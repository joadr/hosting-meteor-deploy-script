(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Accounts = Package['accounts-base'].Accounts;
var check = Package.check.check;
var Match = Package.check.Match;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var ECMAScript = Package.ecmascript.ECMAScript;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var _ = Package.underscore._;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Autoupdate = Package.autoupdate.Autoupdate;

/* Package-scope variables */
var willChangeWithParent, objectHasKey, Roles;

var require = meteorInstall({"node_modules":{"meteor":{"nicolaslopezj:roles":{"helpers.js":["babel-runtime/helpers/typeof",function(require){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/nicolaslopezj_roles/helpers.js                                                                          //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var _typeof2 = require("babel-runtime/helpers/typeof");                                                             //
                                                                                                                    //
var _typeof3 = _interopRequireDefault(_typeof2);                                                                    //
                                                                                                                    //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                   //
                                                                                                                    //
willChangeWithParent = function (object, key) {                                                                     // 1
  if (!_.isObject(object)) {                                                                                        // 2
    return;                                                                                                         // 3
  }                                                                                                                 // 4
                                                                                                                    //
  var willChange = false;                                                                                           // 5
                                                                                                                    //
  _.each(_.keys(object), function (modifyingKey) {                                                                  // 6
    if (key && key.indexOf(modifyingKey) === 0) {                                                                   // 7
      willChange = true;                                                                                            // 8
    }                                                                                                               // 9
  });                                                                                                               // 10
                                                                                                                    //
  return willChange;                                                                                                // 11
};                                                                                                                  // 12
                                                                                                                    //
objectHasKey = function (object, key) {                                                                             // 14
  var dotNotation = {};                                                                                             // 15
  (function () {                                                                                                    // 17
    function recurse(obj, current) {                                                                                // 17
      for (var key in meteorBabelHelpers.sanitizeForInObject(obj)) {                                                // 18
        var value = obj[key];                                                                                       // 19
        var newKey = current ? current + "." + key : key; // joined key with dot                                    // 20
                                                                                                                    //
        if (value && (typeof value === "undefined" ? "undefined" : (0, _typeof3.default)(value)) === "object") {    // 21
          recurse(value, newKey); // it's a nested object, so do it again                                           // 22
        } else {                                                                                                    // 23
          dotNotation[newKey] = value; // it's not an object, so set the property                                   // 24
        }                                                                                                           // 25
      }                                                                                                             // 26
    }                                                                                                               // 27
                                                                                                                    //
    return recurse;                                                                                                 // 17
  })()(object);                                                                                                     // 17
                                                                                                                    //
  var keys = _.keys(dotNotation);                                                                                   // 29
                                                                                                                    //
  var newKeys = [];                                                                                                 // 30
                                                                                                                    //
  _.each(keys, function (_key) {                                                                                    // 32
    var parts = _key.split('.');                                                                                    // 33
                                                                                                                    //
    var added = [];                                                                                                 // 34
                                                                                                                    //
    _.each(parts, function (part) {                                                                                 // 35
      if (!isNaN(part)) {                                                                                           // 36
        part = '$';                                                                                                 // 37
        added.push(part);                                                                                           // 38
      } else {                                                                                                      // 39
        added.push(part);                                                                                           // 40
        newKeys.push(added.join('.'));                                                                              // 41
      }                                                                                                             // 42
    });                                                                                                             // 43
  });                                                                                                               // 44
                                                                                                                    //
  return _.contains(newKeys, key);                                                                                  // 46
};                                                                                                                  // 47
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"roles.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/nicolaslopezj_roles/roles.js                                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 // 1
 * Init the variable                                                                                                //
 */Roles = {};                                                                                                      //
Roles.debug = false; /**                                                                                            // 6
                      * Initialize variables                                                                        //
                      */                                                                                            //
Roles._roles = {};                                                                                                  // 11
Roles._actions = [];                                                                                                // 12
Roles._helpers = [];                                                                                                // 13
Roles._usersCollection = Meteor.users;                                                                              // 14
Roles._specialRoles = ['__loggedIn__', '__notAdmin__', '__notLoggedIn__', '__all__']; /**                           // 15
                                                                                       * Old collection             //
                                                                                       */                           //
Roles._oldCollection = new Mongo.Collection('roles'); /**                                                           // 20
                                                       * Get the list of roles                                      //
                                                       */                                                           //
                                                                                                                    //
Roles.availableRoles = function () {                                                                                // 25
  return _.difference(_.keys(this._roles), this._specialRoles);                                                     // 26
}; /**                                                                                                              // 27
    * Check if a user has a role                                                                                    //
    */                                                                                                              //
                                                                                                                    //
Roles.userHasRole = function (userId, role) {                                                                       // 32
  if (role == '__all__') return true;                                                                               // 33
  if (role == '__notLoggedIn__' && !userId) return true;                                                            // 34
  if (role == '__default__' && userId) return true;                                                                 // 35
  if (role == '__notAdmin__' && Roles._usersCollection.find({                                                       // 36
    _id: userId,                                                                                                    // 38
    roles: 'admin'                                                                                                  // 38
  }).count() === 0) return true;                                                                                    // 38
  return Roles._usersCollection.find({                                                                              // 40
    _id: userId,                                                                                                    // 40
    roles: role                                                                                                     // 40
  }).count() > 0;                                                                                                   // 40
}; /**                                                                                                              // 41
    * Creates a new action                                                                                          //
    */                                                                                                              //
                                                                                                                    //
Roles.registerAction = function (name, adminAllow, adminDeny) {                                                     // 46
  check(name, String);                                                                                              // 47
  check(adminAllow, Match.Optional(Match.Any));                                                                     // 48
  check(adminDeny, Match.Optional(Match.Any));                                                                      // 49
                                                                                                                    //
  if (!_.contains(this._actions, name)) {                                                                           // 51
    this._actions.push(name);                                                                                       // 52
  }                                                                                                                 // 53
                                                                                                                    //
  if (adminAllow) {                                                                                                 // 55
    Roles.adminRole.allow(name, adminAllow);                                                                        // 56
  }                                                                                                                 // 57
                                                                                                                    //
  if (adminDeny) {                                                                                                  // 59
    Roles.adminRole.deny(name, adminDeny);                                                                          // 60
  }                                                                                                                 // 61
}; /**                                                                                                              // 62
    * Creates a new helper                                                                                          //
    */                                                                                                              //
                                                                                                                    //
Roles.registerHelper = function (name, adminHelper) {                                                               // 67
  check(name, String);                                                                                              // 68
  check(adminHelper, Match.Any);                                                                                    // 69
                                                                                                                    //
  if (!_.contains(this._helpers, name)) {                                                                           // 71
    this._helpers.push(name);                                                                                       // 72
  }                                                                                                                 // 73
                                                                                                                    //
  if (adminHelper) {                                                                                                // 75
    Roles.adminRole.helper(name, adminHelper);                                                                      // 76
  }                                                                                                                 // 77
}; /**                                                                                                              // 78
    * Constructs a new role                                                                                         //
    */                                                                                                              //
                                                                                                                    //
Roles.Role = function (name) {                                                                                      // 83
  check(name, String);                                                                                              // 84
  if (!(this instanceof Roles.Role)) throw new Error('use "new" to construct a role');                              // 86
  if (_.has(Roles._roles, name)) throw new Error('"' + name + '" role is already defined');                         // 89
  this.name = name;                                                                                                 // 92
  this.allowRules = {};                                                                                             // 93
  this.denyRules = {};                                                                                              // 94
  this.helpers = {};                                                                                                // 95
  Roles._roles[name] = this;                                                                                        // 97
}; /**                                                                                                              // 98
    * Adds allow properties to a role                                                                               //
    */                                                                                                              //
                                                                                                                    //
Roles.Role.prototype.allow = function (action, allow) {                                                             // 103
  check(action, String);                                                                                            // 104
  check(allow, Match.Any);                                                                                          // 105
                                                                                                                    //
  if (!_.contains(Roles._actions, action)) {                                                                        // 107
    Roles.registerAction(action);                                                                                   // 108
  }                                                                                                                 // 109
                                                                                                                    //
  if (!_.isFunction(allow)) {                                                                                       // 111
    var clone = _.clone(allow);                                                                                     // 112
                                                                                                                    //
    allow = function () {                                                                                           // 113
      return clone;                                                                                                 // 114
    };                                                                                                              // 115
  }                                                                                                                 // 116
                                                                                                                    //
  this.allowRules[action] = this.allowRules[action] || [];                                                          // 118
  this.allowRules[action].push(allow);                                                                              // 119
}; /**                                                                                                              // 120
    * Adds deny properties to a role                                                                                //
    */                                                                                                              //
                                                                                                                    //
Roles.Role.prototype.deny = function (action, deny) {                                                               // 125
  check(action, String);                                                                                            // 126
  check(deny, Match.Any);                                                                                           // 127
                                                                                                                    //
  if (!_.contains(Roles._actions, action)) {                                                                        // 129
    Roles.registerAction(action);                                                                                   // 130
  }                                                                                                                 // 131
                                                                                                                    //
  if (!_.isFunction(deny)) {                                                                                        // 133
    var clone = _.clone(deny);                                                                                      // 134
                                                                                                                    //
    deny = function () {                                                                                            // 135
      return clone;                                                                                                 // 136
    };                                                                                                              // 137
  }                                                                                                                 // 138
                                                                                                                    //
  this.denyRules[action] = this.denyRules[action] || [];                                                            // 140
  this.denyRules[action].push(deny);                                                                                // 141
}; /**                                                                                                              // 142
    * Adds a helper to a role                                                                                       //
    */                                                                                                              //
                                                                                                                    //
Roles.Role.prototype.helper = function (helper, func) {                                                             // 147
  check(helper, String);                                                                                            // 148
  check(func, Match.Any);                                                                                           // 149
                                                                                                                    //
  if (!_.contains(Roles._helpers, helper)) {                                                                        // 151
    Roles.registerHelper(helper);                                                                                   // 152
  }                                                                                                                 // 153
                                                                                                                    //
  if (!_.isFunction(func)) {                                                                                        // 155
    var value = _.clone(func);                                                                                      // 156
                                                                                                                    //
    func = function () {                                                                                            // 157
      return value;                                                                                                 // 158
    };                                                                                                              // 159
  }                                                                                                                 // 160
                                                                                                                    //
  if (!this.helpers[helper]) {                                                                                      // 162
    this.helpers[helper] = [];                                                                                      // 163
  }                                                                                                                 // 164
                                                                                                                    //
  this.helpers[helper].push(func);                                                                                  // 166
}; /**                                                                                                              // 167
    * Get user roles                                                                                                //
    */                                                                                                              //
                                                                                                                    //
Roles.getUserRoles = function (userId, includeSpecial) {                                                            // 172
  check(userId, Match.OneOf(String, null, undefined));                                                              // 173
  check(includeSpecial, Match.Optional(Boolean));                                                                   // 174
                                                                                                                    //
  var object = Roles._usersCollection.findOne({                                                                     // 175
    _id: userId                                                                                                     // 175
  }, {                                                                                                              // 175
    fields: {                                                                                                       // 175
      roles: 1                                                                                                      // 175
    }                                                                                                               // 175
  });                                                                                                               // 175
                                                                                                                    //
  var roles = object && object.roles || [];                                                                         // 176
                                                                                                                    //
  if (includeSpecial) {                                                                                             // 177
    roles.push('__all__');                                                                                          // 178
                                                                                                                    //
    if (!userId) {                                                                                                  // 179
      roles.push('__notLoggedIn__');                                                                                // 180
    } else {                                                                                                        // 181
      roles.push('__loggedIn__');                                                                                   // 182
                                                                                                                    //
      if (!_.contains(roles, 'admin')) {                                                                            // 183
        roles.push('__notAdmin__');                                                                                 // 184
      }                                                                                                             // 185
    }                                                                                                               // 186
  }                                                                                                                 // 187
                                                                                                                    //
  return roles;                                                                                                     // 189
}; /**                                                                                                              // 190
    * Calls a helper                                                                                                //
    */                                                                                                              //
                                                                                                                    //
Roles.helper = function (userId, helper) {                                                                          // 195
  var _this = this;                                                                                                 // 195
                                                                                                                    //
  check(userId, Match.OneOf(String, null, undefined));                                                              // 196
  check(helper, String);                                                                                            // 197
  if (!_.contains(this._helpers, helper)) throw 'Helper "' + helper + '" is not defined';                           // 198
                                                                                                                    //
  var args = _.toArray(arguments).slice(2);                                                                         // 200
                                                                                                                    //
  var context = {                                                                                                   // 201
    userId: userId                                                                                                  // 201
  };                                                                                                                // 201
  var responses = [];                                                                                               // 202
  var roles = Roles.getUserRoles(userId, true);                                                                     // 203
                                                                                                                    //
  _.each(roles, function (role) {                                                                                   // 205
    if (_this._roles[role] && _this._roles[role].helpers && _this._roles[role].helpers[helper]) {                   // 206
      var helpers = _this._roles[role].helpers[helper];                                                             // 207
                                                                                                                    //
      _.each(helpers, function (helper) {                                                                           // 208
        responses.push(helper.apply(context, args));                                                                // 209
      });                                                                                                           // 210
    }                                                                                                               // 211
  });                                                                                                               // 212
                                                                                                                    //
  return responses;                                                                                                 // 214
}; /**                                                                                                              // 215
    * Returns if the user passes the allow check                                                                    //
    */                                                                                                              //
                                                                                                                    //
Roles.allow = function (userId, action) {                                                                           // 220
  check(userId, Match.OneOf(String, null, undefined));                                                              // 221
  check(action, String);                                                                                            // 222
                                                                                                                    //
  var args = _.toArray(arguments).slice(2);                                                                         // 224
                                                                                                                    //
  var self = this;                                                                                                  // 225
  var context = {                                                                                                   // 226
    userId: userId                                                                                                  // 226
  };                                                                                                                // 226
  var allowed = false;                                                                                              // 227
  var roles = Roles.getUserRoles(userId, true);                                                                     // 228
                                                                                                                    //
  _.each(roles, function (role) {                                                                                   // 230
    if (!allowed && self._roles[role] && self._roles[role].allowRules && self._roles[role].allowRules[action]) {    // 231
      _.each(self._roles[role].allowRules[action], function (func) {                                                // 232
        var allow = func.apply(context, args);                                                                      // 233
                                                                                                                    //
        if (allow === true) {                                                                                       // 234
          allowed = true;                                                                                           // 235
        }                                                                                                           // 236
      });                                                                                                           // 237
    }                                                                                                               // 238
  });                                                                                                               // 239
                                                                                                                    //
  return allowed;                                                                                                   // 241
}; /**                                                                                                              // 242
    * Returns if the user has permission using deny and deny                                                        //
    */                                                                                                              //
                                                                                                                    //
Roles.deny = function (userId, action) {                                                                            // 247
  var _this2 = this;                                                                                                // 247
                                                                                                                    //
  check(userId, Match.OneOf(String, null, undefined));                                                              // 248
  check(action, String);                                                                                            // 249
                                                                                                                    //
  var args = _.toArray(arguments).slice(2);                                                                         // 251
                                                                                                                    //
  var context = {                                                                                                   // 252
    userId: userId                                                                                                  // 252
  };                                                                                                                // 252
  var denied = false;                                                                                               // 253
  var roles = Roles.getUserRoles(userId, true);                                                                     // 254
                                                                                                                    //
  _.each(roles, function (role) {                                                                                   // 256
    if (!denied && _this2._roles[role] && _this2._roles[role].denyRules && _this2._roles[role].denyRules[action]) {
      _.each(_this2._roles[role].denyRules[action], function (func) {                                               // 263
        var denies = func.apply(context, args);                                                                     // 264
                                                                                                                    //
        if (denies === true) {                                                                                      // 265
          denied = true;                                                                                            // 266
                                                                                                                    //
          if (Roles.debug) {                                                                                        // 267
            console.log("[" + action + "] denied for " + userId + " with role " + role);                            // 268
          }                                                                                                         // 269
        }                                                                                                           // 270
      });                                                                                                           // 271
    }                                                                                                               // 272
  });                                                                                                               // 273
                                                                                                                    //
  return denied;                                                                                                    // 275
}; /**                                                                                                              // 276
    * To check if a user has permisisons to execute an action                                                       //
    */                                                                                                              //
                                                                                                                    //
Roles.userHasPermission = function () {                                                                             // 281
  var allows = this.allow.apply(this, arguments);                                                                   // 282
  var denies = this.deny.apply(this, arguments);                                                                    // 283
  return allows === true && denies === false;                                                                       // 284
}; /**                                                                                                              // 285
    * If the user doesn't has permission it will throw a error                                                      //
    */                                                                                                              //
                                                                                                                    //
Roles.checkPermission = function () {                                                                               // 290
  if (!this.userHasPermission.apply(this, arguments)) {                                                             // 291
    throw new Meteor.Error('unauthorized', 'The user has no permission to perform this action');                    // 292
  }                                                                                                                 // 293
}; /**                                                                                                              // 294
    * Adds helpers to users                                                                                         //
    */                                                                                                              //
                                                                                                                    //
Roles.setUsersHelpers = function () {                                                                               // 299
  Roles._usersCollection.helpers({                                                                                  // 300
    /**                                                                                                             // 301
     * Returns the user roles                                                                                       //
     */getRoles: function (includeSpecial) {                                                                        //
      return Roles.getUserRoles(this._id, includeSpecial);                                                          // 305
    },                                                                                                              // 306
    /**                                                                                                             // 307
     * To check if the user has a role                                                                              //
     */hasRole: function (role) {                                                                                   //
      return Roles.userHasRole(this._id, role);                                                                     // 311
    }                                                                                                               // 312
  });                                                                                                               // 300
};                                                                                                                  // 314
                                                                                                                    //
Roles.setUsersHelpers(); /**                                                                                        // 316
                          * The admin role, who recives the default actions.                                        //
                          */                                                                                        //
Roles.adminRole = new Roles.Role('admin');                                                                          // 321
Roles._adminRole = Roles.adminRole; // Backwards compatibility                                                      // 321
/**                                                                                                                 // 322
 * All the logged in users users                                                                                    //
 */                                                                                                                 //
Roles.loggedInRole = new Roles.Role('__loggedIn__');                                                                // 325
Roles.defaultRole = Roles.loggedInRole; // Backwards compatibility                                                  // 325
/**                                                                                                                 // 326
 * The users that are not admins                                                                                    //
 */                                                                                                                 //
Roles.notAdminRole = new Roles.Role('__notAdmin__'); /**                                                            // 329
                                                      * The users that are not logged in                            //
                                                      */                                                            //
Roles.notLoggedInRole = new Roles.Role('__notLoggedIn__'); /**                                                      // 333
                                                            * Always, no exception                                  //
                                                            */                                                      //
Roles.allRole = new Roles.Role('__all__'); /**                                                                      // 337
                                            * A Helper to attach actions to collections easily                      //
                                            */                                                                      //
                                                                                                                    //
Mongo.Collection.prototype.attachRoles = function (name, dontAllow) {                                               // 342
  Roles.registerAction(name + '.insert', !dontAllow);                                                               // 343
  Roles.registerAction(name + '.update', !dontAllow);                                                               // 344
  Roles.registerAction(name + '.remove', !dontAllow);                                                               // 345
  Roles.registerHelper(name + '.forbiddenFields', []);                                                              // 346
  this.allow({                                                                                                      // 348
    insert: function (userId, doc) {                                                                                // 349
      var allows = Roles.allow(userId, name + '.insert', userId, doc);                                              // 350
                                                                                                                    //
      if (Roles.debug && !allows) {                                                                                 // 351
        console.log("[" + name + ".insert] not allowed for " + userId);                                             // 352
      }                                                                                                             // 353
                                                                                                                    //
      return allows;                                                                                                // 355
    },                                                                                                              // 356
    update: function (userId, doc, fields, modifier) {                                                              // 358
      var allows = Roles.allow(userId, name + '.update', userId, doc, fields, modifier);                            // 359
                                                                                                                    //
      if (Roles.debug && !allows) {                                                                                 // 360
        console.log("[" + name + ".update] not allowed for " + userId);                                             // 361
      }                                                                                                             // 362
                                                                                                                    //
      return allows;                                                                                                // 364
    },                                                                                                              // 365
    remove: function (userId, doc) {                                                                                // 367
      var allows = Roles.allow(userId, name + '.remove', userId, doc);                                              // 368
                                                                                                                    //
      if (Roles.debug && !allows) {                                                                                 // 369
        console.log("[" + name + ".remove] not allowed for " + userId);                                             // 370
      }                                                                                                             // 371
                                                                                                                    //
      return allows;                                                                                                // 373
    }                                                                                                               // 374
  });                                                                                                               // 348
  this.deny({                                                                                                       // 377
    insert: function (userId, doc) {                                                                                // 378
      return Roles.deny(userId, name + '.insert', userId, doc);                                                     // 379
    },                                                                                                              // 380
    update: function (userId, doc, fields, modifier) {                                                              // 382
      return Roles.deny(userId, name + '.update', userId, doc, fields, modifier);                                   // 383
    },                                                                                                              // 384
    remove: function (userId, doc) {                                                                                // 386
      return Roles.deny(userId, name + '.remove', userId, doc);                                                     // 387
    }                                                                                                               // 388
  });                                                                                                               // 377
  this.deny({                                                                                                       // 391
    insert: function (userId, doc) {                                                                                // 392
      var forbiddenFields = _.union.apply(this, Roles.helper(userId, name + '.forbiddenFields'));                   // 393
                                                                                                                    //
      for (var i in meteorBabelHelpers.sanitizeForInObject(forbiddenFields)) {                                      // 395
        var field = forbiddenFields[i];                                                                             // 396
                                                                                                                    //
        if (objectHasKey(doc, field)) {                                                                             // 397
          if (Roles.debug) {                                                                                        // 398
            console.log("[" + name + ".forbiddenField] Field " + field + " is forbidden for " + userId);            // 399
          }                                                                                                         // 400
                                                                                                                    //
          return true;                                                                                              // 402
        }                                                                                                           // 403
      }                                                                                                             // 404
    },                                                                                                              // 405
    update: function (userId, doc, fields, modifier) {                                                              // 407
      var forbiddenFields = _.union.apply(this, Roles.helper(userId, name + '.forbiddenFields', doc._id));          // 408
                                                                                                                    //
      var types = ['$inc', '$mul', '$rename', '$setOnInsert', '$set', '$unset', '$min', '$max', '$currentDate']; // By some reason following for will itterate even through empty array. This will prevent unwanted habbit.
                                                                                                                    //
      if (forbiddenFields.length === 0) {                                                                           // 412
        return false;                                                                                               // 413
      }                                                                                                             // 414
                                                                                                                    //
      for (var i in meteorBabelHelpers.sanitizeForInObject(forbiddenFields)) {                                      // 416
        var field = forbiddenFields[i];                                                                             // 417
                                                                                                                    //
        for (var j in meteorBabelHelpers.sanitizeForInObject(types)) {                                              // 418
          var type = types[j];                                                                                      // 419
                                                                                                                    //
          if (objectHasKey(modifier[type], field)) {                                                                // 420
            if (Roles.debug) {                                                                                      // 421
              console.log("[" + name + ".forbiddenField] Field " + field + " is forbidden for " + userId);          // 422
            }                                                                                                       // 423
                                                                                                                    //
            return true;                                                                                            // 425
          }                                                                                                         // 426
                                                                                                                    //
          if (willChangeWithParent(modifier[type], field)) {                                                        // 428
            if (Roles.debug) {                                                                                      // 429
              console.log("[" + name + ".forbiddenField] Field " + field + " is forbidden for " + userId + " is been changed by a parent object");
            }                                                                                                       // 431
                                                                                                                    //
            return true;                                                                                            // 433
          }                                                                                                         // 434
        }                                                                                                           // 435
      }                                                                                                             // 436
    }                                                                                                               // 437
  });                                                                                                               // 391
};                                                                                                                  // 439
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"keys.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/nicolaslopezj_roles/keys.js                                                                             //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Roles.keys = {}; /**                                                                                                // 1
                  * Initialize the collection                                                                       //
                  */                                                                                                //
Roles.keys.collection = new Meteor.Collection('nicolaslopezj_roles_keys'); /**                                      // 6
                                                                            * Set the permissions                   //
                                                                            * Users can request keys just for them  //
                                                                            */                                      //
Roles.keys.collection.allow({                                                                                       // 12
  insert: function (userId, doc) {                                                                                  // 13
    return userId === doc.userId;                                                                                   // 14
  },                                                                                                                // 15
  remove: function (userId, doc) {                                                                                  // 16
    return userId === doc.userId;                                                                                   // 17
  }                                                                                                                 // 18
}); /**                                                                                                             // 12
     * Requests a new key                                                                                           //
     * @param  {String} userId    Id of the userId                                                                  //
     * @param  {Date}   expiresAt Date of expiration                                                                //
     * @return {String}           Id of the key                                                                     //
     */                                                                                                             //
                                                                                                                    //
Roles.keys.request = function (userId, expiresAt) {                                                                 // 27
  check(userId, String);                                                                                            // 28
  var doc = {                                                                                                       // 29
    userId: userId,                                                                                                 // 30
    createdAt: new Date()                                                                                           // 31
  };                                                                                                                // 29
                                                                                                                    //
  if (expiresAt) {                                                                                                  // 33
    check(expiresAt, Date);                                                                                         // 34
    doc.expiresAt = expiresAt;                                                                                      // 35
  }                                                                                                                 // 36
                                                                                                                    //
  return this.collection.insert(doc);                                                                               // 37
}; /**                                                                                                              // 38
    * Returns the userId of the specified key and deletes the key from the database                                 //
    * @param  {String}  key                                                                                         //
    * @param  {Boolean} dontDelete True to leave the key in the database                                            //
    * @return {String}             Id of the user                                                                   //
    */                                                                                                              //
                                                                                                                    //
Roles.keys.getUserId = function (key, dontDelete) {                                                                 // 46
  check(key, String);                                                                                               // 47
  check(dontDelete, Match.Optional(Boolean));                                                                       // 48
  var doc = this.collection.findOne({                                                                               // 50
    _id: key,                                                                                                       // 50
    $or: [{                                                                                                         // 50
      expiresAt: {                                                                                                  // 50
        $exists: false                                                                                              // 50
      }                                                                                                             // 50
    }, {                                                                                                            // 50
      expiresAt: {                                                                                                  // 50
        $gte: new Date()                                                                                            // 50
      }                                                                                                             // 50
    }]                                                                                                              // 50
  });                                                                                                               // 50
  if (!doc) return;                                                                                                 // 51
                                                                                                                    //
  if (!dontDelete) {                                                                                                // 53
    if (!doc.expiresAt) {                                                                                           // 54
      console.log('borrando por no tener expire at');                                                               // 55
      this.collection.remove({                                                                                      // 56
        _id: key                                                                                                    // 56
      });                                                                                                           // 56
    } else {                                                                                                        // 57
      if (moment(doc.expiresAt).isBefore(moment())) {                                                               // 58
        console.log('borrando por expire at ya pasó');                                                              // 59
        this.collection.remove({                                                                                    // 60
          _id: key                                                                                                  // 60
        });                                                                                                         // 60
      }                                                                                                             // 61
    }                                                                                                               // 62
  }                                                                                                                 // 63
                                                                                                                    //
  return doc.userId;                                                                                                // 65
};                                                                                                                  // 66
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"roles_server.js":["babel-runtime/helpers/toConsumableArray","babel-runtime/helpers/typeof","babel-runtime/helpers/extends","meteor/meteor","meteor/check",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/nicolaslopezj_roles/roles_server.js                                                                     //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var _toConsumableArray2 = require("babel-runtime/helpers/toConsumableArray");                                       //
                                                                                                                    //
var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);                                              //
                                                                                                                    //
var _typeof2 = require("babel-runtime/helpers/typeof");                                                             //
                                                                                                                    //
var _typeof3 = _interopRequireDefault(_typeof2);                                                                    //
                                                                                                                    //
var _extends2 = require("babel-runtime/helpers/extends");                                                           //
                                                                                                                    //
var _extends3 = _interopRequireDefault(_extends2);                                                                  //
                                                                                                                    //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                   //
                                                                                                                    //
var Meteor = void 0;                                                                                                // 1
module.import('meteor/meteor', {                                                                                    // 1
  "Meteor": function (v) {                                                                                          // 1
    Meteor = v;                                                                                                     // 1
  }                                                                                                                 // 1
}, 0);                                                                                                              // 1
var check = void 0,                                                                                                 // 1
    Match = void 0;                                                                                                 // 1
module.import('meteor/check', {                                                                                     // 1
  "check": function (v) {                                                                                           // 1
    check = v;                                                                                                      // 1
  },                                                                                                                // 1
  "Match": function (v) {                                                                                           // 1
    Match = v;                                                                                                      // 1
  }                                                                                                                 // 1
}, 1);                                                                                                              // 1
/**                                                                                                                 // 4
 * Publish user roles                                                                                               //
 */Meteor.publish('nicolaslopezj_roles', function () {                                                              //
  return Meteor.users.find({                                                                                        // 8
    _id: this.userId                                                                                                // 8
  }, {                                                                                                              // 8
    fields: {                                                                                                       // 8
      roles: 1                                                                                                      // 8
    }                                                                                                               // 8
  });                                                                                                               // 8
}); /**                                                                                                             // 9
     * Migrate                                                                                                      //
     */                                                                                                             //
Meteor.methods({                                                                                                    // 14
  nicolaslopezj_roles_migrate: function () {                                                                        // 15
    var selector = Roles._oldCollection.find({});                                                                   // 16
                                                                                                                    //
    console.log('migrating ' + selector.count() + ' roles...');                                                     // 17
    selector.forEach(function (userRoles) {                                                                         // 18
      Meteor.users.update(userRoles.userId, {                                                                       // 19
        $set: {                                                                                                     // 19
          roles: userRoles.roles                                                                                    // 19
        }                                                                                                           // 19
      });                                                                                                           // 19
                                                                                                                    //
      Roles._oldCollection.remove(userRoles);                                                                       // 20
    });                                                                                                             // 21
    console.log('roles migrated');                                                                                  // 23
  }                                                                                                                 // 24
}); /**                                                                                                             // 14
     * Adds roles to a user                                                                                         //
     */                                                                                                             //
                                                                                                                    //
Roles.addUserToRoles = function (userId, roles) {                                                                   // 30
  check(userId, String);                                                                                            // 31
  check(roles, Match.OneOf(String, Array));                                                                         // 32
                                                                                                                    //
  if (!_.isArray(roles)) {                                                                                          // 33
    roles = [roles];                                                                                                // 34
  }                                                                                                                 // 35
                                                                                                                    //
  return Meteor.users.update({                                                                                      // 37
    _id: userId                                                                                                     // 37
  }, {                                                                                                              // 37
    $addToSet: {                                                                                                    // 37
      roles: {                                                                                                      // 37
        $each: roles                                                                                                // 37
      }                                                                                                             // 37
    }                                                                                                               // 37
  });                                                                                                               // 37
}; /**                                                                                                              // 38
    * Set user roles                                                                                                //
    */                                                                                                              //
                                                                                                                    //
Roles.setUserRoles = function (userId, roles) {                                                                     // 43
  check(userId, String);                                                                                            // 44
  check(roles, Match.OneOf(String, Array));                                                                         // 45
                                                                                                                    //
  if (!_.isArray(roles)) {                                                                                          // 46
    roles = [roles];                                                                                                // 47
  }                                                                                                                 // 48
                                                                                                                    //
  return Meteor.users.update({                                                                                      // 50
    _id: userId                                                                                                     // 50
  }, {                                                                                                              // 50
    $set: {                                                                                                         // 50
      roles: roles                                                                                                  // 50
    }                                                                                                               // 50
  });                                                                                                               // 50
}; /**                                                                                                              // 51
    * Removes roles from a user                                                                                     //
    */                                                                                                              //
                                                                                                                    //
Roles.removeUserFromRoles = function (userId, roles) {                                                              // 56
  check(userId, String);                                                                                            // 57
  check(roles, Match.OneOf(String, Array));                                                                         // 58
                                                                                                                    //
  if (!_.isArray(roles)) {                                                                                          // 59
    roles = [roles];                                                                                                // 60
  }                                                                                                                 // 61
                                                                                                                    //
  return Meteor.users.update({                                                                                      // 63
    _id: userId                                                                                                     // 63
  }, {                                                                                                              // 63
    $pullAll: {                                                                                                     // 63
      roles: roles                                                                                                  // 63
    }                                                                                                               // 63
  });                                                                                                               // 63
}; /**                                                                                                              // 64
    * Requires a permission to run a resolver                                                                       //
    */                                                                                                              //
                                                                                                                    //
var defaultOptions = {                                                                                              // 69
  returnNull: false,                                                                                                // 70
  showKey: true,                                                                                                    // 71
  mapArgs: function () {                                                                                            // 72
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {                          // 72
      args[_key] = arguments[_key];                                                                                 // 72
    }                                                                                                               // 72
                                                                                                                    //
    return args;                                                                                                    // 72
  }                                                                                                                 // 72
};                                                                                                                  // 69
                                                                                                                    //
Roles.action = function (action, userOptions) {                                                                     // 74
  var options = (0, _extends3.default)({}, defaultOptions, userOptions);                                            // 75
  return function (target, key, descriptor) {                                                                       // 76
    var fn = descriptor.value || target[key];                                                                       // 77
                                                                                                                    //
    if (typeof fn !== 'function') {                                                                                 // 78
      throw new Error("@Roles.action decorator can only be applied to methods not: " + (typeof fn === "undefined" ? "undefined" : (0, _typeof3.default)(fn)));
    }                                                                                                               // 80
                                                                                                                    //
    return {                                                                                                        // 82
      configurable: true,                                                                                           // 83
      get: function () {                                                                                            // 84
        var newFn = function (root, params, context) {                                                              // 85
          for (var _len2 = arguments.length, other = Array(_len2 > 3 ? _len2 - 3 : 0), _key2 = 3; _key2 < _len2; _key2++) {
            other[_key2 - 3] = arguments[_key2];                                                                    // 85
          }                                                                                                         // 85
                                                                                                                    //
          var _Roles;                                                                                               // 85
                                                                                                                    //
          var args = options.mapArgs.apply(options, [root, params, context].concat(other));                         // 86
                                                                                                                    //
          var hasPermission = (_Roles = Roles).userHasPermission.apply(_Roles, [context.userId, action].concat((0, _toConsumableArray3.default)(args)));
                                                                                                                    //
          if (hasPermission) {                                                                                      // 88
            return fn.apply(undefined, [root, params, context].concat(other));                                      // 89
          } else {                                                                                                  // 90
            if (options.returnNull) {                                                                               // 91
              return null;                                                                                          // 92
            } else {                                                                                                // 93
              var keyText = options.showKey ? " \"" + action + "\" in \"" + key + "\"" : '';                        // 94
              throw new Error("The user has no permission to perform the action" + keyText);                        // 95
            }                                                                                                       // 96
          }                                                                                                         // 97
        };                                                                                                          // 98
                                                                                                                    //
        Object.defineProperty(this, key, {                                                                          // 99
          value: newFn,                                                                                             // 100
          configurable: true,                                                                                       // 101
          writable: true                                                                                            // 102
        });                                                                                                         // 99
        return newFn;                                                                                               // 104
      }                                                                                                             // 105
    };                                                                                                              // 82
  };                                                                                                                // 107
};                                                                                                                  // 108
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/nicolaslopezj:roles/helpers.js");
require("./node_modules/meteor/nicolaslopezj:roles/roles.js");
require("./node_modules/meteor/nicolaslopezj:roles/keys.js");
require("./node_modules/meteor/nicolaslopezj:roles/roles_server.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['nicolaslopezj:roles'] = {}, {
  Roles: Roles,
  objectHasKey: objectHasKey
});

})();

//# sourceMappingURL=nicolaslopezj_roles.js.map
