(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var orion = Package['orionjs:filesystem'].orion;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var HTML = Package.htmljs.HTML;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Collection2 = Package['aldeed:collection2-core'].Collection2;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

/* Package-scope variables */
var Colibri;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:image-attribute":{"attribute.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/orionjs_image-attribute/attribute.js                     //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var subSchema = new SimpleSchema({                                   // 1
  url: {                                                             // 2
    type: String                                                     // 3
  },                                                                 // 2
  fileId: {                                                          // 5
    type: String,                                                    // 6
    optional: true                                                   // 7
  },                                                                 // 5
  info: {                                                            // 9
    type: Object,                                                    // 10
    optional: true                                                   // 11
  },                                                                 // 9
  'info.width': {                                                    // 13
    type: Number,                                                    // 14
    optional: true                                                   // 15
  },                                                                 // 13
  'info.height': {                                                   // 17
    type: Number,                                                    // 18
    optional: true                                                   // 19
  },                                                                 // 17
  'info.backgroundColor': {                                          // 21
    type: String,                                                    // 22
    optional: true                                                   // 23
  },                                                                 // 21
  'info.primaryColor': {                                             // 25
    type: String,                                                    // 26
    optional: true                                                   // 27
  },                                                                 // 25
  'info.secondaryColor': {                                           // 29
    type: String,                                                    // 30
    optional: true                                                   // 31
  },                                                                 // 29
  meta: {                                                            // 33
    type: Object,                                                    // 34
    optional: true,                                                  // 35
    blackbox: true                                                   // 36
  }                                                                  // 33
});                                                                  // 1
orion.attributes.registerAttribute('image', {                        // 40
  template: 'orionAttributesImageUpload',                            // 41
  previewTemplate: 'orionAttributesImageUploadColumn',               // 42
  getSchema: function (options) {                                    // 43
    return {                                                         // 44
      type: subSchema                                                // 45
    };                                                               // 44
  },                                                                 // 47
  valueOut: function () {                                            // 48
    return Session.get('image' + this.attr('data-schema-key'));      // 49
  }                                                                  // 50
});                                                                  // 40
orion.attributes.registerAttribute('images', {                       // 53
  template: 'orionAttributesImagesUpload',                           // 54
  previewTemplate: 'orionAttributesImagesUploadColumn',              // 55
  getSchema: function (options) {                                    // 56
    return {                                                         // 57
      type: [subSchema]                                              // 58
    };                                                               // 57
  },                                                                 // 60
  valueOut: function () {                                            // 61
    return Session.get('images' + this.attr('data-schema-key'));     // 62
  }                                                                  // 63
});                                                                  // 53
///////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/orionjs:image-attribute/attribute.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['orionjs:image-attribute'] = {}, {
  Colibri: Colibri
});

})();

//# sourceMappingURL=orionjs_image-attribute.js.map
