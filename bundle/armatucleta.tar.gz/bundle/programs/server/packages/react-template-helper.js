(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['react-template-helper'] = {};

})();
