(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['simply:reactive-local-storage'] = {};

})();
