(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var _ = Package.underscore._;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Autoupdate = Package.autoupdate.Autoupdate;

/* Package-scope variables */
var __coffeescriptShare, Knox, AWS;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/lepozepo_s3/server/startup.coffee.js                                                                 //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var processBrowser;                                                                                              // 2
Knox = Npm.require("knox");                                                                                      // 2
processBrowser = process.browser;                                                                                // 4
process.browser = false;                                                                                         // 5
AWS = Npm.require("aws-sdk");                                                                                    // 6
process.browser = processBrowser;                                                                                // 7
this.S3 = {                                                                                                      // 10
  config: {},                                                                                                    // 11
  knox: {},                                                                                                      // 12
  aws: {},                                                                                                       // 13
  rules: {}                                                                                                      // 14
};                                                                                                               // 11
Meteor.startup(function () {                                                                                     // 16
  if (!_.has(S3.config, "key")) {                                                                                // 17
    console.log("S3: AWS key is undefined");                                                                     // 18
  }                                                                                                              // 23
                                                                                                                 //
  if (!_.has(S3.config, "secret")) {                                                                             // 20
    console.log("S3: AWS secret is undefined");                                                                  // 21
  }                                                                                                              // 26
                                                                                                                 //
  if (!_.has(S3.config, "bucket")) {                                                                             // 23
    console.log("S3: AWS bucket is undefined");                                                                  // 24
  }                                                                                                              // 29
                                                                                                                 //
  if (!_.has(S3.config, "bucket") || !_.has(S3.config, "secret") || !_.has(S3.config, "key")) {                  // 26
    return;                                                                                                      // 27
  }                                                                                                              // 32
                                                                                                                 //
  _.defaults(S3.config, {                                                                                        // 29
    region: "us-east-1"                                                                                          // 30
  });                                                                                                            // 30
                                                                                                                 //
  S3.knox = Knox.createClient(S3.config);                                                                        // 32
  return S3.aws = new AWS.S3({                                                                                   // 37
    accessKeyId: S3.config.key,                                                                                  // 34
    secretAccessKey: S3.config.secret,                                                                           // 35
    region: S3.config.region                                                                                     // 36
  });                                                                                                            // 34
});                                                                                                              // 16
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/lepozepo_s3/server/sign_request.coffee.js                                                            //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Crypto, HmacSHA256, calculate_signature, moment;                                                             // 1
Meteor.methods({                                                                                                 // 1
  _s3_sign: function (ops) {                                                                                     // 2
    var expiration, key, meta_credential, meta_date, meta_uuid, policy, post_url, signature;                     // 3
                                                                                                                 //
    if (ops == null) {                                                                                           // 6
      ops = {};                                                                                                  // 2
    }                                                                                                            // 8
                                                                                                                 //
    this.unblock();                                                                                              // 3
                                                                                                                 //
    _.defaults(ops, {                                                                                            // 13
      expiration: 1800000,                                                                                       // 14
      path: "",                                                                                                  // 15
      bucket: S3.config.bucket,                                                                                  // 16
      acl: "public-read",                                                                                        // 17
      region: S3.config.region,                                                                                  // 18
      server_side_encryption: false                                                                              // 19
    });                                                                                                          // 14
                                                                                                                 //
    check(ops, {                                                                                                 // 21
      expiration: Number,                                                                                        // 22
      path: String,                                                                                              // 23
      bucket: String,                                                                                            // 24
      acl: String,                                                                                               // 25
      region: String,                                                                                            // 26
      server_side_encryption: Boolean,                                                                           // 27
      file_type: String,                                                                                         // 28
      file_name: String,                                                                                         // 29
      file_size: Number                                                                                          // 30
    });                                                                                                          // 22
    expiration = new Date(Date.now() + ops.expiration);                                                          // 32
    expiration = expiration.toISOString();                                                                       // 33
                                                                                                                 //
    if (_.isEmpty(ops.path)) {                                                                                   // 35
      key = "" + ops.file_name;                                                                                  // 36
    } else {                                                                                                     // 35
      key = ops.path + "/" + ops.file_name;                                                                      // 38
    }                                                                                                            // 35
                                                                                                                 //
    meta_uuid = Meteor.uuid();                                                                                   // 40
    meta_date = moment().format('YYYYMMDD') + "T000000Z";                                                        // 41
    meta_credential = S3.config.key + "/" + moment().format('YYYYMMDD') + "/" + ops.region + "/s3/aws4_request";
    policy = {                                                                                                   // 43
      "expiration": expiration,                                                                                  // 44
      "conditions": [["content-length-range", 0, ops.file_size], {                                               // 45
        "key": key                                                                                               // 47
      }, {                                                                                                       // 47
        "bucket": ops.bucket                                                                                     // 48
      }, {                                                                                                       // 48
        "Content-Type": ops.file_type                                                                            // 49
      }, {                                                                                                       // 49
        "acl": ops.acl                                                                                           // 50
      }, {                                                                                                       // 50
        "x-amz-algorithm": "AWS4-HMAC-SHA256"                                                                    // 51
      }, {                                                                                                       // 51
        "x-amz-credential": meta_credential                                                                      // 52
      }, {                                                                                                       // 52
        "x-amz-date": meta_date                                                                                  // 53
      }, {                                                                                                       // 53
        "x-amz-meta-uuid": meta_uuid                                                                             // 54
      }]                                                                                                         // 54
    };                                                                                                           // 44
                                                                                                                 //
    if (ops.server_side_encryption) {                                                                            // 56
      policy["conditions"].push({                                                                                // 57
        "x-amz-server-side-encryption": "AES256"                                                                 // 57
      });                                                                                                        // 57
    }                                                                                                            // 65
                                                                                                                 //
    policy = new Buffer(JSON.stringify(policy), "utf-8").toString("base64");                                     // 60
    signature = calculate_signature(policy, ops.region);                                                         // 63
                                                                                                                 //
    if (ops.region === "us-east-1" || ops.region === "us-standard") {                                            // 66
      post_url = "https://s3.amazonaws.com/" + ops.bucket;                                                       // 67
    } else {                                                                                                     // 66
      post_url = "https://s3-" + ops.region + ".amazonaws.com/" + ops.bucket;                                    // 69
    }                                                                                                            // 72
                                                                                                                 //
    return {                                                                                                     // 73
      policy: policy,                                                                                            // 72
      signature: signature,                                                                                      // 73
      access_key: S3.config.key,                                                                                 // 74
      post_url: post_url,                                                                                        // 75
      url: (post_url + "/" + key).replace("https://", "http://"),                                                // 76
      secure_url: post_url + "/" + key,                                                                          // 77
      relative_url: "/" + key,                                                                                   // 78
      bucket: ops.bucket,                                                                                        // 79
      acl: ops.acl,                                                                                              // 80
      key: key,                                                                                                  // 81
      file_type: ops.file_type,                                                                                  // 82
      file_name: ops.file_name,                                                                                  // 83
      meta_uuid: meta_uuid,                                                                                      // 84
      meta_date: meta_date,                                                                                      // 85
      meta_credential: meta_credential                                                                           // 86
    };                                                                                                           // 72
  }                                                                                                              // 2
});                                                                                                              // 2
Crypto = Npm.require("crypto-js");                                                                               // 90
moment = Npm.require("moment");                                                                                  // 91
HmacSHA256 = Crypto.HmacSHA256;                                                                                  // 92
                                                                                                                 //
calculate_signature = function (policy, region) {                                                                // 94
  var kDate, kRegion, kService, signature_key;                                                                   // 95
  kDate = HmacSHA256(moment().format("YYYYMMDD"), "AWS4" + S3.config.secret);                                    // 95
  kRegion = HmacSHA256(region, kDate);                                                                           // 96
  kService = HmacSHA256("s3", kRegion);                                                                          // 97
  signature_key = HmacSHA256("aws4_request", kService);                                                          // 98
  return HmacSHA256(policy, signature_key).toString(Crypto.enc.Hex);                                             // 105
};                                                                                                               // 94
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/lepozepo_s3/server/delete_object.coffee.js                                                           //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Future;                                                                                                      // 1
Future = Npm.require('fibers/future');                                                                           // 1
Meteor.methods({                                                                                                 // 3
  _s3_delete: function (path) {                                                                                  // 4
    var auth_function, delete_context, future, ref;                                                              // 5
    this.unblock();                                                                                              // 5
    check(path, String);                                                                                         // 6
    future = new Future();                                                                                       // 8
                                                                                                                 //
    if ((ref = S3.rules) != null ? ref["delete"] : void 0) {                                                     // 10
      delete_context = _.extend(this, {                                                                          // 11
        s3_delete_path: path                                                                                     // 12
      });                                                                                                        // 12
      auth_function = _.bind(S3.rules["delete"], delete_context);                                                // 14
                                                                                                                 //
      if (!auth_function()) {                                                                                    // 15
        throw new Meteor.Error("Unauthorized", "Delete not allowed");                                            // 16
      }                                                                                                          // 10
    }                                                                                                            // 19
                                                                                                                 //
    S3.knox.deleteFile(path, function (e, r) {                                                                   // 18
      if (e) {                                                                                                   // 19
        return future["return"](e);                                                                              // 22
      } else {                                                                                                   // 19
        return future["return"](true);                                                                           // 24
      }                                                                                                          // 25
    });                                                                                                          // 18
    return future.wait();                                                                                        // 27
  }                                                                                                              // 4
});                                                                                                              // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['lepozepo:s3'] = {}, {
  Knox: Knox,
  AWS: AWS
});

})();

//# sourceMappingURL=lepozepo_s3.js.map
