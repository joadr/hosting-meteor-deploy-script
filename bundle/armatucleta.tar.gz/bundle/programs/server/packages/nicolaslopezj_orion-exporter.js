(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var orion = Package['orionjs:collections'].orion;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var Picker = Package['meteorhacks:picker'].Picker;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var HTML = Package.htmljs.HTML;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Collection2 = Package['aldeed:collection2-core'].Collection2;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

/* Package-scope variables */
var exportPages, collections, pages;

var require = meteorInstall({"node_modules":{"meteor":{"nicolaslopezj:orion-exporter":{"exporter.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/nicolaslopezj_orion-exporter/exporter.js                                             //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
Options.init('showExportTab', false);                                                            // 1
Options.init('dontImportCollections', []);                                                       // 2
exportPages = _.has(Package, 'orionjs:pages');                                                   // 3
collections = [];                                                                                // 4
orion.collections.onCreated(function (collection) {                                              // 6
  collections.push(this);                                                                        // 7
});                                                                                              // 8
                                                                                                 //
if (exportPages) {                                                                               // 10
  pages = orion.pages.collection;                                                                // 11
} /**                                                                                            // 12
   * Init the template name variable                                                             //
   */                                                                                            //
                                                                                                 //
ReactiveTemplates.request('orionExport', 'nicolaslopezj_orionExporter_bootstrap');               // 17
                                                                                                 //
if (_.has(Package, 'orionjs:materialize')) {                                                     // 19
  ReactiveTemplates.set('orionExport', 'nicolaslopezj_orionExporter_materialize');               // 20
} /**                                                                                            // 21
   * Init the role action                                                                        //
   */                                                                                            //
                                                                                                 //
Roles.registerAction('nicolaslopezj.orionExport', true); /**                                     // 26
                                                          * Register the route                   //
                                                          */                                     //
RouterLayer.route('/admin/export', {                                                             // 31
  layout: 'layout',                                                                              // 32
  template: 'orionExport',                                                                       // 33
  name: 'nicolaslopezj.orionExport',                                                             // 34
  reactiveTemplates: true                                                                        // 35
}); /**                                                                                          // 31
     * Ensure user is logged in                                                                  //
     */                                                                                          //
orion.accounts.addProtectedRoute('nicolaslopezj.orionExport');                                   // 41
///////////////////////////////////////////////////////////////////////////////////////////////////

},"exporter_server.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/nicolaslopezj_orion-exporter/exporter_server.js                                      //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
var bodyParser = Npm.require('body-parser'); // using meteorhacks:npm package                    // 1
                                                                                                 //
                                                                                                 //
Picker.middleware(bodyParser.json({                                                              // 2
  limit: '100mb'                                                                                 // 2
}));                                                                                             // 2
Picker.route('/admin/download-export-users/:key', function (params, req, res, next) {            // 4
  var userId = Roles.keys.getUserId(params.key);                                                 // 5
                                                                                                 //
  if (!userId || !Roles.userHasPermission(userId, 'nicolaslopezj.orionExport')) {                // 6
    res.end('The user is not authorized to perform this action');                                // 7
    return;                                                                                      // 8
  }                                                                                              // 9
                                                                                                 //
  var data = {};                                                                                 // 11
  data.dictionary = orion.dictionary.findOne();                                                  // 13
                                                                                                 //
  if (exportPages) {                                                                             // 14
    data.pages = pages.find().fetch();                                                           // 15
  } //GridFs                                                                                     // 16
  //var Files = new Mongo.Collection('data.files');                                              // 19
                                                                                                 //
                                                                                                 //
  var Chunk = new Mongo.Collection('data.chunks');                                               // 20
  var Locks = new Mongo.Collection('data.locks'); //console.log(Files.find().fetch());           // 21
  //data.data.files = Files.find().fetch();                                                      // 24
                                                                                                 //
  data.data = {};                                                                                // 25
  data.data.files = fc.find().fetch();                                                           // 26
  data.data.chunk = Chunk.find().fetch();                                                        // 27
  data.data.locks = Locks.find().fetch();                                                        // 28
  data.collections = {};                                                                         // 30
                                                                                                 //
  _.each(collections, function (collection) {                                                    // 32
    data.collections[collection._name] = collection.find().fetch();                              // 33
  });                                                                                            // 34
                                                                                                 //
  data.users = Meteor.users.find().fetch();                                                      // 36
                                                                                                 //
  if (Roles._collection) {                                                                       // 37
    data.roles = Roles._collection.find().fetch();                                               // 38
  }                                                                                              // 39
                                                                                                 //
  res.setHeader('Content-Type', 'application/json');                                             // 41
  res.setHeader('Content-Disposition', 'attachment; filename=backup.orionexport');               // 42
  var json = JSON.stringify(data);                                                               // 44
  res.end(json);                                                                                 // 45
});                                                                                              // 46
Picker.route('/admin/download-export/:key', function (params, req, res, next) {                  // 48
  var userId = Roles.keys.getUserId(params.key);                                                 // 49
                                                                                                 //
  if (!userId || !Roles.userHasPermission(userId, 'nicolaslopezj.orionExport')) {                // 50
    throw new Meteor.Error('unauthorized', 'The user is not authorized to perform this action');
  }                                                                                              // 52
                                                                                                 //
  var data = {};                                                                                 // 54
  data.dictionary = orion.dictionary.findOne();                                                  // 56
                                                                                                 //
  if (exportPages) {                                                                             // 57
    data.pages = pages.find().fetch();                                                           // 58
  }                                                                                              // 59
                                                                                                 //
  data.collections = {};                                                                         // 61
                                                                                                 //
  _.each(collections, function (collection) {                                                    // 63
    data.collections[collection._name] = collection.find().fetch();                              // 64
  });                                                                                            // 65
                                                                                                 //
  res.setHeader('Content-Type', 'application/json');                                             // 67
  res.setHeader('Content-Disposition', 'attachment; filename=backup.orionexport');               // 68
  var json = JSON.stringify(data);                                                               // 70
  res.end(json);                                                                                 // 71
});                                                                                              // 72
Picker.route('/admin/import-data/:key', function (params, req, res, next) {                      // 74
  var userId = Roles.keys.getUserId(params.key);                                                 // 75
                                                                                                 //
  if (!userId || !Roles.userHasPermission(userId, 'nicolaslopezj.orionExport')) {                // 76
    throw new Meteor.Error('unauthorized', 'The user is not authorized to perform this action');
  }                                                                                              // 78
                                                                                                 //
  try {                                                                                          // 80
    var json;                                                                                    // 80
    var data;                                                                                    // 80
    var inserts;                                                                                 // 80
    var Chunk;                                                                                   // 80
    var Locks;                                                                                   // 80
    var collectionData;                                                                          // 80
                                                                                                 //
    (function () {                                                                               // 80
      json = req.body.json;                                                                      // 81
      data = JSON.parse(json);                                                                   // 82
      inserts = 1;                                                                               // 83
                                                                                                 //
      var callback = function (error, response) {                                                // 84
        if (error) {                                                                             // 85
          console.log(error);                                                                    // 86
        } else {                                                                                 // 87
          if (inserts % 20 == 0) {                                                               // 88
            console.log("Document\xA0#" + inserts + " restored...");                             // 89
          }                                                                                      // 90
                                                                                                 //
          inserts++;                                                                             // 92
        }                                                                                        // 93
      }; // import dictionary                                                                    // 94
                                                                                                 //
                                                                                                 //
      orion.dictionary.remove({});                                                               // 97
      console.log('Restoring dictionary...');                                                    // 98
      orion.dictionary.insert(data.dictionary, callback); // import pages                        // 99
                                                                                                 //
      if (exportPages) {                                                                         // 102
        orion.pages.collection.remove({});                                                       // 103
        console.log('Restoring pages...');                                                       // 104
        data.pages.forEach(function (page) {                                                     // 105
          orion.pages.collection.insert(page, callback);                                         // 106
        });                                                                                      // 107
      } // import GridFs                                                                         // 108
      //var Files = new Mongo.Collection('data.files');                                          // 111
                                                                                                 //
                                                                                                 //
      Chunk = new Mongo.Collection('data.chunk');                                                // 112
      Locks = new Mongo.Collection('data.locks'); //Files.remove({});                            // 113
                                                                                                 //
      Chunk.remove({});                                                                          // 116
      Locks.remove({});                                                                          // 117
      console.log('Restoring GridFS...');                                                        // 118
      Files.insert(data.data.files, callback);                                                   // 119
      Chunk.insert(data.data.chunk, callback);                                                   // 120
      Locks.insert(data.data.locks, callback); // import collections                             // 121
                                                                                                 //
      _.each(collections, function (collection) {                                                // 124
        var collectionData = data.collections[collection._name];                                 // 125
        if (_.contains(Options.get('dontImportCollections'), collection._name)) return;          // 126
                                                                                                 //
        if (_.isArray(collectionData)) {                                                         // 128
          if (collection.direct) {                                                               // 129
            collection.direct.remove({});                                                        // 130
          } else {                                                                               // 131
            collection.remove({});                                                               // 132
          }                                                                                      // 133
                                                                                                 //
          console.log("Restoring " + collection._name + "...");                                  // 135
                                                                                                 //
          _.each(collectionData, function (doc) {                                                // 136
            if (collection.direct && collection._c2) {                                           // 137
              collection.direct.insert(doc, {                                                    // 138
                validate: false,                                                                 // 138
                filter: false,                                                                   // 138
                getAutoValues: false,                                                            // 138
                removeEmptyStrings: false                                                        // 138
              }, callback);                                                                      // 138
            } else {                                                                             // 139
              collection.insert(doc, callback);                                                  // 140
            }                                                                                    // 141
          });                                                                                    // 142
        }                                                                                        // 143
      });                                                                                        // 144
                                                                                                 //
      collectionData = null;                                                                     // 146
                                                                                                 //
      if (_.has(data, 'users')) {                                                                // 148
        collectionData = data.users;                                                             // 149
                                                                                                 //
        if (_.isArray(collectionData)) {                                                         // 150
          if (Meteor.users.direct) {                                                             // 151
            Meteor.users.direct.remove({});                                                      // 152
          } else {                                                                               // 153
            Meteor.users.remove({});                                                             // 154
          }                                                                                      // 155
                                                                                                 //
          console.log('Restoring users...');                                                     // 157
                                                                                                 //
          _.each(collectionData, function (doc) {                                                // 158
            if (Meteor.users.direct && Meteor.users._c2) {                                       // 159
              Meteor.users.direct.insert(doc, {                                                  // 160
                validate: false,                                                                 // 160
                filter: false,                                                                   // 160
                getAutoValues: false,                                                            // 160
                removeEmptyStrings: false                                                        // 160
              }, callback);                                                                      // 160
            } else {                                                                             // 161
              Meteor.users.insert(doc, callback);                                                // 162
            }                                                                                    // 163
          });                                                                                    // 164
        }                                                                                        // 165
      }                                                                                          // 166
                                                                                                 //
      if (_.has(data, 'roles')) {                                                                // 168
        collectionData = data.roles;                                                             // 169
                                                                                                 //
        if (_.isArray(collectionData)) {                                                         // 170
          if (Roles._collection) {                                                               // 171
            Roles._collection.remove({});                                                        // 172
                                                                                                 //
            _.each(collectionData, function (doc) {                                              // 173
              Roles._collection.insert(doc);                                                     // 174
            });                                                                                  // 175
          } else {                                                                               // 176
            Roles._oldCollection.remove({});                                                     // 177
                                                                                                 //
            _.each(collectionData, function (doc) {                                              // 178
              Roles._oldCollection.insert(doc);                                                  // 179
            });                                                                                  // 180
          }                                                                                      // 181
        }                                                                                        // 183
      }                                                                                          // 184
    })();                                                                                        // 80
  } catch (e) {                                                                                  // 186
    console.log(e);                                                                              // 187
    throw new Meteor.Error('parse-error', 'Error parsing the file');                             // 188
  }                                                                                              // 189
                                                                                                 //
  res.end('ok');                                                                                 // 191
});                                                                                              // 192
///////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/nicolaslopezj:orion-exporter/exporter.js");
require("./node_modules/meteor/nicolaslopezj:orion-exporter/exporter_server.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nicolaslopezj:orion-exporter'] = {};

})();

//# sourceMappingURL=nicolaslopezj_orion-exporter.js.map
