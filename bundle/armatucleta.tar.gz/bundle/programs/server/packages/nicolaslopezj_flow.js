(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var check = Package.check.check;
var Match = Package.check.Match;
var ValidatedMethod = Package['mdg:validated-method'].ValidatedMethod;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var Picker = Package['meteorhacks:picker'].Picker;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Collection2 = Package['aldeed:collection2-core'].Collection2;

/* Package-scope variables */
var newOrderSchema, newOrder, pack, serialize, validate, PaymentKeys, Payments;

var require = meteorInstall({"node_modules":{"meteor":{"nicolaslopezj:flow":{"main_server.js":["./api/new-order","./collections/payments","./api/config","./api/new-order-schema","./api/confirm",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/nicolaslopezj_flow/main_server.js                                                       //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.export({                                                                                     // 1
  newOrder: function () {                                                                           // 1
    return newOrder;                                                                                // 1
  },                                                                                                // 1
  Payments: function () {                                                                           // 1
    return Payments;                                                                                // 1
  },                                                                                                // 1
  setConfig: function () {                                                                          // 1
    return setConfig;                                                                               // 1
  },                                                                                                // 1
  newOrderSchema: function () {                                                                     // 1
    return newOrderSchema;                                                                          // 1
  }                                                                                                 // 1
});                                                                                                 // 1
var newOrder = void 0;                                                                              // 1
module.import('./api/new-order', {                                                                  // 1
  "default": function (v) {                                                                         // 1
    newOrder = v;                                                                                   // 1
  }                                                                                                 // 1
}, 0);                                                                                              // 1
var Payments = void 0;                                                                              // 1
module.import('./collections/payments', {                                                           // 1
  "default": function (v) {                                                                         // 1
    Payments = v;                                                                                   // 1
  }                                                                                                 // 1
}, 1);                                                                                              // 1
var setConfig = void 0;                                                                             // 1
module.import('./api/config', {                                                                     // 1
  "setConfig": function (v) {                                                                       // 1
    setConfig = v;                                                                                  // 1
  }                                                                                                 // 1
}, 2);                                                                                              // 1
var newOrderSchema = void 0;                                                                        // 1
module.import('./api/new-order-schema', {                                                           // 1
  "default": function (v) {                                                                         // 1
    newOrderSchema = v;                                                                             // 1
  }                                                                                                 // 1
}, 3);                                                                                              // 1
module.import('./api/confirm');                                                                     // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"api":{"config.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/nicolaslopezj_flow/api/config.js                                                        //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.export({                                                                                     // 1
  config: function () {                                                                             // 1
    return config;                                                                                  // 1
  },                                                                                                // 1
  setConfig: function () {                                                                          // 1
    return setConfig;                                                                               // 1
  }                                                                                                 // 1
});                                                                                                 // 1
var config = {                                                                                      // 1
  successUrl: 'http://www.comercio.cl/kpf/exito.php',                                               // 2
  failureUrl: 'http://www.comercio.cl/kpf/fracaso.php',                                             // 3
  paymentUrl: 'http://flow.tuxpan.com/app/kpf/pago.php',                                            // 4
  key: '',                                                                                          // 5
  publicKey: '',                                                                                    // 6
  email: 'emailflow@comercio.com',                                                                  // 7
  paymentTypes: 1,                                                                                  // 8
  integrationType: 'd',                                                                             // 9
  baseUrl: 'http://190.161.223.246:3000/'                                                           // 10
};                                                                                                  // 1
                                                                                                    //
var setConfig = function (newConfig) {                                                              // 13
  return module.runModuleSetters(config = _.extend(config, newConfig));                             // 14
};                                                                                                  // 15
                                                                                                    //
;                                                                                                   // 15
//////////////////////////////////////////////////////////////////////////////////////////////////////

},"confirm.js":["querystring","./validate","fibers","./config",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/nicolaslopezj_flow/api/confirm.js                                                       //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var qs = void 0;                                                                                    // 1
module.import('querystring', {                                                                      // 1
  "default": function (v) {                                                                         // 1
    qs = v;                                                                                         // 1
  }                                                                                                 // 1
}, 0);                                                                                              // 1
var validate = void 0;                                                                              // 1
module.import('./validate', {                                                                       // 1
  "default": function (v) {                                                                         // 1
    validate = v;                                                                                   // 1
  }                                                                                                 // 1
}, 1);                                                                                              // 1
var Fiber = void 0;                                                                                 // 1
module.import('fibers', {                                                                           // 1
  "default": function (v) {                                                                         // 1
    Fiber = v;                                                                                      // 1
  }                                                                                                 // 1
}, 2);                                                                                              // 1
var config = void 0;                                                                                // 1
module.import('./config', {                                                                         // 1
  "config": function (v) {                                                                          // 1
    config = v;                                                                                     // 1
  }                                                                                                 // 1
}, 3);                                                                                              // 1
var post = Picker.filter(function (req, res) {                                                      // 6
  return req.method == 'POST';                                                                      // 7
});                                                                                                 // 8
post.route('/flow-confirm-payment', function (params, request, response, next) {                    // 10
  var body = '';                                                                                    // 12
  request.on('data', function (chunk) {                                                             // 13
    body += chunk;                                                                                  // 14
  });                                                                                               // 15
  request.on('end', function () {                                                                   // 17
    Fiber(function () {                                                                             // 18
      var query = qs.parse(body.split('\n')[3]);                                                    // 19
      var payment = Payments.findOne(query.kpf_orden);                                              // 20
                                                                                                    //
      if (!payment) {                                                                               // 21
        console.log('payment not found');                                                           // 22
        return response.end('payment not found');                                                   // 23
      }                                                                                             // 24
                                                                                                    //
      var error = getError(body.split('\n')[3], query, payment);                                    // 25
      var data = {                                                                                  // 26
        status: error ? 'RECHAZADO' : 'ACEPTADO'                                                    // 26
      };                                                                                            // 26
      var paymentKey = PaymentKeys.findOne({                                                        // 28
        paymentId: payment._id                                                                      // 28
      });                                                                                           // 28
      var key = paymentKey ? paymentKey.keyUsed : config.key;                                       // 29
      data.c = paymentKey ? paymentKey.storeEmail : config.email;                                   // 30
      var packed = pack(data, key);                                                                 // 32
      response.end(packed);                                                                         // 33
    }).run();                                                                                       // 34
  });                                                                                               // 35
});                                                                                                 // 36
                                                                                                    //
var getError = function (input, data, payment) {                                                    // 38
  var error = null;                                                                                 // 39
  if (!payment) return 'Payment not found';                                                         // 40
                                                                                                    //
  if (!data.status) {                                                                               // 41
    error = 'Invalid response status';                                                              // 42
  } else if (!data.s) {                                                                             // 43
    error = 'Invalid response (no signature)';                                                      // 44
  } else if (!data.kpf_orden) {                                                                     // 45
    error = 'Invalid response Orden number';                                                        // 46
  } else if (!data.kpf_monto) {                                                                     // 47
    error = 'Invalid response Amount';                                                              // 48
  } else if (!validate(input.split('&s=')[0], data.s)) {                                            // 49
    error = 'Invalid signature from Flow';                                                          // 50
  } else if (data.status == 'ERROR') {                                                              // 51
    error = data.kpf_error;                                                                         // 52
  } else if (payment.amount !== Number(data.kpf_monto)) {                                           // 53
    error = 'Invalid amount';                                                                       // 54
  } else {                                                                                          // 55
    try {                                                                                           // 56
      var appResponse = config.confirm(payment);                                                    // 57
                                                                                                    //
      if (_.isString(appResponse)) {                                                                // 58
        error = appResponse;                                                                        // 59
      } else if (appResponse !== true) {                                                            // 60
        error = 'App declined payment';                                                             // 61
      }                                                                                             // 62
    } catch (e) {                                                                                   // 63
      console.log('Error', e);                                                                      // 64
      error = 'App error confirming payment';                                                       // 65
    }                                                                                               // 66
  }                                                                                                 // 67
                                                                                                    //
  if (error) {                                                                                      // 69
    Payments.update(payment._id, {                                                                  // 70
      $set: {                                                                                       // 70
        status: 'error',                                                                            // 70
        error: error                                                                                // 70
      }                                                                                             // 70
    });                                                                                             // 70
    return error;                                                                                   // 71
  } else {                                                                                          // 72
    Payments.update(payment._id, {                                                                  // 73
      $set: {                                                                                       // 73
        status: 'success'                                                                           // 73
      }                                                                                             // 73
    });                                                                                             // 73
  }                                                                                                 // 74
};                                                                                                  // 75
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"new-order-schema.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/nicolaslopezj_flow/api/new-order-schema.js                                              //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.export("default", exports.default = newOrderSchema = new SimpleSchema({                      // 1
  amount: {                                                                                         // 2
    type: Number                                                                                    // 3
  },                                                                                                // 2
  description: {                                                                                    // 5
    type: String                                                                                    // 6
  },                                                                                                // 5
  buyerEmail: {                                                                                     // 8
    type: String,                                                                                   // 9
    optional: true,                                                                                 // 10
    regEx: SimpleSchema.RegEx.Email                                                                 // 11
  },                                                                                                // 8
  paymentType: {                                                                                    // 13
    type: Number,                                                                                   // 14
    allowedValues: [1, 2, 9],                                                                       // 15
    optional: true                                                                                  // 16
  },                                                                                                // 13
  successUrl: {                                                                                     // 18
    type: String                                                                                    // 19
  },                                                                                                // 18
  failureUrl: {                                                                                     // 21
    type: String                                                                                    // 22
  },                                                                                                // 21
  meta: {                                                                                           // 24
    type: Object,                                                                                   // 25
    blackbox: true,                                                                                 // 26
    optional: true                                                                                  // 27
  },                                                                                                // 24
  key: {                                                                                            // 29
    type: String,                                                                                   // 30
    optional: true                                                                                  // 31
  },                                                                                                // 29
  storeEmail: {                                                                                     // 33
    type: String,                                                                                   // 34
    optional: true,                                                                                 // 35
    regEx: SimpleSchema.RegEx.Email                                                                 // 36
  }                                                                                                 // 33
}));                                                                                                // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////

},"new-order.js":["meteor/mdg:validated-method","./config","../collections/payments","../collections/keys","./new-order-schema","./pack",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/nicolaslopezj_flow/api/new-order.js                                                     //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var ValidatedMethod = void 0;                                                                       // 1
module.import('meteor/mdg:validated-method', {                                                      // 1
  "ValidatedMethod": function (v) {                                                                 // 1
    ValidatedMethod = v;                                                                            // 1
  }                                                                                                 // 1
}, 0);                                                                                              // 1
var config = void 0;                                                                                // 1
module.import('./config', {                                                                         // 1
  "config": function (v) {                                                                          // 1
    config = v;                                                                                     // 1
  }                                                                                                 // 1
}, 1);                                                                                              // 1
var Payments = void 0;                                                                              // 1
module.import('../collections/payments', {                                                          // 1
  "default": function (v) {                                                                         // 1
    Payments = v;                                                                                   // 1
  }                                                                                                 // 1
}, 2);                                                                                              // 1
var PaymentKeys = void 0;                                                                           // 1
module.import('../collections/keys', {                                                              // 1
  "default": function (v) {                                                                         // 1
    PaymentKeys = v;                                                                                // 1
  }                                                                                                 // 1
}, 3);                                                                                              // 1
var newOrderSchema = void 0;                                                                        // 1
module.import('./new-order-schema', {                                                               // 1
  "default": function (v) {                                                                         // 1
    newOrderSchema = v;                                                                             // 1
  }                                                                                                 // 1
}, 4);                                                                                              // 1
var pack = void 0;                                                                                  // 1
module.import('./pack', {                                                                           // 1
  "default": function (v) {                                                                         // 1
    pack = v;                                                                                       // 1
  }                                                                                                 // 1
}, 5);                                                                                              // 1
                                                                                                    //
var getUrl = function (path, paymentId) {                                                           // 8
  var full = path;                                                                                  // 9
                                                                                                    //
  if (!path.includes('http')) {                                                                     // 10
    full = "" + config.baseUrl + path;                                                              // 11
  }                                                                                                 // 12
                                                                                                    //
  if (full.includes('?')) {                                                                         // 13
    return full + "&p=" + paymentId;                                                                // 14
  } else {                                                                                          // 15
    return full + "?p=" + paymentId;                                                                // 16
  }                                                                                                 // 17
};                                                                                                  // 18
                                                                                                    //
module.export("default", exports.default = newOrder = function (order) {                            // 1
  check(order, newOrderSchema);                                                                     // 21
  var paymentId = Payments.insert({                                                                 // 22
    amount: order.amount,                                                                           // 23
    description: order.description,                                                                 // 24
    buyerEmail: order.buyerEmail,                                                                   // 25
    date: new Date(),                                                                               // 26
    meta: order.meta,                                                                               // 27
    status: 'pending'                                                                               // 28
  });                                                                                               // 22
                                                                                                    //
  if (order.key || order.storeEmail) {                                                              // 31
    PaymentKeys.insert({                                                                            // 32
      paymentId: paymentId,                                                                         // 33
      keyUsed: order.key,                                                                           // 34
      storeEmail: order.storeEmail                                                                  // 35
    });                                                                                             // 32
  }                                                                                                 // 37
                                                                                                    //
  var data = {                                                                                      // 39
    c: order.storeEmail || config.email,                                                            // 40
    oc: paymentId,                                                                                  // 41
    mp: order.paymentType,                                                                          // 42
    m: order.amount,                                                                                // 43
    o: order.description,                                                                           // 44
    ue: getUrl(order.successUrl, paymentId),                                                        // 45
    uf: getUrl(order.failureUrl, paymentId),                                                        // 46
    uc: config.baseUrl + 'flow-confirm-payment',                                                    // 47
    ti: 'd',                                                                                        // 48
    e: order.buyerEmail,                                                                            // 49
    v: 'kit_1_2'                                                                                    // 50
  };                                                                                                // 39
  var packed = pack(data, order.key);                                                               // 52
  return {                                                                                          // 54
    paymentId: paymentId,                                                                           // 54
    pack: packed                                                                                    // 54
  };                                                                                                // 54
});                                                                                                 // 55
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"pack.js":["./config","crypto","./serialize",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/nicolaslopezj_flow/api/pack.js                                                          //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var config = void 0;                                                                                // 1
module.import('./config', {                                                                         // 1
  "config": function (v) {                                                                          // 1
    config = v;                                                                                     // 1
  }                                                                                                 // 1
}, 0);                                                                                              // 1
var crypto = void 0;                                                                                // 1
module.import('crypto', {                                                                           // 1
  "default": function (v) {                                                                         // 1
    crypto = v;                                                                                     // 1
  }                                                                                                 // 1
}, 1);                                                                                              // 1
var serialize = void 0;                                                                             // 1
module.import('./serialize', {                                                                      // 1
  "default": function (v) {                                                                         // 1
    serialize = v;                                                                                  // 1
  }                                                                                                 // 1
}, 2);                                                                                              // 1
module.export("default", exports.default = pack = function (data, key) {                            // 1
  var serialized = serialize(data);                                                                 // 6
  var sign = crypto.createSign('RSA-SHA1');                                                         // 7
  sign.write(serialized);                                                                           // 8
  sign.end();                                                                                       // 9
  var signature = sign.sign(key || config.key, 'base64');                                           // 10
  return serialized + "&s=" + signature;                                                            // 11
});                                                                                                 // 12
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"serialize.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/nicolaslopezj_flow/api/serialize.js                                                     //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.export("default", exports.default = serialize = function (obj) {                             // 1
  var str = [];                                                                                     // 2
                                                                                                    //
  for (var p in meteorBabelHelpers.sanitizeForInObject(obj)) {                                      // 3
    if (obj.hasOwnProperty(p)) {                                                                    // 4
      str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));                           // 5
    }                                                                                               // 6
  }                                                                                                 // 7
                                                                                                    //
  return str.join('&');                                                                             // 8
});                                                                                                 // 9
//////////////////////////////////////////////////////////////////////////////////////////////////////

},"validate.js":["crypto","./config","./serialize",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/nicolaslopezj_flow/api/validate.js                                                      //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var crypto = void 0;                                                                                // 1
module.import('crypto', {                                                                           // 1
  "default": function (v) {                                                                         // 1
    crypto = v;                                                                                     // 1
  }                                                                                                 // 1
}, 0);                                                                                              // 1
var config = void 0;                                                                                // 1
module.import('./config', {                                                                         // 1
  "config": function (v) {                                                                          // 1
    config = v;                                                                                     // 1
  }                                                                                                 // 1
}, 1);                                                                                              // 1
var serialize = void 0;                                                                             // 1
module.import('./serialize', {                                                                      // 1
  "default": function (v) {                                                                         // 1
    serialize = v;                                                                                  // 1
  }                                                                                                 // 1
}, 2);                                                                                              // 1
module.export("default", exports.default = validate = function (raw, signature) {                   // 1
  var verify = crypto.createVerify('RSA-SHA1');                                                     // 6
  verify.write(raw);                                                                                // 7
  verify.end();                                                                                     // 8
  return verify.verify(config.publicKey, signature, 'base64');                                      // 9
});                                                                                                 // 10
//////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"collections":{"keys.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/nicolaslopezj_flow/collections/keys.js                                                  //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.export("default", exports.default = PaymentKeys = new Mongo.Collection('flow_paymentkeys'));
PaymentKeys.attachSchema({                                                                          // 3
  paymentId: {                                                                                      // 4
    type: String                                                                                    // 5
  },                                                                                                // 4
  keyUsed: {                                                                                        // 7
    type: String                                                                                    // 8
  },                                                                                                // 7
  storeEmail: {                                                                                     // 10
    type: String                                                                                    // 11
  }                                                                                                 // 10
});                                                                                                 // 3
//////////////////////////////////////////////////////////////////////////////////////////////////////

},"payments.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/nicolaslopezj_flow/collections/payments.js                                              //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.export("default", exports.default = Payments = new Mongo.Collection('flow_payments'));       // 1
Payments.attachSchema({                                                                             // 3
  amount: {                                                                                         // 4
    type: Number                                                                                    // 5
  },                                                                                                // 4
  description: {                                                                                    // 7
    type: String                                                                                    // 8
  },                                                                                                // 7
  buyerEmail: {                                                                                     // 10
    type: String,                                                                                   // 11
    optional: true,                                                                                 // 12
    regEx: SimpleSchema.RegEx.Email                                                                 // 13
  },                                                                                                // 10
  date: {                                                                                           // 15
    type: Date,                                                                                     // 16
    index: 1                                                                                        // 17
  },                                                                                                // 15
  status: {                                                                                         // 19
    type: String,                                                                                   // 20
    allowedValues: ['pending', 'error', 'success']                                                  // 21
  },                                                                                                // 19
  error: {                                                                                          // 23
    type: String,                                                                                   // 24
    optional: true                                                                                  // 25
  },                                                                                                // 23
  meta: {                                                                                           // 27
    type: Object,                                                                                   // 28
    blackbox: true,                                                                                 // 29
    optional: true                                                                                  // 30
  }                                                                                                 // 27
});                                                                                                 // 3
//////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{"extensions":[".js",".json"]});
var exports = require("./node_modules/meteor/nicolaslopezj:flow/main_server.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nicolaslopezj:flow'] = exports;

})();

//# sourceMappingURL=nicolaslopezj_flow.js.map
