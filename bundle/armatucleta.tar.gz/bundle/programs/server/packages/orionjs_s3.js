(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var orion = Package['orionjs:attributes'].orion;
var Knox = Package['lepozepo:s3'].Knox;
var AWS = Package['lepozepo:s3'].AWS;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var Accounts = Package['accounts-base'].Accounts;
var AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var Collection2 = Package['aldeed:collection2-core'].Collection2;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:s3":{"s3.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
// packages/orionjs_s3/s3.js                                                               //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////
                                                                                           //
if (Meteor.isClient) {                                                                     // 1
  orion.filesystem.providerUpload = function (options, success, failure, progress) {       // 2
    var before = _.pluck(S3.collection.find().fetch(), '_id');                             // 3
                                                                                           //
    S3.upload({                                                                            // 4
      files: options.fileList,                                                             // 5
      path: orion.config.get('AWS_S3_PATH', 'orionjs')                                     // 6
    }, function (error, result) {                                                          // 4
      if (error) {                                                                         // 8
        failure(new Meteor.Error('s3-error', i18n('filesystem.messages.errorUploading')));
      } else {                                                                             // 10
        success(result.secure_url, {                                                       // 11
          s3Path: result.relative_url                                                      // 11
        });                                                                                // 11
      }                                                                                    // 12
                                                                                           //
      S3.collection.remove({});                                                            // 13
    });                                                                                    // 14
                                                                                           //
    var after = _.pluck(S3.collection.find().fetch(), '_id');                              // 15
                                                                                           //
    var difference = _.difference(after, before);                                          // 16
                                                                                           //
    var id = difference.length > 0 ? difference[0] : '';                                   // 17
    Tracker.autorun(function () {                                                          // 19
      var file = S3.collection.findOne(id);                                                // 20
                                                                                           //
      if (file) {                                                                          // 21
        progress(file.percent_uploaded);                                                   // 22
      }                                                                                    // 23
    });                                                                                    // 24
  };                                                                                       // 25
                                                                                           //
  orion.filesystem.providerRemove = function (file, success, failure) {                    // 27
    S3.delete(file.meta.s3Path, function (error, result) {                                 // 28
      if (error) {                                                                         // 29
        failure(new Meteor.Error('s3-error', i18n('filesystem.messages.errorRemoving')));  // 30
      } else {                                                                             // 31
        success();                                                                         // 32
      }                                                                                    // 33
    });                                                                                    // 34
  };                                                                                       // 35
}                                                                                          // 36
                                                                                           //
orion.config.add('AWS_API_KEY', 'aws');                                                    // 38
orion.config.add('AWS_API_SECRET', 'aws');                                                 // 39
orion.config.add('AWS_S3_BUCKET', 'aws');                                                  // 40
orion.config.add('AWS_S3_REGION', 'aws', {                                                 // 41
  optional: true                                                                           // 41
});                                                                                        // 41
orion.config.add('AWS_S3_PATH', 'aws', {                                                   // 42
  optional: true                                                                           // 42
});                                                                                        // 42
                                                                                           //
if (Meteor.isServer) {                                                                     // 44
  S3.config = {                                                                            // 45
    key: orion.config.get('AWS_API_KEY', 'key'),                                           // 46
    secret: orion.config.get('AWS_API_SECRET', 'secret'),                                  // 47
    bucket: orion.config.get('AWS_S3_BUCKET', 'bucket'),                                   // 48
    region: orion.config.get('AWS_S3_REGION', 'us-east-1')                                 // 49
  };                                                                                       // 45
}                                                                                          // 51
/////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/orionjs:s3/s3.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:s3'] = {};

})();

//# sourceMappingURL=orionjs_s3.js.map
