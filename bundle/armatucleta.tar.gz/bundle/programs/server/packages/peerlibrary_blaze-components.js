(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var _ = Package.underscore._;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var EJSON = Package.ejson.EJSON;
var Spacebars = Package.spacebars.Spacebars;
var BaseComponent = Package['peerlibrary:base-component'].BaseComponent;
var BaseComponentDebug = Package['peerlibrary:base-component'].BaseComponentDebug;
var assert = Package['peerlibrary:assert'].assert;
var ReactiveField = Package['peerlibrary:reactive-field'].ReactiveField;
var ComputedField = Package['peerlibrary:computed-field'].ComputedField;
var DataLookup = Package['peerlibrary:data-lookup'].DataLookup;
var HTML = Package.htmljs.HTML;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var __coffeescriptShare, Template, AttributeHandler, ElementAttributesUpdater, BlazeComponent, BlazeComponentDebug;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/template.coffee.js                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template = Blaze.Template;                                                                                             // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/compatibility/templating.js                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* This file is needed to backport this pull request: https://github.com/meteor/meteor/pull/5903
   If it is a copy of templating.js file wrapped into a condition.

   TODO: Remove this file eventually.
 */

if (!Blaze.Template.__checkName) {
  // Packages and apps add templates on to this object.

  /**
   * @summary The class for defining templates
   * @class
   * @instanceName Template.myTemplate
   */
  Template = Blaze.Template;

  var RESERVED_TEMPLATE_NAMES = "__proto__ name".split(" ");

  // Check for duplicate template names and illegal names that won't work.
  Template.__checkName = function (name) {
    // Some names can't be used for Templates. These include:
    //  - Properties Blaze sets on the Template object.
    //  - Properties that some browsers don't let the code to set.
    //    These are specified in RESERVED_TEMPLATE_NAMES.
    if (name in Template || _.contains(RESERVED_TEMPLATE_NAMES, name)) {
      if ((Template[name] instanceof Template) && name !== "body")
        throw new Error("There are multiple templates named '" + name + "'. Each template needs a unique name.");
      throw new Error("This template name is reserved: " + name);
    }
  };

  // XXX COMPAT WITH 0.8.3
  Template.__define__ = function (name, renderFunc) {
    Template.__checkName(name);
    Template[name] = new Template("Template." + name, renderFunc);
    // Exempt packages built pre-0.9.0 from warnings about using old
    // helper syntax, because we can.  It's not very useful to get a
    // warning about someone else's code (like a package on Atmosphere),
    // and this should at least put a bit of a dent in number of warnings
    // that come from packages that haven't been updated lately.
    Template[name]._NOWARN_OLDSTYLE_HELPERS = true;
  };

  // Define a template `Template.body` that renders its
  // `contentRenderFuncs`.  `<body>` tags (of which there may be
  // multiple) will have their contents added to it.

  /**
   * @summary The [template object](#templates_api) representing your `<body>`
   * tag.
   * @locus Client
   */
  Template.body = new Template('body', function () {
    var view = this;
    return _.map(Template.body.contentRenderFuncs, function (func) {
      return func.apply(view);
    });
  });
  Template.body.contentRenderFuncs = []; // array of Blaze.Views
  Template.body.view = null;

  Template.body.addContent = function (renderFunc) {
    Template.body.contentRenderFuncs.push(renderFunc);
  };

  // This function does not use `this` and so it may be called
  // as `Meteor.startup(Template.body.renderIntoDocument)`.
  Template.body.renderToDocument = function () {
    // Only do it once.
    if (Template.body.view)
      return;

    var view = Blaze.render(Template.body, document.body);
    Template.body.view = view;
  };

  // XXX COMPAT WITH 0.9.0
  UI.body = Template.body;

  // XXX COMPAT WITH 0.9.0
  // (<body> tags in packages built with 0.9.0)
  Template.__body__ = Template.body;
  Template.__body__.__contentParts = Template.body.contentViews;
  Template.__body__.__instantiate = Template.body.renderToDocument;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/compatibility/template.dynamic.js                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //

Template.__checkName("__dynamicBackport");
Template["__dynamicBackport"] = new Template("Template.__dynamicBackport", (function() {
  var view = this;
  return [ Blaze.View("lookup:checkContext", function() {
    return Spacebars.mustache(view.lookup("checkContext"));
  }), "\n  ", Blaze.If(function() {
    return Spacebars.call(view.lookup("dataContextPresent"));
  }, function() {
    return [ "\n    ", Spacebars.include(view.lookupTemplate("__dynamicWithDataContext"), function() {
      return Blaze._InOuterTemplateScope(view, function() {
        return Spacebars.include(function() {
          return Spacebars.call(view.templateContentBlock);
        });
      });
    }), "\n  " ];
  }, function() {
    return [ "\n    \n    ", Blaze._TemplateWith(function() {
      return {
        template: Spacebars.call(view.lookup("template")),
        data: Spacebars.call(view.lookup(".."))
      };
    }, function() {
      return Spacebars.include(view.lookupTemplate("__dynamicWithDataContext"), function() {
        return Blaze._InOuterTemplateScope(view, function() {
          return Spacebars.include(function() {
            return Spacebars.call(view.templateContentBlock);
          });
        });
      });
    }), "\n  " ];
  }) ];
}));

Template.__checkName("__dynamicWithDataContextBackport");
Template["__dynamicWithDataContextBackport"] = new Template("Template.__dynamicWithDataContextBackport", (function() {
  var view = this;
  return Spacebars.With(function() {
    return Spacebars.dataMustache(view.lookup("chooseTemplate"), view.lookup("template"));
  }, function() {
    return [ "\n    \n    ", Blaze._TemplateWith(function() {
      return Spacebars.call(Spacebars.dot(view.lookup(".."), "data"));
    }, function() {
      return Spacebars.include(view.lookupTemplate(".."), function() {
        return Blaze._InOuterTemplateScope(view, function() {
          return Spacebars.include(function() {
            return Spacebars.call(view.templateContentBlock);
          });
        });
      });
    }), "\n  " ];
  });
}));

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/compatibility/dynamic.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* This file is needed to backport this pull request: https://github.com/meteor/meteor/pull/5903
   If it is a copy of dynamic.js file wrapped into a condition with renaming of backported templates.

   TODO: Remove this file eventually.
 */

if (!Blaze.Template.__dynamicWithDataContext) {
  Blaze.Template.__dynamicWithDataContext = Blaze.Template.__dynamicWithDataContextBackport;
  Blaze.Template.__dynamicWithDataContext.viewName = 'Template.__dynamicWithDataContext';
  Blaze.Template.__dynamic = Blaze.Template.__dynamicBackport;
  Blaze.Template.__dynamic.viewName = 'Template.__dynamic';

  var Template = Blaze.Template;

  /**
   * @isTemplate true
   * @memberOf Template
   * @function dynamic
   * @summary Choose a template to include dynamically, by name.
   * @locus Templates
   * @param {String} template The name of the template to include.
   * @param {Object} [data] Optional. The data context in which to include the
   * template.
   */

  Template.__dynamicWithDataContext.helpers({
    chooseTemplate: function (name) {
      return Blaze._getTemplate(name, function () {
        return Template.instance();
      });
    }
  });

  Template.__dynamic.helpers({
    dataContextPresent: function () {
      return _.has(this, "data");
    },
    checkContext: function () {
      if (!_.has(this, "template")) {
        throw new Error("Must specify name in the 'template' argument " +
          "to {{> Template.dynamic}}.");
      }

      _.each(this, function (v, k) {
        if (k !== "template" && k !== "data") {
          throw new Error("Invalid argument to {{> Template.dynamic}}: " +
            k);
        }
      });
    }
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/compatibility/lookup.js                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* This file backports Blaze lookup.js from Meteor 1.2 so that required Blaze features to support Blaze
   Components are available also in older Meteor versions.
   It is a copy of lookup.js file from Meteor 1.2 with lexical scope lookup commented out.

   TODO: Remove this file eventually.
 */

// Check if we are not running Meteor 1.2+.
if (! Blaze._getTemplate) {
  // If `x` is a function, binds the value of `this` for that function
  // to the current data context.
  var bindDataContext = function (x) {
    if (typeof x === 'function') {
      return function () {
        var data = Blaze.getData();
        if (data == null)
          data = {};
        return x.apply(data, arguments);
      };
    }
    return x;
  };

  Blaze._getTemplateHelper = function (template, name, tmplInstanceFunc) {
    // XXX COMPAT WITH 0.9.3
    var isKnownOldStyleHelper = false;

    if (template.__helpers.has(name)) {
      var helper = template.__helpers.get(name);
      if (helper === Blaze._OLDSTYLE_HELPER) {
        isKnownOldStyleHelper = true;
      } else if (helper != null) {
        return wrapHelper(bindDataContext(helper), tmplInstanceFunc);
      } else {
        return null;
      }
    }

    // old-style helper
    if (name in template) {
      // Only warn once per helper
      if (!isKnownOldStyleHelper) {
        template.__helpers.set(name, Blaze._OLDSTYLE_HELPER);
        if (!template._NOWARN_OLDSTYLE_HELPERS) {
          Blaze._warn('Assigning helper with `' + template.viewName + '.' +
            name + ' = ...` is deprecated.  Use `' + template.viewName +
            '.helpers(...)` instead.');
        }
      }
      if (template[name] != null) {
        return wrapHelper(bindDataContext(template[name]), tmplInstanceFunc);
      }
    }

    return null;
  };

  var wrapHelper = function (f, templateFunc) {
    // XXX COMPAT WITH METEOR 1.0.3.2
    if (!Blaze.Template._withTemplateInstanceFunc) {
      return Blaze._wrapCatchingExceptions(f, 'template helper');
    }

    if (typeof f !== "function") {
      return f;
    }

    return function () {
      var self = this;
      var args = arguments;

      return Blaze.Template._withTemplateInstanceFunc(templateFunc, function () {
        return Blaze._wrapCatchingExceptions(f, 'template helper').apply(self, args);
      });
    };
  };

  // templateInstance argument is provided to be available for possible
  // alternative implementations of this function by 3rd party packages.
  Blaze._getTemplate = function (name, templateInstance) {
    if ((name in Blaze.Template) && (Blaze.Template[name] instanceof Blaze.Template)) {
      return Blaze.Template[name];
    }
    return null;
  };

  Blaze._getGlobalHelper = function (name, templateInstance) {
    if (Blaze._globalHelpers[name] != null) {
      return wrapHelper(bindDataContext(Blaze._globalHelpers[name]), templateInstance);
    }
    return null;
  };

  Blaze.View.prototype.lookup = function (name, _options) {
    var template = this.template;
    var lookupTemplate = _options && _options.template;
    var helper;
    var binding;
    var boundTmplInstance;
    var foundTemplate;

    if (this.templateInstance) {
      boundTmplInstance = _.bind(this.templateInstance, this);
    }

    // 0. looking up the parent data context with the special "../" syntax
    if (/^\./.test(name)) {
      // starts with a dot. must be a series of dots which maps to an
      // ancestor of the appropriate height.
      if (!/^(\.)+$/.test(name))
        throw new Error("id starting with dot must be a series of dots");

      return Blaze._parentData(name.length - 1, true /*_functionWrapped*/);

    }

    // 1. look up a helper on the current template
    if (template && ((helper = Blaze._getTemplateHelper(template, name, boundTmplInstance)) != null)) {
      return helper;
    }

    // 2. look up a binding by traversing the lexical view hierarchy inside the
    // current template
    /*if (template && (binding = Blaze._lexicalBindingLookup(Blaze.currentView, name)) != null) {
      return binding;
    }*/

    // 3. look up a template by name
    if (lookupTemplate && ((foundTemplate = Blaze._getTemplate(name, boundTmplInstance)) != null)) {
      return foundTemplate;
    }

    // 4. look up a global helper
    if ((helper = Blaze._getGlobalHelper(name, boundTmplInstance)) != null) {
      return helper;
    }

    // 5. look up in a data context
    return function () {
      var isCalledAsFunction = (arguments.length > 0);
      var data = Blaze.getData();
      var x = data && data[name];
      if (!x) {
        if (lookupTemplate) {
          throw new Error("No such template: " + name);
        } else if (isCalledAsFunction) {
          throw new Error("No such function: " + name);
        } /*else if (name.charAt(0) === '@' && ((x === null) ||
          (x === undefined))) {
          // Throw an error if the user tries to use a `@directive`
          // that doesn't exist.  We don't implement all directives
          // from Handlebars, so there's a potential for confusion
          // if we fail silently.  On the other hand, we want to
          // throw late in case some app or package wants to provide
          // a missing directive.
          throw new Error("Unsupported directive: " + name);
        }*/
      }
      if (!data) {
        return null;
      }
      if (typeof x !== 'function') {
        if (isCalledAsFunction) {
          throw new Error("Can't call non-function: " + x);
        }
        return x;
      }
      return x.apply(data, arguments);
    };
  };
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/compatibility/attrs.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* This file is needed to backport this pull request: https://github.com/meteor/meteor/pull/5893
   It is a copy of attrs.js file with the changes from the above pull request merged in.

   TODO: Remove this file eventually.
 */

var jsUrlsAllowed = false;
Blaze._allowJavascriptUrls = function () {
  jsUrlsAllowed = true;
};
Blaze._javascriptUrlsAllowed = function () {
  return jsUrlsAllowed;
};

// An AttributeHandler object is responsible for updating a particular attribute
// of a particular element.  AttributeHandler subclasses implement
// browser-specific logic for dealing with particular attributes across
// different browsers.
//
// To define a new type of AttributeHandler, use
// `var FooHandler = AttributeHandler.extend({ update: function ... })`
// where the `update` function takes arguments `(element, oldValue, value)`.
// The `element` argument is always the same between calls to `update` on
// the same instance.  `oldValue` and `value` are each either `null` or
// a Unicode string of the type that might be passed to the value argument
// of `setAttribute` (i.e. not an HTML string with character references).
// When an AttributeHandler is installed, an initial call to `update` is
// always made with `oldValue = null`.  The `update` method can access
// `this.name` if the AttributeHandler class is a generic one that applies
// to multiple attribute names.
//
// AttributeHandlers can store custom properties on `this`, as long as they
// don't use the names `element`, `name`, `value`, and `oldValue`.
//
// AttributeHandlers can't influence how attributes appear in rendered HTML,
// only how they are updated after materialization as DOM.

AttributeHandler = function (name, value) {
  this.name = name;
  this.value = value;
};
Blaze._AttributeHandler = AttributeHandler;

AttributeHandler.prototype.update = function (element, oldValue, value) {
  if (value === null) {
    if (oldValue !== null)
      element.removeAttribute(this.name);
  } else {
    element.setAttribute(this.name, value);
  }
};

AttributeHandler.extend = function (options) {
  var curType = this;
  var subType = function AttributeHandlerSubtype(/*arguments*/) {
    AttributeHandler.apply(this, arguments);
  };
  subType.prototype = new curType;
  subType.extend = curType.extend;
  if (options)
    _.extend(subType.prototype, options);
  return subType;
};

/// Apply the diff between the attributes of "oldValue" and "value" to "element."
//
// Each subclass must implement a parseValue method which takes a string
// as an input and returns a dict of attributes. The keys of the dict
// are unique identifiers (ie. css properties in the case of styles), and the
// values are the entire attribute which will be injected into the element.
//
// Extended below to support classes, SVG elements and styles.

Blaze._DiffingAttributeHandler = AttributeHandler.extend({
  update: function (element, oldValue, value) {
    if (!this.getCurrentValue || !this.setValue || !this.parseValue)
      throw new Error("Missing methods in subclass of 'DiffingAttributeHandler'");

    var oldAttrsMap = oldValue ? this.parseValue(oldValue) : {};
    var newAttrsMap = value ? this.parseValue(value) : {};

    // the current attributes on the element, which we will mutate.

    var attrString = this.getCurrentValue(element);
    var attrsMap = attrString ? this.parseValue(attrString) : {};

    _.each(_.keys(oldAttrsMap), function (t) {
      if (! (t in newAttrsMap))
        delete attrsMap[t];
    });

    _.each(_.keys(newAttrsMap), function (t) {
      attrsMap[t] = newAttrsMap[t];
    });

    this.setValue(element, _.values(attrsMap).join(' '));
  }
});

var ClassHandler = Blaze._DiffingAttributeHandler.extend({
  // @param rawValue {String}
  getCurrentValue: function (element) {
    return element.className;
  },
  setValue: function (element, className) {
    element.className = className;
  },
  parseValue: function (attrString) {
    var tokens = {};

    _.each(attrString.split(' '), function(token) {
      if (token)
        tokens[token] = token;
    });
    return tokens;
  }
});

var SVGClassHandler = ClassHandler.extend({
  getCurrentValue: function (element) {
    return element.className.baseVal;
  },
  setValue: function (element, className) {
    element.setAttribute('class', className);
  }
});

var StyleHandler = Blaze._DiffingAttributeHandler.extend({
  getCurrentValue: function (element) {
    return element.getAttribute('style');
  },
  setValue: function (element, style) {
    if (style === '') {
      element.removeAttribute('style');
    } else {
      element.setAttribute('style', style);
    }
  },

  // Parse a string to produce a map from property to attribute string.
  //
  // Example:
  // "color:red; foo:12px" produces a token {color: "color:red", foo:"foo:12px"}
  parseValue: function (attrString) {
    var tokens = {};

    // Regex for parsing a css attribute declaration, taken from css-parse:
    // https://github.com/reworkcss/css-parse/blob/7cef3658d0bba872cde05a85339034b187cb3397/index.js#L219
    var regex = /(\*?[-#\/\*\\\w]+(?:\[[0-9a-z_-]+\])?)\s*:\s*(?:\'(?:\\\'|.)*?\'|"(?:\\"|.)*?"|\([^\)]*?\)|[^};])+[;\s]*/g;
    var match = regex.exec(attrString);
    while (match) {
      // match[0] = entire matching string
      // match[1] = css property
      // Prefix the token to prevent conflicts with existing properties.

      // XXX No `String.trim` on Safari 4. Swap out $.trim if we want to
      // remove strong dep on jquery.
      tokens[' ' + match[1]] = match[0].trim ?
        match[0].trim() : $.trim(match[0]);

      match = regex.exec(attrString);
    }

    return tokens;
  }
});

var BooleanHandler = AttributeHandler.extend({
  update: function (element, oldValue, value) {
    var name = this.name;
    if (value == null) {
      if (oldValue != null)
        element[name] = false;
    } else {
      element[name] = true;
    }
  }
});

var DOMPropertyHandler = AttributeHandler.extend({
  update: function (element, oldValue, value) {
    var name = this.name;
    if (value !== element[name])
      element[name] = value;
  }
});

// attributes of the type 'xlink:something' should be set using
// the correct namespace in order to work
var XlinkHandler = AttributeHandler.extend({
  update: function(element, oldValue, value) {
    var NS = 'http://www.w3.org/1999/xlink';
    if (value === null) {
      if (oldValue !== null)
        element.removeAttributeNS(NS, this.name);
    } else {
      element.setAttributeNS(NS, this.name, this.value);
    }
  }
});

// cross-browser version of `instanceof SVGElement`
var isSVGElement = function (elem) {
  return 'ownerSVGElement' in elem;
};

var isUrlAttribute = function (tagName, attrName) {
  // Compiled from http://www.w3.org/TR/REC-html40/index/attributes.html
  // and
  // http://www.w3.org/html/wg/drafts/html/master/index.html#attributes-1
  var urlAttrs = {
    FORM: ['action'],
    BODY: ['background'],
    BLOCKQUOTE: ['cite'],
    Q: ['cite'],
    DEL: ['cite'],
    INS: ['cite'],
    OBJECT: ['classid', 'codebase', 'data', 'usemap'],
    APPLET: ['codebase'],
    A: ['href'],
    AREA: ['href'],
    LINK: ['href'],
    BASE: ['href'],
    IMG: ['longdesc', 'src', 'usemap'],
    FRAME: ['longdesc', 'src'],
    IFRAME: ['longdesc', 'src'],
    HEAD: ['profile'],
    SCRIPT: ['src'],
    INPUT: ['src', 'usemap', 'formaction'],
    BUTTON: ['formaction'],
    BASE: ['href'],
    MENUITEM: ['icon'],
    HTML: ['manifest'],
    VIDEO: ['poster']
  };

  if (attrName === 'itemid') {
    return true;
  }

  var urlAttrNames = urlAttrs[tagName] || [];
  return _.contains(urlAttrNames, attrName);
};

// To get the protocol for a URL, we let the browser normalize it for
// us, by setting it as the href for an anchor tag and then reading out
// the 'protocol' property.
if (Meteor.isClient) {
  var anchorForNormalization = document.createElement('A');
}

var getUrlProtocol = function (url) {
  if (Meteor.isClient) {
    anchorForNormalization.href = url;
    return (anchorForNormalization.protocol || "").toLowerCase();
  } else {
    throw new Error('getUrlProtocol not implemented on the server');
  }
};

// UrlHandler is an attribute handler for all HTML attributes that take
// URL values. It disallows javascript: URLs, unless
// Blaze._allowJavascriptUrls() has been called. To detect javascript:
// urls, we set the attribute on a dummy anchor element and then read
// out the 'protocol' property of the attribute.
var origUpdate = AttributeHandler.prototype.update;
var UrlHandler = AttributeHandler.extend({
  update: function (element, oldValue, value) {
    var self = this;
    var args = arguments;

    if (Blaze._javascriptUrlsAllowed()) {
      origUpdate.apply(self, args);
    } else {
      var isJavascriptProtocol = (getUrlProtocol(value) === "javascript:");
      if (isJavascriptProtocol) {
        Blaze._warn("URLs that use the 'javascript:' protocol are not " +
                    "allowed in URL attribute values. " +
                    "Call Blaze._allowJavascriptUrls() " +
                    "to enable them.");
        origUpdate.apply(self, [element, oldValue, null]);
      } else {
        origUpdate.apply(self, args);
      }
    }
  }
});

// XXX make it possible for users to register attribute handlers!
Blaze._makeAttributeHandler = function (elem, name, value) {
  // generally, use setAttribute but certain attributes need to be set
  // by directly setting a JavaScript property on the DOM element.
  if (name === 'class') {
    if (isSVGElement(elem)) {
      return new SVGClassHandler(name, value);
    } else {
      return new ClassHandler(name, value);
    }
  } else if (name === 'style') {
    return new StyleHandler(name, value);
  } else if ((elem.tagName === 'OPTION' && name === 'selected') ||
             (elem.tagName === 'INPUT' && name === 'checked')) {
    return new BooleanHandler(name, value);
  } else if ((elem.tagName === 'TEXTAREA' || elem.tagName === 'INPUT')
             && name === 'value') {
    // internally, TEXTAREAs tracks their value in the 'value'
    // attribute just like INPUTs.
    return new DOMPropertyHandler(name, value);
  } else if (name.substring(0,6) === 'xlink:') {
    return new XlinkHandler(name.substring(6), value);
  } else if (isUrlAttribute(elem.tagName, name)) {
    return new UrlHandler(name, value);
  } else {
    return new AttributeHandler(name, value);
  }

  // XXX will need one for 'style' on IE, though modern browsers
  // seem to handle setAttribute ok.
};


ElementAttributesUpdater = function (elem) {
  this.elem = elem;
  this.handlers = {};
};

// Update attributes on `elem` to the dictionary `attrs`, whose
// values are strings.
ElementAttributesUpdater.prototype.update = function(newAttrs) {
  var elem = this.elem;
  var handlers = this.handlers;

  for (var k in handlers) {
    if (! _.has(newAttrs, k)) {
      // remove attributes (and handlers) for attribute names
      // that don't exist as keys of `newAttrs` and so won't
      // be visited when traversing it.  (Attributes that
      // exist in the `newAttrs` object but are `null`
      // are handled later.)
      var handler = handlers[k];
      var oldValue = handler.value;
      handler.value = null;
      handler.update(elem, oldValue, null);
      delete handlers[k];
    }
  }

  for (var k in newAttrs) {
    var handler = null;
    var oldValue;
    var value = newAttrs[k];
    if (! _.has(handlers, k)) {
      if (value !== null) {
        // make new handler
        handler = Blaze._makeAttributeHandler(elem, k, value);
        handlers[k] = handler;
        oldValue = null;
      }
    } else {
      handler = handlers[k];
      oldValue = handler.value;
    }
    if (oldValue !== value) {
      handler.value = value;
      handler.update(elem, oldValue, value);
      if (value === null)
        delete handlers[k];
    }
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/compatibility/materializer.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* This file is needed to backport this pull request: https://github.com/meteor/meteor/pull/5893
   It is a copy of the materializer.js file and is needed because it references symbols from attrs.js.

   TODO: Remove this file eventually.
 */

// Turns HTMLjs into DOM nodes and DOMRanges.
//
// - `htmljs`: the value to materialize, which may be any of the htmljs
//   types (Tag, CharRef, Comment, Raw, array, string, boolean, number,
//   null, or undefined) or a View or Template (which will be used to
//   construct a View).
// - `intoArray`: the array of DOM nodes and DOMRanges to push the output
//   into (required)
// - `parentView`: the View we are materializing content for (optional)
// - `_existingWorkStack`: optional argument, only used for recursive
//   calls when there is some other _materializeDOM on the call stack.
//   If _materializeDOM called your function and passed in a workStack,
//   pass it back when you call _materializeDOM (such as from a workStack
//   task).
//
// Returns `intoArray`, which is especially useful if you pass in `[]`.
Blaze._materializeDOM = function (htmljs, intoArray, parentView,
                                  _existingWorkStack) {
  // In order to use fewer stack frames, materializeDOMInner can push
  // tasks onto `workStack`, and they will be popped off
  // and run, last first, after materializeDOMInner returns.  The
  // reason we use a stack instead of a queue is so that we recurse
  // depth-first, doing newer tasks first.
  var workStack = (_existingWorkStack || []);
  materializeDOMInner(htmljs, intoArray, parentView, workStack);

  if (! _existingWorkStack) {
    // We created the work stack, so we are responsible for finishing
    // the work.  Call each "task" function, starting with the top
    // of the stack.
    while (workStack.length) {
      // Note that running task() may push new items onto workStack.
      var task = workStack.pop();
      task();
    }
  }

  return intoArray;
};

var materializeDOMInner = function (htmljs, intoArray, parentView, workStack) {
  if (htmljs == null) {
    // null or undefined
    return;
  }

  switch (typeof htmljs) {
  case 'string': case 'boolean': case 'number':
    intoArray.push(document.createTextNode(String(htmljs)));
    return;
  case 'object':
    if (htmljs.htmljsType) {
      switch (htmljs.htmljsType) {
      case HTML.Tag.htmljsType:
        intoArray.push(materializeTag(htmljs, parentView, workStack));
        return;
      case HTML.CharRef.htmljsType:
        intoArray.push(document.createTextNode(htmljs.str));
        return;
      case HTML.Comment.htmljsType:
        intoArray.push(document.createComment(htmljs.sanitizedValue));
        return;
      case HTML.Raw.htmljsType:
        // Get an array of DOM nodes by using the browser's HTML parser
        // (like innerHTML).
        var nodes = Blaze._DOMBackend.parseHTML(htmljs.value);
        for (var i = 0; i < nodes.length; i++)
          intoArray.push(nodes[i]);
        return;
      }
    } else if (HTML.isArray(htmljs)) {
      for (var i = htmljs.length-1; i >= 0; i--) {
        workStack.push(_.bind(Blaze._materializeDOM, null,
                              htmljs[i], intoArray, parentView, workStack));
      }
      return;
    } else {
      if (htmljs instanceof Blaze.Template) {
        htmljs = htmljs.constructView();
        // fall through to Blaze.View case below
      }
      if (htmljs instanceof Blaze.View) {
        Blaze._materializeView(htmljs, parentView, workStack, intoArray);
        return;
      }
    }
  }

  throw new Error("Unexpected object in htmljs: " + htmljs);
};

var materializeTag = function (tag, parentView, workStack) {
  var tagName = tag.tagName;
  var elem;
  if ((HTML.isKnownSVGElement(tagName) || isSVGAnchor(tag))
      && document.createElementNS) {
    // inline SVG
    elem = document.createElementNS('http://www.w3.org/2000/svg', tagName);
  } else {
    // normal elements
    elem = document.createElement(tagName);
  }

  var rawAttrs = tag.attrs;
  var children = tag.children;
  if (tagName === 'textarea' && tag.children.length &&
      ! (rawAttrs && ('value' in rawAttrs))) {
    // Provide very limited support for TEXTAREA tags with children
    // rather than a "value" attribute.
    // Reactivity in the form of Views nested in the tag's children
    // won't work.  Compilers should compile textarea contents into
    // the "value" attribute of the tag, wrapped in a function if there
    // is reactivity.
    if (typeof rawAttrs === 'function' ||
        HTML.isArray(rawAttrs)) {
      throw new Error("Can't have reactive children of TEXTAREA node; " +
                      "use the 'value' attribute instead.");
    }
    rawAttrs = _.extend({}, rawAttrs || null);
    rawAttrs.value = Blaze._expand(children, parentView);
    children = [];
  }

  if (rawAttrs) {
    var attrUpdater = new ElementAttributesUpdater(elem);
    var updateAttributes = function () {
      var expandedAttrs = Blaze._expandAttributes(rawAttrs, parentView);
      var flattenedAttrs = HTML.flattenAttributes(expandedAttrs);
      var stringAttrs = {};
      for (var attrName in flattenedAttrs) {
        stringAttrs[attrName] = Blaze._toText(flattenedAttrs[attrName],
                                              parentView,
                                              HTML.TEXTMODE.STRING);
      }
      attrUpdater.update(stringAttrs);
    };
    var updaterComputation;
    if (parentView) {
      updaterComputation =
        parentView.autorun(updateAttributes, undefined, 'updater');
    } else {
      updaterComputation = Tracker.nonreactive(function () {
        return Tracker.autorun(function () {
          Tracker._withCurrentView(parentView, updateAttributes);
        });
      });
    }
    Blaze._DOMBackend.Teardown.onElementTeardown(elem, function attrTeardown() {
      updaterComputation.stop();
    });
  }

  if (children.length) {
    var childNodesAndRanges = [];
    // push this function first so that it's done last
    workStack.push(function () {
      for (var i = 0; i < childNodesAndRanges.length; i++) {
        var x = childNodesAndRanges[i];
        if (x instanceof Blaze._DOMRange)
          x.attach(elem);
        else
          elem.appendChild(x);
      }
    });
    // now push the task that calculates childNodesAndRanges
    workStack.push(_.bind(Blaze._materializeDOM, null,
                          children, childNodesAndRanges, parentView,
                          workStack));
  }

  return elem;
};


var isSVGAnchor = function (node) {
  // We generally aren't able to detect SVG <a> elements because
  // if "A" were in our list of known svg element names, then all
  // <a> nodes would be created using
  // `document.createElementNS`. But in the special case of <a
  // xlink:href="...">, we can at least detect that attribute and
  // create an SVG <a> tag in that case.
  //
  // However, we still have a general problem of knowing when to
  // use document.createElementNS and when to use
  // document.createElement; for example, font tags will always
  // be created as SVG elements which can cause other
  // problems. #1977
  return (node.tagName === "a" &&
          node.attrs &&
          node.attrs["xlink:href"] !== undefined);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/lib.coffee.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ComponentsNamespaceReference,                                                                                      // 2
    HTMLJSExpander,                                                                                                    // 2
    REQUIRE_RENDERED_INSTANCE,                                                                                         // 2
    SUPPORTS_REACTIVE_INSTANCE,                                                                                        // 2
    addEvents,                                                                                                         // 2
    argumentsConstructor,                                                                                              // 2
    bindComponent,                                                                                                     // 2
    bindDataContext,                                                                                                   // 2
    callTemplateBaseHooks,                                                                                             // 2
    contentAsFunc,                                                                                                     // 2
    contentAsView,                                                                                                     // 2
    createMatcher,                                                                                                     // 2
    currentViewIfRendering,                                                                                            // 2
    expand,                                                                                                            // 2
    expandView,                                                                                                        // 2
    getTemplateBase,                                                                                                   // 2
    getTemplateInstance,                                                                                               // 2
    getTemplateInstanceFunction,                                                                                       // 2
    method,                                                                                                            // 2
    methodName,                                                                                                        // 2
    originalDot,                                                                                                       // 2
    originalFlattenAttributes,                                                                                         // 2
    originalGetTemplate,                                                                                               // 2
    originalInclude,                                                                                                   // 2
    originalVisitTag,                                                                                                  // 2
    ref,                                                                                                               // 2
    registerFirstCreatedHook,                                                                                          // 2
    registerHooks,                                                                                                     // 2
    templateInstanceToComponent,                                                                                       // 2
    withTemplateInstanceFunc,                                                                                          // 2
    wrapHelper,                                                                                                        // 2
    wrapViewAndTemplate,                                                                                               // 2
    slice = [].slice,                                                                                                  // 2
    extend = function (child, parent) {                                                                                // 2
  for (var key in meteorBabelHelpers.sanitizeForInObject(parent)) {                                                    // 3
    if (hasProp.call(parent, key)) child[key] = parent[key];                                                           // 3
  }                                                                                                                    // 3
                                                                                                                       //
  function ctor() {                                                                                                    // 3
    this.constructor = child;                                                                                          // 3
  }                                                                                                                    // 3
                                                                                                                       //
  ctor.prototype = parent.prototype;                                                                                   // 3
  child.prototype = new ctor();                                                                                        // 3
  child.__super__ = parent.prototype;                                                                                  // 3
  return child;                                                                                                        // 3
},                                                                                                                     // 3
    hasProp = {}.hasOwnProperty,                                                                                       // 2
    indexOf = [].indexOf || function (item) {                                                                          // 2
  for (var i = 0, l = this.length; i < l; i++) {                                                                       // 5
    if (i in this && this[i] === item) return i;                                                                       // 5
  }                                                                                                                    // 5
                                                                                                                       //
  return -1;                                                                                                           // 5
};                                                                                                                     // 5
                                                                                                                       //
createMatcher = function (propertyOrMatcherOrFunction, checkMixins) {                                                  // 2
  var matcher, property;                                                                                               // 3
                                                                                                                       //
  if (_.isString(propertyOrMatcherOrFunction)) {                                                                       // 3
    property = propertyOrMatcherOrFunction;                                                                            // 4
                                                                                                                       //
    propertyOrMatcherOrFunction = function (_this) {                                                                   // 5
      return function (child, parent) {                                                                                // 12
        if (checkMixins && child !== parent && child.getFirstWith) {                                                   // 8
          return !!child.getFirstWith(null, property);                                                                 // 14
        } else {                                                                                                       // 8
          return property in child;                                                                                    // 16
        }                                                                                                              // 17
      };                                                                                                               // 5
    }(this);                                                                                                           // 5
  } else if (!_.isFunction(propertyOrMatcherOrFunction)) {                                                             // 3
    assert(_.isObject(propertyOrMatcherOrFunction));                                                                   // 14
    matcher = propertyOrMatcherOrFunction;                                                                             // 15
                                                                                                                       //
    propertyOrMatcherOrFunction = function (_this) {                                                                   // 16
      return function (child, parent) {                                                                                // 24
        var childWithProperty, value;                                                                                  // 17
                                                                                                                       //
        for (property in meteorBabelHelpers.sanitizeForInObject(matcher)) {                                            // 17
          value = matcher[property];                                                                                   // 27
                                                                                                                       //
          if (checkMixins && child !== parent && child.getFirstWith) {                                                 // 20
            childWithProperty = child.getFirstWith(null, property);                                                    // 21
          } else {                                                                                                     // 20
            if (property in child) {                                                                                   // 23
              childWithProperty = child;                                                                               // 23
            }                                                                                                          // 20
          }                                                                                                            // 34
                                                                                                                       //
          if (!childWithProperty) {                                                                                    // 24
            return false;                                                                                              // 24
          }                                                                                                            // 37
                                                                                                                       //
          if (_.isFunction(childWithProperty[property])) {                                                             // 26
            if (childWithProperty[property]() !== value) {                                                             // 27
              return false;                                                                                            // 27
            }                                                                                                          // 26
          } else {                                                                                                     // 26
            if (childWithProperty[property] !== value) {                                                               // 29
              return false;                                                                                            // 29
            }                                                                                                          // 26
          }                                                                                                            // 46
        }                                                                                                              // 17
                                                                                                                       //
        return true;                                                                                                   // 48
      };                                                                                                               // 16
    }(this);                                                                                                           // 16
  }                                                                                                                    // 51
                                                                                                                       //
  return propertyOrMatcherOrFunction;                                                                                  // 52
};                                                                                                                     // 2
                                                                                                                       //
getTemplateInstance = function (view, skipBlockHelpers) {                                                              // 35
  while (view && !view._templateInstance) {                                                                            // 36
    if (skipBlockHelpers) {                                                                                            // 37
      view = view.parentView;                                                                                          // 38
    } else {                                                                                                           // 37
      view = view.originalParentView || view.parentView;                                                               // 40
    }                                                                                                                  // 61
  }                                                                                                                    // 36
                                                                                                                       //
  return view != null ? view._templateInstance : void 0;                                                               // 63
};                                                                                                                     // 35
                                                                                                                       //
templateInstanceToComponent = function (templateInstanceFunc, skipBlockHelpers) {                                      // 48
  var templateInstance;                                                                                                // 49
  templateInstance = typeof templateInstanceFunc === "function" ? templateInstanceFunc() : void 0;                     // 49
  templateInstance = getTemplateInstance(templateInstance != null ? templateInstance.view : void 0, skipBlockHelpers);
                                                                                                                       //
  while (templateInstance) {                                                                                           // 55
    if ('component' in templateInstance) {                                                                             // 56
      return templateInstance.component;                                                                               // 56
    }                                                                                                                  // 73
                                                                                                                       //
    if (skipBlockHelpers) {                                                                                            // 58
      templateInstance = getTemplateInstance(templateInstance.view.parentView, skipBlockHelpers);                      // 59
    } else {                                                                                                           // 58
      templateInstance = getTemplateInstance(templateInstance.view.originalParentView || templateInstance.view.parentView, skipBlockHelpers);
    }                                                                                                                  // 78
  }                                                                                                                    // 55
                                                                                                                       //
  return null;                                                                                                         // 80
};                                                                                                                     // 48
                                                                                                                       //
getTemplateInstanceFunction = function (view, skipBlockHelpers) {                                                      // 65
  var templateInstance;                                                                                                // 66
  templateInstance = getTemplateInstance(view, skipBlockHelpers);                                                      // 66
  return function () {                                                                                                 // 86
    return templateInstance;                                                                                           // 87
  };                                                                                                                   // 67
};                                                                                                                     // 65
                                                                                                                       //
ComponentsNamespaceReference = function () {                                                                           // 70
  function ComponentsNamespaceReference(namespace, templateInstance1) {                                                // 71
    this.namespace = namespace;                                                                                        // 71
    this.templateInstance = templateInstance1;                                                                         // 71
  }                                                                                                                    // 71
                                                                                                                       //
  return ComponentsNamespaceReference;                                                                                 // 97
}();                                                                                                                   // 99
                                                                                                                       //
originalDot = Spacebars.dot;                                                                                           // 75
                                                                                                                       //
Spacebars.dot = function () {                                                                                          // 76
  var args, value;                                                                                                     // 77
  value = arguments[0], args = 2 <= arguments.length ? slice.call(arguments, 1) : [];                                  // 76
                                                                                                                       //
  if (value instanceof ComponentsNamespaceReference) {                                                                 // 77
    return Blaze._getTemplate(value.namespace + "." + args.join('.'), value.templateInstance);                         // 78
  }                                                                                                                    // 108
                                                                                                                       //
  return originalDot.apply(null, [value].concat(slice.call(args)));                                                    // 109
};                                                                                                                     // 76
                                                                                                                       //
originalInclude = Spacebars.include;                                                                                   // 82
                                                                                                                       //
Spacebars.include = function () {                                                                                      // 83
  var args, templateOrFunction;                                                                                        // 88
  templateOrFunction = arguments[0], args = 2 <= arguments.length ? slice.call(arguments, 1) : [];                     // 83
                                                                                                                       //
  if (templateOrFunction instanceof ComponentsNamespaceReference) {                                                    // 88
    templateOrFunction = Blaze._getTemplate(templateOrFunction.namespace, templateOrFunction.templateInstance);        // 89
  }                                                                                                                    // 119
                                                                                                                       //
  return originalInclude.apply(null, [templateOrFunction].concat(slice.call(args)));                                   // 120
};                                                                                                                     // 83
                                                                                                                       //
Blaze._getTemplateHelper = function (template, name, templateInstance) {                                               // 111
  var component, helper, isKnownOldStyleHelper, mixinOrComponent, ref, ref1, ref2;                                     // 112
  isKnownOldStyleHelper = false;                                                                                       // 112
                                                                                                                       //
  if (template.__helpers.has(name)) {                                                                                  // 113
    helper = template.__helpers.get(name);                                                                             // 114
                                                                                                                       //
    if (helper === Blaze._OLDSTYLE_HELPER) {                                                                           // 115
      isKnownOldStyleHelper = true;                                                                                    // 116
    } else if (helper != null) {                                                                                       // 115
      return wrapHelper(bindDataContext(helper), templateInstance);                                                    // 118
    } else {                                                                                                           // 117
      return null;                                                                                                     // 120
    }                                                                                                                  // 113
  }                                                                                                                    // 135
                                                                                                                       //
  if (name in template) {                                                                                              // 123
    if (!isKnownOldStyleHelper) {                                                                                      // 125
      template.__helpers.set(name, Blaze._OLDSTYLE_HELPER);                                                            // 126
                                                                                                                       //
      if (!template._NOWARN_OLDSTYLE_HELPERS) {                                                                        // 127
        Blaze._warn("Assigning helper with `" + template.viewName + "." + name + " = ...` is deprecated.  Use `" + template.viewName + ".helpers(...)` instead.");
      }                                                                                                                // 125
    }                                                                                                                  // 142
                                                                                                                       //
    if (template[name] != null) {                                                                                      // 129
      return wrapHelper(bindDataContext(template[name]), templateInstance);                                            // 130
    } else {                                                                                                           // 129
      return null;                                                                                                     // 132
    }                                                                                                                  // 123
  }                                                                                                                    // 148
                                                                                                                       //
  if (!templateInstance) {                                                                                             // 134
    return null;                                                                                                       // 134
  }                                                                                                                    // 151
                                                                                                                       //
  if ((ref = template.viewName) === 'Template.__dynamicWithDataContext' || ref === 'Template.__dynamic') {             // 140
    return null;                                                                                                       // 140
  }                                                                                                                    // 154
                                                                                                                       //
  component = Tracker.nonreactive(function () {                                                                        // 144
    return templateInstanceToComponent(templateInstance, true);                                                        // 156
  });                                                                                                                  // 144
                                                                                                                       //
  if (component) {                                                                                                     // 150
    if (mixinOrComponent = component.getFirstWith(null, name)) {                                                       // 152
      return wrapHelper(bindComponent(mixinOrComponent, mixinOrComponent[name]), templateInstance);                    // 153
    }                                                                                                                  // 150
  }                                                                                                                    // 162
                                                                                                                       //
  if (name && name in BlazeComponent.components) {                                                                     // 158
    return new ComponentsNamespaceReference(name, templateInstance);                                                   // 159
  }                                                                                                                    // 165
                                                                                                                       //
  if (component) {                                                                                                     // 162
    if ((helper = (ref1 = component._componentInternals) != null ? (ref2 = ref1.templateBase) != null ? ref2.__helpers.get(name) : void 0 : void 0) != null) {
      return wrapHelper(bindDataContext(helper), templateInstance);                                                    // 165
    }                                                                                                                  // 162
  }                                                                                                                    // 170
                                                                                                                       //
  return null;                                                                                                         // 171
};                                                                                                                     // 111
                                                                                                                       //
share.inExpandAttributes = false;                                                                                      // 169
                                                                                                                       //
bindComponent = function (component, helper) {                                                                         // 171
  if (_.isFunction(helper)) {                                                                                          // 172
    return function () {                                                                                               // 178
      var args, name, result, value;                                                                                   // 174
      args = 1 <= arguments.length ? slice.call(arguments, 0) : [];                                                    // 173
      result = helper.apply(component, args);                                                                          // 174
                                                                                                                       //
      if (share.inExpandAttributes && _.isObject(result)) {                                                            // 178
        for (name in meteorBabelHelpers.sanitizeForInObject(result)) {                                                 // 179
          value = result[name];                                                                                        // 184
                                                                                                                       //
          if (share.EVENT_HANDLER_REGEX.test(name)) {                                                                  // 185
            if (_.isFunction(value)) {                                                                                 // 180
              result[name] = _.bind(value, component);                                                                 // 181
            } else if (_.isArray(value)) {                                                                             // 180
              result[name] = _.map(value, function (fun) {                                                             // 183
                if (_.isFunction(fun)) {                                                                               // 184
                  return _.bind(fun, component);                                                                       // 191
                } else {                                                                                               // 184
                  return fun;                                                                                          // 193
                }                                                                                                      // 194
              });                                                                                                      // 183
            }                                                                                                          // 196
          }                                                                                                            // 197
        }                                                                                                              // 178
      }                                                                                                                // 199
                                                                                                                       //
      return result;                                                                                                   // 200
    };                                                                                                                 // 173
  } else {                                                                                                             // 172
    return helper;                                                                                                     // 203
  }                                                                                                                    // 204
};                                                                                                                     // 171
                                                                                                                       //
bindDataContext = function (helper) {                                                                                  // 193
  if (_.isFunction(helper)) {                                                                                          // 194
    return function () {                                                                                               // 209
      var data;                                                                                                        // 196
      data = Blaze.getData();                                                                                          // 196
                                                                                                                       //
      if (data == null) {                                                                                              // 212
        data = {};                                                                                                     // 197
      }                                                                                                                // 214
                                                                                                                       //
      return helper.apply(data, arguments);                                                                            // 215
    };                                                                                                                 // 195
  } else {                                                                                                             // 194
    return helper;                                                                                                     // 218
  }                                                                                                                    // 219
};                                                                                                                     // 193
                                                                                                                       //
wrapHelper = function (f, templateFunc) {                                                                              // 202
  if (!Blaze.Template._withTemplateInstanceFunc) {                                                                     // 204
    return Blaze._wrapCatchingExceptions(f, 'template helper');                                                        // 204
  }                                                                                                                    // 225
                                                                                                                       //
  if (!_.isFunction(f)) {                                                                                              // 206
    return f;                                                                                                          // 206
  }                                                                                                                    // 228
                                                                                                                       //
  return function () {                                                                                                 // 229
    var args, self;                                                                                                    // 209
    self = this;                                                                                                       // 209
    args = arguments;                                                                                                  // 210
    return Blaze.Template._withTemplateInstanceFunc(templateFunc, function () {                                        // 233
      return Blaze._wrapCatchingExceptions(f, 'template helper').apply(self, args);                                    // 234
    });                                                                                                                // 212
  };                                                                                                                   // 208
};                                                                                                                     // 202
                                                                                                                       //
if (Blaze.Template._withTemplateInstanceFunc) {                                                                        // 215
  withTemplateInstanceFunc = Blaze.Template._withTemplateInstanceFunc;                                                 // 216
} else {                                                                                                               // 215
  withTemplateInstanceFunc = function (templateInstance, f) {                                                          // 219
    return f();                                                                                                        // 243
  };                                                                                                                   // 219
}                                                                                                                      // 245
                                                                                                                       //
getTemplateBase = function (component) {                                                                               // 222
  return Tracker.nonreactive(function () {                                                                             // 248
    var componentTemplate, templateBase;                                                                               // 225
    componentTemplate = component.template();                                                                          // 225
                                                                                                                       //
    if (_.isString(componentTemplate)) {                                                                               // 226
      templateBase = Template[componentTemplate];                                                                      // 227
                                                                                                                       //
      if (!templateBase) {                                                                                             // 228
        throw new Error("Template '" + componentTemplate + "' cannot be found.");                                      // 228
      }                                                                                                                // 226
    } else if (componentTemplate) {                                                                                    // 226
      templateBase = componentTemplate;                                                                                // 230
    } else {                                                                                                           // 229
      throw new Error("Template for the component '" + (component.componentName() || 'unnamed') + "' not provided.");  // 232
    }                                                                                                                  // 260
                                                                                                                       //
    return templateBase;                                                                                               // 261
  });                                                                                                                  // 224
};                                                                                                                     // 222
                                                                                                                       //
callTemplateBaseHooks = function (component, hookName) {                                                               // 236
  var callbacks, templateInstance;                                                                                     // 238
                                                                                                                       //
  if (component !== component.component()) {                                                                           // 238
    return;                                                                                                            // 238
  }                                                                                                                    // 269
                                                                                                                       //
  templateInstance = Tracker.nonreactive(function () {                                                                 // 240
    return component._componentInternals.templateInstance();                                                           // 271
  });                                                                                                                  // 240
  callbacks = component._componentInternals.templateBase._getCallbacks(hookName);                                      // 242
                                                                                                                       //
  Template._withTemplateInstanceFunc(function () {                                                                     // 243
    return templateInstance;                                                                                           // 275
  }, function () {                                                                                                     // 243
    var callback, i, len, results;                                                                                     // 248
    results = [];                                                                                                      // 248
                                                                                                                       //
    for (i = 0, len = callbacks.length; i < len; i++) {                                                                // 279
      callback = callbacks[i];                                                                                         // 280
      results.push(callback.call(templateInstance));                                                                   // 281
    }                                                                                                                  // 248
                                                                                                                       //
    return results;                                                                                                    // 283
  });                                                                                                                  // 243
};                                                                                                                     // 236
                                                                                                                       //
wrapViewAndTemplate = function (currentView, f) {                                                                      // 254
  var templateInstance;                                                                                                // 259
  templateInstance = getTemplateInstanceFunction(currentView, true);                                                   // 259
  return withTemplateInstanceFunc(templateInstance, function () {                                                      // 290
    return Blaze._withCurrentView(currentView, function () {                                                           // 291
      return f();                                                                                                      // 292
    });                                                                                                                // 271
  });                                                                                                                  // 265
};                                                                                                                     // 254
                                                                                                                       //
addEvents = function (view, component) {                                                                               // 274
  var eventMap, events, eventsList, fn, handler, i, len, spec;                                                         // 275
  eventsList = component.events();                                                                                     // 275
                                                                                                                       //
  if (!_.isArray(eventsList)) {                                                                                        // 277
    throw new Error("'events' method from the component '" + (component.componentName() || 'unnamed') + "' did not return a list of event maps.");
  }                                                                                                                    // 302
                                                                                                                       //
  for (i = 0, len = eventsList.length; i < len; i++) {                                                                 // 279
    events = eventsList[i];                                                                                            // 304
    eventMap = {};                                                                                                     // 280
                                                                                                                       //
    fn = function (spec, handler) {                                                                                    // 306
      return eventMap[spec] = function () {                                                                            // 307
        var args, currentView, event;                                                                                  // 285
        args = 1 <= arguments.length ? slice.call(arguments, 0) : [];                                                  // 284
        event = args[0];                                                                                               // 285
        currentView = Blaze.getView(event.currentTarget);                                                              // 287
        wrapViewAndTemplate(currentView, function () {                                                                 // 288
          return handler.apply(component, args);                                                                       // 313
        });                                                                                                            // 288
      };                                                                                                               // 284
    };                                                                                                                 // 283
                                                                                                                       //
    for (spec in meteorBabelHelpers.sanitizeForInObject(events)) {                                                     // 282
      handler = events[spec];                                                                                          // 318
      fn(spec, handler);                                                                                               // 319
    }                                                                                                                  // 282
                                                                                                                       //
    Blaze._addEventMap(view, eventMap, view);                                                                          // 295
  }                                                                                                                    // 279
};                                                                                                                     // 274
                                                                                                                       //
originalGetTemplate = Blaze._getTemplate;                                                                              // 299
                                                                                                                       //
Blaze._getTemplate = function (name, templateInstance) {                                                               // 300
  var template;                                                                                                        // 302
  template = Tracker.nonreactive(function () {                                                                         // 302
    var parentComponent, ref;                                                                                          // 303
                                                                                                                       //
    if (Blaze.currentView) {                                                                                           // 303
      parentComponent = BlazeComponent.currentComponent();                                                             // 304
    } else {                                                                                                           // 303
      parentComponent = templateInstanceToComponent(templateInstance, false);                                          // 308
    }                                                                                                                  // 335
                                                                                                                       //
    return (ref = BlazeComponent.getComponent(name)) != null ? ref.renderComponent(parentComponent) : void 0;          // 336
  });                                                                                                                  // 302
                                                                                                                       //
  if (template && (template instanceof Blaze.Template || _.isFunction(template))) {                                    // 311
    return template;                                                                                                   // 311
  }                                                                                                                    // 340
                                                                                                                       //
  return originalGetTemplate(name);                                                                                    // 341
};                                                                                                                     // 300
                                                                                                                       //
registerHooks = function (template, hooks) {                                                                           // 315
  if (template.onCreated) {                                                                                            // 316
    template.onCreated(hooks.onCreated);                                                                               // 317
    template.onRendered(hooks.onRendered);                                                                             // 318
    return template.onDestroyed(hooks.onDestroyed);                                                                    // 348
  } else {                                                                                                             // 316
    template.created = hooks.onCreated;                                                                                // 322
    template.rendered = hooks.onRendered;                                                                              // 323
    return template.destroyed = hooks.onDestroyed;                                                                     // 352
  }                                                                                                                    // 353
};                                                                                                                     // 315
                                                                                                                       //
registerFirstCreatedHook = function (template, onCreated) {                                                            // 326
  var oldCreated;                                                                                                      // 327
                                                                                                                       //
  if (template._callbacks) {                                                                                           // 327
    return template._callbacks.created.unshift(onCreated);                                                             // 359
  } else {                                                                                                             // 327
    oldCreated = template.created;                                                                                     // 331
    return template.created = function () {                                                                            // 362
      onCreated.call(this);                                                                                            // 333
      return oldCreated != null ? oldCreated.call(this) : void 0;                                                      // 364
    };                                                                                                                 // 332
  }                                                                                                                    // 366
};                                                                                                                     // 326
                                                                                                                       //
Template.__dynamicWithDataContext.__helpers.set('chooseTemplate', function (name) {                                    // 343
  return Blaze._getTemplate(name, function (_this) {                                                                   // 370
    return function () {                                                                                               // 371
      return Template.instance();                                                                                      // 372
    };                                                                                                                 // 344
  }(this));                                                                                                            // 344
});                                                                                                                    // 343
                                                                                                                       //
argumentsConstructor = function () {                                                                                   // 347
  return assert(false);                                                                                                // 378
};                                                                                                                     // 347
                                                                                                                       //
Template.registerHelper('args', function () {                                                                          // 353
  var obj;                                                                                                             // 354
  obj = {};                                                                                                            // 354
  obj.constructor = argumentsConstructor;                                                                              // 356
  obj._arguments = arguments;                                                                                          // 357
  return obj;                                                                                                          // 386
});                                                                                                                    // 353
share.EVENT_HANDLER_REGEX = /^on[A-Z]/;                                                                                // 360
                                                                                                                       //
share.isEventHandler = function (fun) {                                                                                // 362
  return _.isFunction(fun) && fun.eventHandler;                                                                        // 392
};                                                                                                                     // 362
                                                                                                                       //
originalFlattenAttributes = HTML.flattenAttributes;                                                                    // 367
                                                                                                                       //
HTML.flattenAttributes = function (attrs) {                                                                            // 368
  var name, value;                                                                                                     // 369
                                                                                                                       //
  if (attrs = originalFlattenAttributes(attrs)) {                                                                      // 369
    for (name in meteorBabelHelpers.sanitizeForInObject(attrs)) {                                                      // 370
      value = attrs[name];                                                                                             // 401
                                                                                                                       //
      if (!share.EVENT_HANDLER_REGEX.test(name)) {                                                                     // 402
        continue;                                                                                                      // 403
      }                                                                                                                // 404
                                                                                                                       //
      if (share.isEventHandler(value)) {                                                                               // 372
        continue;                                                                                                      // 372
      }                                                                                                                // 407
                                                                                                                       //
      if (_.isArray(value) && _.some(value, share.isEventHandler)) {                                                   // 373
        continue;                                                                                                      // 373
      }                                                                                                                // 410
                                                                                                                       //
      if (_.isArray(value)) {                                                                                          // 377
        attrs[name] = _.map(value, Spacebars.event);                                                                   // 378
      } else {                                                                                                         // 377
        attrs[name] = Spacebars.event(value);                                                                          // 380
      }                                                                                                                // 415
    }                                                                                                                  // 369
  }                                                                                                                    // 417
                                                                                                                       //
  return attrs;                                                                                                        // 418
};                                                                                                                     // 368
                                                                                                                       //
Spacebars.event = function () {                                                                                        // 384
  var args, eventHandler, fun;                                                                                         // 385
  eventHandler = arguments[0], args = 2 <= arguments.length ? slice.call(arguments, 1) : [];                           // 384
                                                                                                                       //
  if (!_.isFunction(eventHandler)) {                                                                                   // 385
    throw new Error("Event handler not a function: " + eventHandler);                                                  // 385
  }                                                                                                                    // 426
                                                                                                                       //
  args = Spacebars.mustacheImpl.apply(Spacebars, [function () {                                                        // 388
    var xs;                                                                                                            // 388
    xs = 1 <= arguments.length ? slice.call(arguments, 0) : [];                                                        // 388
    return xs;                                                                                                         // 430
  }].concat(slice.call(args)));                                                                                        // 388
                                                                                                                       //
  fun = function () {                                                                                                  // 390
    var currentView, event, eventArgs;                                                                                 // 391
    event = arguments[0], eventArgs = 2 <= arguments.length ? slice.call(arguments, 1) : [];                           // 390
    currentView = Blaze.getView(event.currentTarget);                                                                  // 391
    return wrapViewAndTemplate(currentView, function () {                                                              // 436
      return eventHandler.apply(null, [event].concat(args, eventArgs));                                                // 437
    });                                                                                                                // 392
  };                                                                                                                   // 390
                                                                                                                       //
  fun.eventHandler = true;                                                                                             // 398
  return fun;                                                                                                          // 441
};                                                                                                                     // 384
                                                                                                                       //
originalVisitTag = HTML.ToHTMLVisitor.prototype.visitTag;                                                              // 403
                                                                                                                       //
HTML.ToHTMLVisitor.prototype.visitTag = function (tag) {                                                               // 404
  var attrs, name;                                                                                                     // 405
                                                                                                                       //
  if (attrs = tag.attrs) {                                                                                             // 405
    attrs = HTML.flattenAttributes(attrs);                                                                             // 406
                                                                                                                       //
    for (name in meteorBabelHelpers.sanitizeForInObject(attrs)) {                                                      // 407
      if (share.EVENT_HANDLER_REGEX.test(name)) {                                                                      // 451
        delete attrs[name];                                                                                            // 408
      }                                                                                                                // 453
    }                                                                                                                  // 407
                                                                                                                       //
    tag.attrs = attrs;                                                                                                 // 409
  }                                                                                                                    // 456
                                                                                                                       //
  return originalVisitTag.call(this, tag);                                                                             // 457
};                                                                                                                     // 404
                                                                                                                       //
currentViewIfRendering = function () {                                                                                 // 413
  var view;                                                                                                            // 414
  view = Blaze.currentView;                                                                                            // 414
                                                                                                                       //
  if (view != null ? view._isInRender : void 0) {                                                                      // 415
    return view;                                                                                                       // 464
  } else {                                                                                                             // 415
    return null;                                                                                                       // 466
  }                                                                                                                    // 467
};                                                                                                                     // 413
                                                                                                                       //
contentAsFunc = function (content) {                                                                                   // 420
  if (!_.isFunction(content)) {                                                                                        // 423
    return function () {                                                                                               // 424
      return content;                                                                                                  // 473
    };                                                                                                                 // 424
  }                                                                                                                    // 475
                                                                                                                       //
  return content;                                                                                                      // 476
};                                                                                                                     // 420
                                                                                                                       //
contentAsView = function (content) {                                                                                   // 429
  if (content instanceof Blaze.Template) {                                                                             // 432
    return content.constructView();                                                                                    // 481
  } else if (content instanceof Blaze.View) {                                                                          // 432
    return content;                                                                                                    // 483
  } else {                                                                                                             // 434
    return Blaze.View('render', contentAsFunc(content));                                                               // 485
  }                                                                                                                    // 486
};                                                                                                                     // 429
                                                                                                                       //
HTMLJSExpander = Blaze._HTMLJSExpander.extend();                                                                       // 439
HTMLJSExpander.def({                                                                                                   // 440
  visitObject: function (x) {                                                                                          // 442
    if (x instanceof Blaze.Template) {                                                                                 // 443
      x = x.constructView();                                                                                           // 444
    }                                                                                                                  // 495
                                                                                                                       //
    if (x instanceof Blaze.View) {                                                                                     // 445
      return expandView(x, this.parentView);                                                                           // 446
    }                                                                                                                  // 498
                                                                                                                       //
    return HTML.TransformingVisitor.prototype.visitObject.call(this, x);                                               // 499
  }                                                                                                                    // 442
});                                                                                                                    // 442
                                                                                                                       //
expand = function (htmljs, parentView) {                                                                               // 451
  parentView = parentView || currentViewIfRendering();                                                                 // 452
  return new HTMLJSExpander({                                                                                          // 505
    parentView: parentView                                                                                             // 454
  }).visit(htmljs);                                                                                                    // 454
};                                                                                                                     // 451
                                                                                                                       //
expandView = function (view, parentView) {                                                                             // 457
  var htmljs, result;                                                                                                  // 458
                                                                                                                       //
  Blaze._createView(view, parentView, true);                                                                           // 458
                                                                                                                       //
  view._isInRender = true;                                                                                             // 460
  htmljs = Blaze._withCurrentView(view, function () {                                                                  // 461
    return view._render();                                                                                             // 515
  });                                                                                                                  // 461
  view._isInRender = false;                                                                                            // 463
  Tracker.flush();                                                                                                     // 465
  result = expand(htmljs, view);                                                                                       // 467
  Tracker.flush();                                                                                                     // 469
                                                                                                                       //
  if (Tracker.active) {                                                                                                // 471
    Tracker.onInvalidate(function () {                                                                                 // 472
      return Blaze._destroyView(view);                                                                                 // 523
    });                                                                                                                // 472
  } else {                                                                                                             // 471
    Blaze._destroyView(view);                                                                                          // 475
  }                                                                                                                    // 527
                                                                                                                       //
  Tracker.flush();                                                                                                     // 477
  return result;                                                                                                       // 529
};                                                                                                                     // 457
                                                                                                                       //
BlazeComponent = function (superClass) {                                                                               // 481
  extend(BlazeComponent, superClass);                                                                                  // 533
                                                                                                                       //
  function BlazeComponent() {                                                                                          // 535
    return BlazeComponent.__super__.constructor.apply(this, arguments);                                                // 536
  }                                                                                                                    // 537
                                                                                                                       //
  BlazeComponent.getComponentForElement = function (domElement) {                                                      // 483
    var templateInstance;                                                                                              // 484
                                                                                                                       //
    if (!domElement) {                                                                                                 // 484
      return null;                                                                                                     // 484
    }                                                                                                                  // 543
                                                                                                                       //
    if (domElement.nodeType !== Node.ELEMENT_NODE) {                                                                   // 487
      throw new Error("Expected DOM element.");                                                                        // 487
    }                                                                                                                  // 546
                                                                                                                       //
    templateInstance = getTemplateInstanceFunction(Blaze.getView(domElement), true);                                   // 493
    return templateInstanceToComponent(templateInstance, true);                                                        // 548
  };                                                                                                                   // 483
                                                                                                                       //
  BlazeComponent.prototype.childComponents = function (nameOrComponent) {                                              // 551
    var component;                                                                                                     // 497
                                                                                                                       //
    if ((component = this.component()) !== this) {                                                                     // 497
      return component.childComponents(nameOrComponent);                                                               // 554
    } else {                                                                                                           // 497
      return BlazeComponent.__super__.childComponents.apply(this, arguments);                                          // 556
    }                                                                                                                  // 557
  };                                                                                                                   // 496
                                                                                                                       //
  BlazeComponent.prototype.childComponentsWith = function (propertyOrMatcherOrFunction) {                              // 560
    var component;                                                                                                     // 505
                                                                                                                       //
    if ((component = this.component()) !== this) {                                                                     // 505
      return component.childComponentsWith(propertyOrMatcherOrFunction);                                               // 563
    } else {                                                                                                           // 505
      assert(propertyOrMatcherOrFunction);                                                                             // 508
      propertyOrMatcherOrFunction = createMatcher(propertyOrMatcherOrFunction, true);                                  // 510
      return BlazeComponent.__super__.childComponentsWith.call(this, propertyOrMatcherOrFunction);                     // 567
    }                                                                                                                  // 568
  };                                                                                                                   // 504
                                                                                                                       //
  BlazeComponent.prototype.parentComponent = function (parentComponent) {                                              // 571
    var component;                                                                                                     // 515
                                                                                                                       //
    if ((component = this.component()) !== this) {                                                                     // 515
      return component.parentComponent(parentComponent);                                                               // 574
    } else {                                                                                                           // 515
      return BlazeComponent.__super__.parentComponent.apply(this, arguments);                                          // 576
    }                                                                                                                  // 577
  };                                                                                                                   // 514
                                                                                                                       //
  BlazeComponent.prototype.addChildComponent = function (childComponent) {                                             // 580
    var component;                                                                                                     // 521
                                                                                                                       //
    if ((component = this.component()) !== this) {                                                                     // 521
      return component.addChildComponent(childComponent);                                                              // 583
    } else {                                                                                                           // 521
      return BlazeComponent.__super__.addChildComponent.apply(this, arguments);                                        // 585
    }                                                                                                                  // 586
  };                                                                                                                   // 520
                                                                                                                       //
  BlazeComponent.prototype.removeChildComponent = function (childComponent) {                                          // 589
    var component;                                                                                                     // 527
                                                                                                                       //
    if ((component = this.component()) !== this) {                                                                     // 527
      return component.removeChildComponent(childComponent);                                                           // 592
    } else {                                                                                                           // 527
      return BlazeComponent.__super__.removeChildComponent.apply(this, arguments);                                     // 594
    }                                                                                                                  // 595
  };                                                                                                                   // 526
                                                                                                                       //
  BlazeComponent.prototype.mixins = function () {                                                                      // 598
    return [];                                                                                                         // 599
  };                                                                                                                   // 532
                                                                                                                       //
  BlazeComponent.prototype.mixinParent = function (mixinParent) {                                                      // 602
    if (this._componentInternals == null) {                                                                            // 603
      this._componentInternals = {};                                                                                   // 539
    }                                                                                                                  // 605
                                                                                                                       //
    if (mixinParent) {                                                                                                 // 542
      this._componentInternals.mixinParent = mixinParent;                                                              // 543
      return this;                                                                                                     // 545
    }                                                                                                                  // 609
                                                                                                                       //
    return this._componentInternals.mixinParent || null;                                                               // 610
  };                                                                                                                   // 538
                                                                                                                       //
  BlazeComponent.prototype.requireMixin = function (nameOrMixin) {                                                     // 613
    var ref;                                                                                                           // 551
    assert((ref = this._componentInternals) != null ? ref.mixins : void 0);                                            // 551
    Tracker.nonreactive(function (_this) {                                                                             // 553
      return function () {                                                                                             // 617
        var base, component, mixinInstance, mixinInstanceComponent, ref1, ref2, ref3;                                  // 556
                                                                                                                       //
        if (_this.getMixin(nameOrMixin)) {                                                                             // 556
          return;                                                                                                      // 556
        }                                                                                                              // 621
                                                                                                                       //
        if (_.isString(nameOrMixin)) {                                                                                 // 558
          if (_this.constructor.getComponent) {                                                                        // 561
            mixinInstanceComponent = _this.constructor.getComponent(nameOrMixin);                                      // 562
          } else {                                                                                                     // 561
            mixinInstanceComponent = BlazeComponent.getComponent(nameOrMixin);                                         // 564
          }                                                                                                            // 627
                                                                                                                       //
          if (!mixinInstanceComponent) {                                                                               // 565
            throw new Error("Unknown mixin '" + nameOrMixin + "'.");                                                   // 565
          }                                                                                                            // 630
                                                                                                                       //
          mixinInstance = new mixinInstanceComponent();                                                                // 566
        } else if (_.isFunction(nameOrMixin)) {                                                                        // 558
          mixinInstance = new nameOrMixin();                                                                           // 568
        } else {                                                                                                       // 567
          mixinInstance = nameOrMixin;                                                                                 // 570
        }                                                                                                              // 636
                                                                                                                       //
        _this._componentInternals.mixins.push(mixinInstance);                                                          // 575
                                                                                                                       //
        if (mixinInstance.mixinParent) {                                                                               // 580
          mixinInstance.mixinParent(_this);                                                                            // 581
        }                                                                                                              // 640
                                                                                                                       //
        if (typeof mixinInstance.createMixins === "function") {                                                        // 641
          mixinInstance.createMixins();                                                                                // 584
        }                                                                                                              // 643
                                                                                                                       //
        if (component = _this.component()) {                                                                           // 586
          if (component._componentInternals == null) {                                                                 // 645
            component._componentInternals = {};                                                                        // 587
          }                                                                                                            // 647
                                                                                                                       //
          if ((base = component._componentInternals).templateInstance == null) {                                       // 648
            base.templateInstance = new ReactiveField(null, function (a, b) {                                          // 649
              return a === b;                                                                                          // 650
            });                                                                                                        // 588
          }                                                                                                            // 652
                                                                                                                       //
          if (!((ref1 = component._componentInternals.templateInstance()) != null ? ref1.view.isDestroyed : void 0)) {
            if (!component._componentInternals.inOnCreated && ((ref2 = component._componentInternals.templateInstance()) != null ? ref2.view.isCreated : void 0)) {
              if (typeof mixinInstance.onCreated === "function") {                                                     // 655
                mixinInstance.onCreated();                                                                             // 595
              }                                                                                                        // 595
            }                                                                                                          // 658
                                                                                                                       //
            if (!component._componentInternals.inOnRendered && ((ref3 = component._componentInternals.templateInstance()) != null ? ref3.view.isRendered : void 0)) {
              return typeof mixinInstance.onRendered === "function" ? mixinInstance.onRendered() : void 0;             // 660
            }                                                                                                          // 594
          }                                                                                                            // 586
        }                                                                                                              // 663
      };                                                                                                               // 553
    }(this));                                                                                                          // 553
    return this;                                                                                                       // 666
  };                                                                                                                   // 550
                                                                                                                       //
  BlazeComponent.prototype.createMixins = function () {                                                                // 669
    var i, len, mixin, ref;                                                                                            // 603
                                                                                                                       //
    if (this._componentInternals == null) {                                                                            // 671
      this._componentInternals = {};                                                                                   // 603
    }                                                                                                                  // 673
                                                                                                                       //
    if (this._componentInternals.mixins) {                                                                             // 606
      return;                                                                                                          // 606
    }                                                                                                                  // 676
                                                                                                                       //
    this._componentInternals.mixins = [];                                                                              // 607
    ref = this.mixins();                                                                                               // 609
                                                                                                                       //
    for (i = 0, len = ref.length; i < len; i++) {                                                                      // 609
      mixin = ref[i];                                                                                                  // 680
      this.requireMixin(mixin);                                                                                        // 610
    }                                                                                                                  // 609
                                                                                                                       //
    return this;                                                                                                       // 683
  };                                                                                                                   // 602
                                                                                                                       //
  BlazeComponent.prototype.getMixin = function (nameOrMixin) {                                                         // 686
    if (_.isString(nameOrMixin)) {                                                                                     // 616
      return this.getFirstWith(this, function (_this) {                                                                // 688
        return function (child, parent) {                                                                              // 689
          var mixinComponentName;                                                                                      // 621
          mixinComponentName = (typeof child.componentName === "function" ? child.componentName() : void 0) || null;   // 621
          return mixinComponentName && mixinComponentName === nameOrMixin;                                             // 622
        };                                                                                                             // 618
      }(this));                                                                                                        // 618
    } else {                                                                                                           // 616
      return this.getFirstWith(this, function (_this) {                                                                // 696
        return function (child, parent) {                                                                              // 697
          if (child.constructor === nameOrMixin) {                                                                     // 627
            return true;                                                                                               // 627
          }                                                                                                            // 700
                                                                                                                       //
          if (child === nameOrMixin) {                                                                                 // 630
            return true;                                                                                               // 630
          }                                                                                                            // 703
                                                                                                                       //
          return false;                                                                                                // 704
        };                                                                                                             // 625
      }(this));                                                                                                        // 625
    }                                                                                                                  // 707
  };                                                                                                                   // 615
                                                                                                                       //
  BlazeComponent.prototype.callFirstWith = function () {                                                               // 710
    var afterComponentOrMixin, args, componentOrMixin, propertyName;                                                   // 637
    afterComponentOrMixin = arguments[0], propertyName = arguments[1], args = 3 <= arguments.length ? slice.call(arguments, 2) : [];
    assert(_.isString(propertyName));                                                                                  // 637
    componentOrMixin = this.getFirstWith(afterComponentOrMixin, propertyName);                                         // 639
                                                                                                                       //
    if (!componentOrMixin) {                                                                                           // 642
      return;                                                                                                          // 642
    }                                                                                                                  // 717
                                                                                                                       //
    if (_.isFunction(componentOrMixin[propertyName])) {                                                                // 646
      return componentOrMixin[propertyName].apply(componentOrMixin, args);                                             // 647
    } else {                                                                                                           // 646
      return componentOrMixin[propertyName];                                                                           // 649
    }                                                                                                                  // 722
  };                                                                                                                   // 636
                                                                                                                       //
  BlazeComponent.prototype.getFirstWith = function (afterComponentOrMixin, propertyOrMatcherOrFunction) {              // 725
    var found, i, len, mixin, ref, ref1;                                                                               // 652
    assert((ref = this._componentInternals) != null ? ref.mixins : void 0);                                            // 652
    assert(propertyOrMatcherOrFunction);                                                                               // 653
    propertyOrMatcherOrFunction = createMatcher(propertyOrMatcherOrFunction, false);                                   // 656
                                                                                                                       //
    if (!afterComponentOrMixin) {                                                                                      // 659
      if (propertyOrMatcherOrFunction.call(this, this, this)) {                                                        // 660
        return this;                                                                                                   // 660
      }                                                                                                                // 733
                                                                                                                       //
      found = true;                                                                                                    // 662
    } else if (afterComponentOrMixin && afterComponentOrMixin === this) {                                              // 659
      found = true;                                                                                                    // 665
    } else {                                                                                                           // 664
      found = false;                                                                                                   // 667
    }                                                                                                                  // 739
                                                                                                                       //
    ref1 = this._componentInternals.mixins;                                                                            // 670
                                                                                                                       //
    for (i = 0, len = ref1.length; i < len; i++) {                                                                     // 670
      mixin = ref1[i];                                                                                                 // 742
                                                                                                                       //
      if (found && propertyOrMatcherOrFunction.call(this, mixin, this)) {                                              // 671
        return mixin;                                                                                                  // 671
      }                                                                                                                // 745
                                                                                                                       //
      if (mixin === afterComponentOrMixin) {                                                                           // 673
        found = true;                                                                                                  // 673
      }                                                                                                                // 748
    }                                                                                                                  // 670
                                                                                                                       //
    return null;                                                                                                       // 750
  };                                                                                                                   // 651
                                                                                                                       //
  BlazeComponent.renderComponent = function (parentComponent) {                                                        // 682
    return Tracker.nonreactive(function (_this) {                                                                      // 754
      return function () {                                                                                             // 755
        var componentClass, data;                                                                                      // 684
        componentClass = _this;                                                                                        // 684
                                                                                                                       //
        if (Blaze.currentView) {                                                                                       // 686
          data = Template.currentData();                                                                               // 692
        } else {                                                                                                       // 686
          data = null;                                                                                                 // 696
        }                                                                                                              // 762
                                                                                                                       //
        if ((data != null ? data.constructor : void 0) !== argumentsConstructor) {                                     // 698
          return wrapViewAndTemplate(Blaze.currentView, function () {                                                  // 701
            var component;                                                                                             // 702
            component = new componentClass();                                                                          // 702
            return component.renderComponent(parentComponent);                                                         // 704
          });                                                                                                          // 701
        }                                                                                                              // 769
                                                                                                                       //
        return function () {                                                                                           // 770
          var currentWith, nonreactiveArguments, reactiveArguments;                                                    // 711
          assert(Tracker.active);                                                                                      // 711
          currentWith = Blaze.getView('with');                                                                         // 716
          reactiveArguments = new ComputedField(function () {                                                          // 723
            data = currentWith.dataVar.get();                                                                          // 724
            assert.equal(data != null ? data.constructor : void 0, argumentsConstructor);                              // 725
            return data._arguments;                                                                                    // 777
          }, EJSON.equals);                                                                                            // 723
          nonreactiveArguments = reactiveArguments();                                                                  // 731
          return Tracker.nonreactive(function () {                                                                     // 780
            var template;                                                                                              // 736
            template = Blaze._withCurrentView(Blaze.currentView.parentView.parentView, function (_this) {              // 736
              return function () {                                                                                     // 783
                return wrapViewAndTemplate(Blaze.currentView, function () {                                            // 739
                  var component;                                                                                       // 741
                                                                                                                       //
                  component = function (func, args, ctor) {                                                            // 741
                    ctor.prototype = func.prototype;                                                                   // 787
                    var child = new ctor(),                                                                            // 788
                        result = func.apply(child, args);                                                              // 788
                    return Object(result) === result ? result : child;                                                 // 789
                  }(componentClass, nonreactiveArguments, function () {});                                             // 790
                                                                                                                       //
                  return component.renderComponent(parentComponent);                                                   // 743
                });                                                                                                    // 739
              };                                                                                                       // 736
            }(this));                                                                                                  // 736
            registerFirstCreatedHook(template, function () {                                                           // 746
              this.view.originalParentView = this.view.parentView;                                                     // 749
              return this.view.parentView = this.view.parentView.parentView.parentView;                                // 797
            });                                                                                                        // 746
            return template;                                                                                           // 799
          });                                                                                                          // 733
        };                                                                                                             // 710
      };                                                                                                               // 683
    }(this));                                                                                                          // 683
  };                                                                                                                   // 682
                                                                                                                       //
  BlazeComponent.prototype.renderComponent = function (parentComponent) {                                              // 806
    return Tracker.nonreactive(function (_this) {                                                                      // 807
      return function () {                                                                                             // 808
        var component, template, templateBase;                                                                         // 760
        component = _this.component();                                                                                 // 760
        component.createMixins();                                                                                      // 763
        templateBase = getTemplateBase(component);                                                                     // 765
        template = new Blaze.Template("BlazeComponent." + (component.componentName() || 'unnamed'), templateBase.renderFunction);
                                                                                                                       //
        if (component._componentInternals == null) {                                                                   // 814
          component._componentInternals = {};                                                                          // 776
        }                                                                                                              // 816
                                                                                                                       //
        component._componentInternals.templateBase = templateBase;                                                     // 777
        registerHooks(template, {                                                                                      // 779
          onCreated: function () {                                                                                     // 780
            var base, base1, base2, base3, componentOrMixin, results;                                                  // 783
                                                                                                                       //
            if (parentComponent) {                                                                                     // 783
              Tracker.nonreactive(function (_this) {                                                                   // 785
                return function () {                                                                                   // 823
                  var ref;                                                                                             // 787
                  assert(!component.parentComponent(), "Component '" + (component.componentName() || 'unnamed') + "' parent component '" + (((ref = component.parentComponent()) != null ? ref.componentName() : void 0) || 'unnamed') + "' already set.");
                  component.parentComponent(parentComponent);                                                          // 790
                  return parentComponent.addChildComponent(component);                                                 // 827
                };                                                                                                     // 785
              }(this));                                                                                                // 785
            }                                                                                                          // 830
                                                                                                                       //
            this.view._onViewRendered(function (_this) {                                                               // 793
              return function () {                                                                                     // 832
                var componentOrMixin, results;                                                                         // 795
                                                                                                                       //
                if (_this.view.renderCount !== 1) {                                                                    // 795
                  return;                                                                                              // 795
                }                                                                                                      // 836
                                                                                                                       //
                componentOrMixin = null;                                                                               // 798
                results = [];                                                                                          // 799
                                                                                                                       //
                while (componentOrMixin = _this.component.getFirstWith(componentOrMixin, 'events')) {                  // 839
                  results.push(addEvents(_this.view, componentOrMixin));                                               // 840
                }                                                                                                      // 799
                                                                                                                       //
                return results;                                                                                        // 842
              };                                                                                                       // 793
            }(this));                                                                                                  // 793
                                                                                                                       //
            this.component = component;                                                                                // 802
            assert(!Tracker.nonreactive(function (_this) {                                                             // 805
              return function () {                                                                                     // 847
                var base;                                                                                              // 805
                return typeof (base = _this.component._componentInternals).templateInstance === "function" ? base.templateInstance() : void 0;
              };                                                                                                       // 805
            }(this)));                                                                                                 // 805
                                                                                                                       //
            if ((base = this.component._componentInternals).templateInstance == null) {                                // 852
              base.templateInstance = new ReactiveField(this, function (a, b) {                                        // 853
                return a === b;                                                                                        // 854
              });                                                                                                      // 807
            }                                                                                                          // 856
                                                                                                                       //
            this.component._componentInternals.templateInstance(this);                                                 // 808
                                                                                                                       //
            if ((base1 = this.component._componentInternals).isCreated == null) {                                      // 858
              base1.isCreated = new ReactiveField(true);                                                               // 859
            }                                                                                                          // 860
                                                                                                                       //
            this.component._componentInternals.isCreated(true);                                                        // 811
                                                                                                                       //
            if ((base2 = this.component._componentInternals).isRendered == null) {                                     // 862
              base2.isRendered = new ReactiveField(false);                                                             // 863
            }                                                                                                          // 864
                                                                                                                       //
            this.component._componentInternals.isRendered(false);                                                      // 816
                                                                                                                       //
            if ((base3 = this.component._componentInternals).isDestroyed == null) {                                    // 866
              base3.isDestroyed = new ReactiveField(false);                                                            // 867
            }                                                                                                          // 868
                                                                                                                       //
            this.component._componentInternals.isDestroyed(false);                                                     // 819
                                                                                                                       //
            try {                                                                                                      // 821
              this.component._componentInternals.inOnCreated = true;                                                   // 826
              componentOrMixin = null;                                                                                 // 827
              results = [];                                                                                            // 828
                                                                                                                       //
              while (componentOrMixin = this.component.getFirstWith(componentOrMixin, 'onCreated')) {                  // 874
                results.push(componentOrMixin.onCreated());                                                            // 875
              }                                                                                                        // 828
                                                                                                                       //
              return results;                                                                                          // 877
            } finally {                                                                                                // 821
              delete this.component._componentInternals.inOnCreated;                                                   // 831
            }                                                                                                          // 880
          },                                                                                                           // 780
          onRendered: function () {                                                                                    // 833
            var base, componentOrMixin, results;                                                                       // 836
                                                                                                                       //
            if ((base = this.component._componentInternals).isRendered == null) {                                      // 884
              base.isRendered = new ReactiveField(true);                                                               // 885
            }                                                                                                          // 886
                                                                                                                       //
            this.component._componentInternals.isRendered(true);                                                       // 837
                                                                                                                       //
            Tracker.nonreactive(function (_this) {                                                                     // 839
              return function () {                                                                                     // 889
                return assert.equal(_this.component._componentInternals.isCreated(), true);                            // 890
              };                                                                                                       // 839
            }(this));                                                                                                  // 839
                                                                                                                       //
            try {                                                                                                      // 842
              this.component._componentInternals.inOnRendered = true;                                                  // 844
              componentOrMixin = null;                                                                                 // 845
              results = [];                                                                                            // 846
                                                                                                                       //
              while (componentOrMixin = this.component.getFirstWith(componentOrMixin, 'onRendered')) {                 // 897
                results.push(componentOrMixin.onRendered());                                                           // 898
              }                                                                                                        // 846
                                                                                                                       //
              return results;                                                                                          // 900
            } finally {                                                                                                // 842
              delete this.component._componentInternals.inOnRendered;                                                  // 849
            }                                                                                                          // 903
          },                                                                                                           // 780
          onDestroyed: function () {                                                                                   // 851
            return this.autorun(function (_this) {                                                                     // 906
              return function (computation) {                                                                          // 907
                if (_this.component.childComponents().length) {                                                        // 857
                  return;                                                                                              // 857
                }                                                                                                      // 910
                                                                                                                       //
                computation.stop();                                                                                    // 858
                return Tracker.nonreactive(function () {                                                               // 912
                  var base, base1, componentOrMixin;                                                                   // 861
                  assert.equal(_this.component._componentInternals.isCreated(), true);                                 // 861
                                                                                                                       //
                  _this.component._componentInternals.isCreated(false);                                                // 863
                                                                                                                       //
                  if ((base = _this.component._componentInternals).isRendered == null) {                               // 916
                    base.isRendered = new ReactiveField(false);                                                        // 917
                  }                                                                                                    // 918
                                                                                                                       //
                  _this.component._componentInternals.isRendered(false);                                               // 866
                                                                                                                       //
                  if ((base1 = _this.component._componentInternals).isDestroyed == null) {                             // 920
                    base1.isDestroyed = new ReactiveField(true);                                                       // 921
                  }                                                                                                    // 922
                                                                                                                       //
                  _this.component._componentInternals.isDestroyed(true);                                               // 869
                                                                                                                       //
                  componentOrMixin = null;                                                                             // 871
                                                                                                                       //
                  while (componentOrMixin = _this.component.getFirstWith(componentOrMixin, 'onDestroyed')) {           // 872
                    componentOrMixin.onDestroyed();                                                                    // 873
                  }                                                                                                    // 872
                                                                                                                       //
                  if (parentComponent) {                                                                               // 875
                    component.parentComponent(null);                                                                   // 877
                    parentComponent.removeChildComponent(component);                                                   // 878
                  }                                                                                                    // 931
                                                                                                                       //
                  return _this.component._componentInternals.templateInstance(null);                                   // 932
                });                                                                                                    // 860
              };                                                                                                       // 852
            }(this));                                                                                                  // 852
          }                                                                                                            // 780
        });                                                                                                            // 780
        return template;                                                                                               // 938
      };                                                                                                               // 759
    }(this));                                                                                                          // 759
  };                                                                                                                   // 754
                                                                                                                       //
  BlazeComponent.prototype.removeComponent = function () {                                                             // 943
    if (this.isRendered()) {                                                                                           // 886
      return Blaze.remove(this.component()._componentInternals.templateInstance().view);                               // 945
    }                                                                                                                  // 946
  };                                                                                                                   // 885
                                                                                                                       //
  BlazeComponent._renderComponentTo = function (visitor, parentComponent, parentView, data) {                          // 888
    var component;                                                                                                     // 889
    component = Tracker.nonreactive(function (_this) {                                                                 // 889
      return function () {                                                                                             // 952
        var componentClass;                                                                                            // 890
        componentClass = _this;                                                                                        // 890
        parentView = parentView || currentViewIfRendering() || (parentComponent != null ? parentComponent.isRendered() : void 0) && parentComponent._componentInternals.templateInstance().view || null;
        return wrapViewAndTemplate(parentView, function () {                                                           // 956
          return new componentClass();                                                                                 // 957
        });                                                                                                            // 894
      };                                                                                                               // 889
    }(this));                                                                                                          // 889
                                                                                                                       //
    if (arguments.length > 2) {                                                                                        // 897
      return component._renderComponentTo(visitor, parentComponent, parentView, data);                                 // 962
    } else {                                                                                                           // 897
      return component._renderComponentTo(visitor, parentComponent, parentView);                                       // 964
    }                                                                                                                  // 965
  };                                                                                                                   // 888
                                                                                                                       //
  BlazeComponent.renderComponentToHTML = function (parentComponent, parentView, data) {                                // 902
    if (arguments.length > 2) {                                                                                        // 903
      return this._renderComponentTo(new HTML.ToHTMLVisitor(), parentComponent, parentView, data);                     // 970
    } else {                                                                                                           // 903
      return this._renderComponentTo(new HTML.ToHTMLVisitor(), parentComponent, parentView);                           // 972
    }                                                                                                                  // 973
  };                                                                                                                   // 902
                                                                                                                       //
  BlazeComponent.prototype._renderComponentTo = function (visitor, parentComponent, parentView, data) {                // 976
    var expandedView, template;                                                                                        // 909
    template = Tracker.nonreactive(function (_this) {                                                                  // 909
      return function () {                                                                                             // 979
        parentView = parentView || currentViewIfRendering() || (parentComponent != null ? parentComponent.isRendered() : void 0) && parentComponent._componentInternals.templateInstance().view || null;
        return wrapViewAndTemplate(parentView, function () {                                                           // 981
          return _this.component().renderComponent(parentComponent);                                                   // 982
        });                                                                                                            // 912
      };                                                                                                               // 909
    }(this));                                                                                                          // 909
                                                                                                                       //
    if (arguments.length > 2) {                                                                                        // 915
      expandedView = expandView(Blaze._TemplateWith(data, contentAsFunc(template)), parentView);                       // 916
    } else {                                                                                                           // 915
      expandedView = expandView(contentAsView(template), parentView);                                                  // 918
    }                                                                                                                  // 990
                                                                                                                       //
    return visitor.visit(expandedView);                                                                                // 991
  };                                                                                                                   // 908
                                                                                                                       //
  BlazeComponent.prototype.renderComponentToHTML = function (parentComponent, parentView, data) {                      // 994
    if (arguments.length > 2) {                                                                                        // 923
      return this._renderComponentTo(new HTML.ToHTMLVisitor(), parentComponent, parentView, data);                     // 996
    } else {                                                                                                           // 923
      return this._renderComponentTo(new HTML.ToHTMLVisitor(), parentComponent, parentView);                           // 998
    }                                                                                                                  // 999
  };                                                                                                                   // 922
                                                                                                                       //
  BlazeComponent.prototype.template = function () {                                                                    // 1002
    return this.callFirstWith(this, 'template') || this.constructor.componentName();                                   // 1003
  };                                                                                                                   // 928
                                                                                                                       //
  BlazeComponent.prototype.onCreated = function () {                                                                   // 1006
    return callTemplateBaseHooks(this, 'created');                                                                     // 1007
  };                                                                                                                   // 931
                                                                                                                       //
  BlazeComponent.prototype.onRendered = function () {                                                                  // 1010
    return callTemplateBaseHooks(this, 'rendered');                                                                    // 1011
  };                                                                                                                   // 934
                                                                                                                       //
  BlazeComponent.prototype.onDestroyed = function () {                                                                 // 1014
    return callTemplateBaseHooks(this, 'destroyed');                                                                   // 1015
  };                                                                                                                   // 937
                                                                                                                       //
  BlazeComponent.prototype.isCreated = function () {                                                                   // 1018
    var base, component;                                                                                               // 941
    component = this.component();                                                                                      // 941
                                                                                                                       //
    if (component._componentInternals == null) {                                                                       // 1021
      component._componentInternals = {};                                                                              // 943
    }                                                                                                                  // 1023
                                                                                                                       //
    if ((base = component._componentInternals).isCreated == null) {                                                    // 1024
      base.isCreated = new ReactiveField(false);                                                                       // 1025
    }                                                                                                                  // 1026
                                                                                                                       //
    return component._componentInternals.isCreated();                                                                  // 1027
  };                                                                                                                   // 940
                                                                                                                       //
  BlazeComponent.prototype.isRendered = function () {                                                                  // 1030
    var base, component;                                                                                               // 949
    component = this.component();                                                                                      // 949
                                                                                                                       //
    if (component._componentInternals == null) {                                                                       // 1033
      component._componentInternals = {};                                                                              // 951
    }                                                                                                                  // 1035
                                                                                                                       //
    if ((base = component._componentInternals).isRendered == null) {                                                   // 1036
      base.isRendered = new ReactiveField(false);                                                                      // 1037
    }                                                                                                                  // 1038
                                                                                                                       //
    return component._componentInternals.isRendered();                                                                 // 1039
  };                                                                                                                   // 948
                                                                                                                       //
  BlazeComponent.prototype.isDestroyed = function () {                                                                 // 1042
    var base, component;                                                                                               // 957
    component = this.component();                                                                                      // 957
                                                                                                                       //
    if (component._componentInternals == null) {                                                                       // 1045
      component._componentInternals = {};                                                                              // 959
    }                                                                                                                  // 1047
                                                                                                                       //
    if ((base = component._componentInternals).isDestroyed == null) {                                                  // 1048
      base.isDestroyed = new ReactiveField(false);                                                                     // 1049
    }                                                                                                                  // 1050
                                                                                                                       //
    return component._componentInternals.isDestroyed();                                                                // 1051
  };                                                                                                                   // 956
                                                                                                                       //
  BlazeComponent.prototype.insertDOMElement = function (parent, node, before) {                                        // 1054
    if (before == null) {                                                                                              // 1055
      before = null;                                                                                                   // 965
    }                                                                                                                  // 1057
                                                                                                                       //
    if (parent && node && (node.parentNode !== parent || node.nextSibling !== before)) {                               // 966
      parent.insertBefore(node, before);                                                                               // 967
    }                                                                                                                  // 1060
  };                                                                                                                   // 964
                                                                                                                       //
  BlazeComponent.prototype.moveDOMElement = function (parent, node, before) {                                          // 1063
    if (before == null) {                                                                                              // 1064
      before = null;                                                                                                   // 972
    }                                                                                                                  // 1066
                                                                                                                       //
    if (parent && node && (node.parentNode !== parent || node.nextSibling !== before)) {                               // 973
      parent.insertBefore(node, before);                                                                               // 974
    }                                                                                                                  // 1069
  };                                                                                                                   // 971
                                                                                                                       //
  BlazeComponent.prototype.removeDOMElement = function (parent, node) {                                                // 1072
    if (parent && node && node.parentNode === parent) {                                                                // 979
      parent.removeChild(node);                                                                                        // 980
    }                                                                                                                  // 1075
  };                                                                                                                   // 978
                                                                                                                       //
  BlazeComponent.prototype.events = function () {                                                                      // 1078
    var eventMap, events, fn, handler, i, len, ref, results, spec, templateInstance, view;                             // 986
                                                                                                                       //
    if (this !== this.component()) {                                                                                   // 986
      return [];                                                                                                       // 986
    }                                                                                                                  // 1082
                                                                                                                       //
    if (this._componentInternals == null) {                                                                            // 1083
      this._componentInternals = {};                                                                                   // 988
    }                                                                                                                  // 1085
                                                                                                                       //
    view = Tracker.nonreactive(function (_this) {                                                                      // 990
      return function () {                                                                                             // 1087
        return _this._componentInternals.templateInstance().view;                                                      // 1088
      };                                                                                                               // 990
    }(this));                                                                                                          // 990
    templateInstance = getTemplateInstanceFunction(view, true);                                                        // 993
    ref = this._componentInternals.templateBase.__eventMaps;                                                           // 995
    results = [];                                                                                                      // 995
                                                                                                                       //
    for (i = 0, len = ref.length; i < len; i++) {                                                                      // 1094
      events = ref[i];                                                                                                 // 1095
      eventMap = {};                                                                                                   // 996
                                                                                                                       //
      fn = function (spec, handler) {                                                                                  // 1097
        return eventMap[spec] = function () {                                                                          // 1098
          var args;                                                                                                    // 1004
          args = 1 <= arguments.length ? slice.call(arguments, 0) : [];                                                // 1000
          return withTemplateInstanceFunc(templateInstance, function () {                                              // 1101
            return Blaze._withCurrentView(view, function () {                                                          // 1102
              return handler.apply(view, args);                                                                        // 1103
            });                                                                                                        // 1005
          });                                                                                                          // 1004
        };                                                                                                             // 1000
      };                                                                                                               // 999
                                                                                                                       //
      for (spec in meteorBabelHelpers.sanitizeForInObject(events)) {                                                   // 998
        handler = events[spec];                                                                                        // 1109
        fn(spec, handler);                                                                                             // 1110
      }                                                                                                                // 998
                                                                                                                       //
      results.push(eventMap);                                                                                          // 1112
    }                                                                                                                  // 995
                                                                                                                       //
    return results;                                                                                                    // 1114
  };                                                                                                                   // 984
                                                                                                                       //
  BlazeComponent.prototype.data = function (path, equalsFunc) {                                                        // 1117
    var base, component, ref, view;                                                                                    // 1015
    component = this.component();                                                                                      // 1015
                                                                                                                       //
    if (component._componentInternals == null) {                                                                       // 1120
      component._componentInternals = {};                                                                              // 1017
    }                                                                                                                  // 1122
                                                                                                                       //
    if ((base = component._componentInternals).templateInstance == null) {                                             // 1123
      base.templateInstance = new ReactiveField(null, function (a, b) {                                                // 1124
        return a === b;                                                                                                // 1125
      });                                                                                                              // 1018
    }                                                                                                                  // 1127
                                                                                                                       //
    if (view = (ref = component._componentInternals.templateInstance()) != null ? ref.view : void 0) {                 // 1020
      if (path != null) {                                                                                              // 1021
        return Blaze._withCurrentView(null, function (_this) {                                                         // 1026
          return function () {                                                                                         // 1131
            return DataLookup.get(function () {                                                                        // 1132
              return Blaze.getData(view);                                                                              // 1133
            }, path, equalsFunc);                                                                                      // 1027
          };                                                                                                           // 1026
        }(this));                                                                                                      // 1026
      } else {                                                                                                         // 1021
        return Blaze.getData(view);                                                                                    // 1032
      }                                                                                                                // 1020
    }                                                                                                                  // 1140
                                                                                                                       //
    return void 0;                                                                                                     // 1141
  };                                                                                                                   // 1014
                                                                                                                       //
  BlazeComponent.currentData = function (path, equalsFunc) {                                                           // 1043
    var currentView;                                                                                                   // 1044
                                                                                                                       //
    if (!Blaze.currentView) {                                                                                          // 1044
      return void 0;                                                                                                   // 1044
    }                                                                                                                  // 1148
                                                                                                                       //
    currentView = Blaze.currentView;                                                                                   // 1046
                                                                                                                       //
    if (_.isString(path)) {                                                                                            // 1048
      path = path.split('.');                                                                                          // 1049
    } else if (!_.isArray(path)) {                                                                                     // 1048
      return Blaze.getData(currentView);                                                                               // 1051
    }                                                                                                                  // 1154
                                                                                                                       //
    return Blaze._withCurrentView(null, function (_this) {                                                             // 1155
      return function () {                                                                                             // 1156
        return DataLookup.get(function () {                                                                            // 1157
          var lexicalData, result;                                                                                     // 1059
                                                                                                                       //
          if (Blaze._lexicalBindingLookup && (lexicalData = Blaze._lexicalBindingLookup(currentView, path[0]))) {      // 1059
            result = {};                                                                                               // 1062
            result[path[0]] = lexicalData;                                                                             // 1063
            return result;                                                                                             // 1064
          }                                                                                                            // 1163
                                                                                                                       //
          return Blaze.getData(currentView);                                                                           // 1164
        }, path, equalsFunc);                                                                                          // 1058
      };                                                                                                               // 1057
    }(this));                                                                                                          // 1057
  };                                                                                                                   // 1043
                                                                                                                       //
  BlazeComponent.prototype.currentData = function (path, equalsFunc) {                                                 // 1170
    return this.constructor.currentData(path, equalsFunc);                                                             // 1171
  };                                                                                                                   // 1071
                                                                                                                       //
  BlazeComponent.prototype.component = function () {                                                                   // 1174
    var component, mixinParent;                                                                                        // 1076
    component = this;                                                                                                  // 1076
                                                                                                                       //
    while (true) {                                                                                                     // 1078
      if (!component.mixinParent) {                                                                                    // 1080
        return null;                                                                                                   // 1080
      }                                                                                                                // 1180
                                                                                                                       //
      if (!(mixinParent = component.mixinParent())) {                                                                  // 1083
        return component;                                                                                              // 1083
      }                                                                                                                // 1183
                                                                                                                       //
      component = mixinParent;                                                                                         // 1084
    }                                                                                                                  // 1078
  };                                                                                                                   // 1075
                                                                                                                       //
  BlazeComponent.currentComponent = function () {                                                                      // 1090
    var templateInstance;                                                                                              // 1093
    templateInstance = getTemplateInstanceFunction(Blaze.currentView, false);                                          // 1093
    return templateInstanceToComponent(templateInstance, false);                                                       // 1191
  };                                                                                                                   // 1090
                                                                                                                       //
  BlazeComponent.prototype.currentComponent = function () {                                                            // 1194
    return this.constructor.currentComponent();                                                                        // 1195
  };                                                                                                                   // 1097
                                                                                                                       //
  BlazeComponent.prototype.firstNode = function () {                                                                   // 1198
    if (this.isRendered()) {                                                                                           // 1101
      return this.component()._componentInternals.templateInstance().view._domrange.firstNode();                       // 1101
    }                                                                                                                  // 1201
                                                                                                                       //
    return void 0;                                                                                                     // 1202
  };                                                                                                                   // 1100
                                                                                                                       //
  BlazeComponent.prototype.lastNode = function () {                                                                    // 1205
    if (this.isRendered()) {                                                                                           // 1106
      return this.component()._componentInternals.templateInstance().view._domrange.lastNode();                        // 1106
    }                                                                                                                  // 1208
                                                                                                                       //
    return void 0;                                                                                                     // 1209
  };                                                                                                                   // 1105
                                                                                                                       //
  BlazeComponent.prototype.autorun = function (runFunc) {                                                              // 1212
    var templateInstance;                                                                                              // 1112
    templateInstance = Tracker.nonreactive(function (_this) {                                                          // 1112
      return function () {                                                                                             // 1215
        var ref;                                                                                                       // 1113
        return (ref = _this.component()._componentInternals) != null ? typeof ref.templateInstance === "function" ? ref.templateInstance() : void 0 : void 0;
      };                                                                                                               // 1112
    }(this));                                                                                                          // 1112
                                                                                                                       //
    if (!templateInstance) {                                                                                           // 1115
      throw new Error("The component has to be created before calling 'autorun'.");                                    // 1115
    }                                                                                                                  // 1222
                                                                                                                       //
    return templateInstance.autorun(_.bind(runFunc, this));                                                            // 1223
  };                                                                                                                   // 1111
                                                                                                                       //
  return BlazeComponent;                                                                                               // 1226
}(BaseComponent);                                                                                                      // 1228
                                                                                                                       //
SUPPORTS_REACTIVE_INSTANCE = ['subscriptionsReady'];                                                                   // 1119
REQUIRE_RENDERED_INSTANCE = ['$', 'find', 'findAll'];                                                                  // 1123
ref = Blaze.TemplateInstance.prototype;                                                                                // 1131
                                                                                                                       //
for (methodName in meteorBabelHelpers.sanitizeForInObject(ref)) {                                                      // 1131
  method = ref[methodName];                                                                                            // 1236
                                                                                                                       //
  if (!(methodName in BlazeComponent.prototype)) {                                                                     // 1237
    (function (methodName, method) {                                                                                   // 1132
      if (indexOf.call(SUPPORTS_REACTIVE_INSTANCE, methodName) >= 0) {                                                 // 1133
        return BlazeComponent.prototype[methodName] = function () {                                                    // 1240
          var args, base, component, templateInstance;                                                                 // 1135
          args = 1 <= arguments.length ? slice.call(arguments, 0) : [];                                                // 1134
          component = this.component();                                                                                // 1135
                                                                                                                       //
          if (component._componentInternals == null) {                                                                 // 1244
            component._componentInternals = {};                                                                        // 1137
          }                                                                                                            // 1246
                                                                                                                       //
          if ((base = component._componentInternals).templateInstance == null) {                                       // 1247
            base.templateInstance = new ReactiveField(null, function (a, b) {                                          // 1248
              return a === b;                                                                                          // 1249
            });                                                                                                        // 1138
          }                                                                                                            // 1251
                                                                                                                       //
          if (templateInstance = component._componentInternals.templateInstance()) {                                   // 1140
            return templateInstance[methodName].apply(templateInstance, args);                                         // 1141
          }                                                                                                            // 1254
                                                                                                                       //
          return void 0;                                                                                               // 1255
        };                                                                                                             // 1134
      } else if (indexOf.call(REQUIRE_RENDERED_INSTANCE, methodName) >= 0) {                                           // 1133
        return BlazeComponent.prototype[methodName] = function () {                                                    // 1258
          var args, ref1;                                                                                              // 1147
          args = 1 <= arguments.length ? slice.call(arguments, 0) : [];                                                // 1146
                                                                                                                       //
          if (this.isRendered()) {                                                                                     // 1147
            return (ref1 = this.component()._componentInternals.templateInstance())[methodName].apply(ref1, args);     // 1147
          }                                                                                                            // 1263
                                                                                                                       //
          return void 0;                                                                                               // 1264
        };                                                                                                             // 1146
      } else {                                                                                                         // 1145
        return BlazeComponent.prototype[methodName] = function () {                                                    // 1267
          var args, templateInstance;                                                                                  // 1153
          args = 1 <= arguments.length ? slice.call(arguments, 0) : [];                                                // 1152
          templateInstance = Tracker.nonreactive(function (_this) {                                                    // 1153
            return function () {                                                                                       // 1271
              var ref1;                                                                                                // 1154
              return (ref1 = _this.component()._componentInternals) != null ? typeof ref1.templateInstance === "function" ? ref1.templateInstance() : void 0 : void 0;
            };                                                                                                         // 1153
          }(this));                                                                                                    // 1153
                                                                                                                       //
          if (!templateInstance) {                                                                                     // 1156
            throw new Error("The component has to be created before calling '" + methodName + "'.");                   // 1156
          }                                                                                                            // 1278
                                                                                                                       //
          return templateInstance[methodName].apply(templateInstance, args);                                           // 1279
        };                                                                                                             // 1152
      }                                                                                                                // 1281
    })(methodName, method);                                                                                            // 1132
  }                                                                                                                    // 1283
}                                                                                                                      // 1131
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/debug.coffee.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function (child, parent) {                                                                                // 1
  for (var key in meteorBabelHelpers.sanitizeForInObject(parent)) {                                                    // 1
    if (hasProp.call(parent, key)) child[key] = parent[key];                                                           // 1
  }                                                                                                                    // 1
                                                                                                                       //
  function ctor() {                                                                                                    // 1
    this.constructor = child;                                                                                          // 1
  }                                                                                                                    // 1
                                                                                                                       //
  ctor.prototype = parent.prototype;                                                                                   // 1
  child.prototype = new ctor();                                                                                        // 1
  child.__super__ = parent.prototype;                                                                                  // 1
  return child;                                                                                                        // 1
},                                                                                                                     // 1
    hasProp = {}.hasOwnProperty,                                                                                       // 1
    indexOf = [].indexOf || function (item) {                                                                          // 1
  for (var i = 0, l = this.length; i < l; i++) {                                                                       // 4
    if (i in this && this[i] === item) return i;                                                                       // 4
  }                                                                                                                    // 4
                                                                                                                       //
  return -1;                                                                                                           // 4
};                                                                                                                     // 4
                                                                                                                       //
BlazeComponentDebug = function (superClass) {                                                                          // 1
  extend(BlazeComponentDebug, superClass);                                                                             // 7
                                                                                                                       //
  function BlazeComponentDebug() {                                                                                     // 9
    return BlazeComponentDebug.__super__.constructor.apply(this, arguments);                                           // 10
  }                                                                                                                    // 11
                                                                                                                       //
  BlazeComponentDebug.startComponent = function (component) {                                                          // 2
    BlazeComponentDebug.__super__.constructor.startComponent.apply(this, arguments);                                   // 3
                                                                                                                       //
    return console.log(component.data());                                                                              // 15
  };                                                                                                                   // 2
                                                                                                                       //
  BlazeComponentDebug.startMarkedComponent = function (component) {                                                    // 7
    BlazeComponentDebug.__super__.constructor.startMarkedComponent.apply(this, arguments);                             // 8
                                                                                                                       //
    return console.log(component.data());                                                                              // 20
  };                                                                                                                   // 7
                                                                                                                       //
  BlazeComponentDebug.dumpComponentSubtree = function (rootComponentOrElement) {                                       // 12
    if ('nodeType' in rootComponentOrElement && rootComponentOrElement.nodeType === Node.ELEMENT_NODE) {               // 13
      rootComponentOrElement = BlazeComponent.getComponentForElement(rootComponentOrElement);                          // 14
    }                                                                                                                  // 26
                                                                                                                       //
    return BlazeComponentDebug.__super__.constructor.dumpComponentSubtree.apply(this, arguments);                      // 27
  };                                                                                                                   // 12
                                                                                                                       //
  BlazeComponentDebug.dumpComponentTree = function (rootComponentOrElement) {                                          // 18
    if ('nodeType' in rootComponentOrElement && rootComponentOrElement.nodeType === Node.ELEMENT_NODE) {               // 19
      rootComponentOrElement = BlazeComponent.getComponentForElement(rootComponentOrElement);                          // 20
    }                                                                                                                  // 33
                                                                                                                       //
    return BlazeComponentDebug.__super__.constructor.dumpComponentTree.apply(this, arguments);                         // 34
  };                                                                                                                   // 18
                                                                                                                       //
  BlazeComponentDebug.dumpAllComponents = function () {                                                                // 24
    var allRootComponents, j, len, rootComponent;                                                                      // 25
    allRootComponents = [];                                                                                            // 25
    $('*').each(function (_this) {                                                                                     // 27
      return function (i, element) {                                                                                   // 41
        var component, rootComponent;                                                                                  // 28
        component = BlazeComponent.getComponentForElement(element);                                                    // 28
                                                                                                                       //
        if (!component) {                                                                                              // 29
          return;                                                                                                      // 29
        }                                                                                                              // 46
                                                                                                                       //
        rootComponent = _this.componentRoot(component);                                                                // 30
                                                                                                                       //
        if (indexOf.call(allRootComponents, rootComponent) < 0) {                                                      // 31
          return allRootComponents.push(rootComponent);                                                                // 49
        }                                                                                                              // 50
      };                                                                                                               // 27
    }(this));                                                                                                          // 27
                                                                                                                       //
    for (j = 0, len = allRootComponents.length; j < len; j++) {                                                        // 33
      rootComponent = allRootComponents[j];                                                                            // 54
      this.dumpComponentSubtree(rootComponent);                                                                        // 34
    }                                                                                                                  // 33
  };                                                                                                                   // 24
                                                                                                                       //
  return BlazeComponentDebug;                                                                                          // 59
}(BaseComponentDebug);                                                                                                 // 61
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/peerlibrary_blaze-components/server.coffee.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Template.body.renderToDocument = function () {};                                                                       // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['peerlibrary:blaze-components'] = {}, {
  Template: Template,
  BlazeComponent: BlazeComponent,
  BlazeComponentDebug: BlazeComponentDebug
});

})();

//# sourceMappingURL=peerlibrary_blaze-components.js.map
