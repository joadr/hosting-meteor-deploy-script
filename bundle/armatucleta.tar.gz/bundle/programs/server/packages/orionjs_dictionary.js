(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var orion = Package['orionjs:base'].orion;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var Collection2 = Package['aldeed:collection2-core'].Collection2;
var HTML = Package.htmljs.HTML;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:dictionary":{"dictionary.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/orionjs_dictionary/dictionary.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Creates the dictionary mongo collection                                                                             //
 */orion.dictionary = new Mongo.Collection('dictionary'); /**                                                          //
                                                           * To get reactively if the dictionary is active             //
                                                           */                                                          //
orion.dictionary._isActiveDependency = new Tracker.Dependency();                                                       // 9
orion.dictionary._isActive = false;                                                                                    // 10
                                                                                                                       //
orion.dictionary.isActive = function () {                                                                              // 11
  this._isActiveDependency.depend();                                                                                   // 12
                                                                                                                       //
  return this._isActive;                                                                                               // 13
}; /**                                                                                                                 // 14
    * Register dictionary actions and helpers for roles                                                                //
    */                                                                                                                 //
                                                                                                                       //
Roles.registerAction('dictionary.update', true);                                                                       // 19
Roles.registerHelper('dictionary.allowedCategories', function () {                                                     // 20
  return orion.dictionary.simpleSchema()._firstLevelSchemaKeys;                                                        // 21
}); /**                                                                                                                // 22
     * Dictionary permissions                                                                                          //
     */                                                                                                                //
orion.dictionary.deny({                                                                                                // 27
  /**                                                                                                                  // 28
   * No one can insert a dicionary object                                                                              //
   * becouse it only uses one and its created                                                                          //
   * automatically                                                                                                     //
   */'insert': function (userId, doc) {                                                                                //
    return true;                                                                                                       // 34
  },                                                                                                                   // 35
  /**                                                                                                                  // 36
   * No one can remove a dicionary object                                                                              //
   * becouse it only uses one.                                                                                         //
   */'remove': function (userId, doc) {                                                                                //
    return true;                                                                                                       // 41
  }                                                                                                                    // 42
});                                                                                                                    // 27
orion.dictionary.allow({                                                                                               // 45
  'update': function (userId, doc, fields, modifier) {                                                                 // 46
    return Roles.allow(userId, 'dictionary.update', userId, doc, fields, modifier);                                    // 47
  }                                                                                                                    // 48
});                                                                                                                    // 45
orion.dictionary.deny({                                                                                                // 51
  'update': function (userId, doc, fields, modifier) {                                                                 // 52
    return Roles.deny(userId, 'dictionary.update', userId, doc, fields, modifier);                                     // 53
  }                                                                                                                    // 54
}); /**                                                                                                                // 51
     * Only allow to edit allowed categories                                                                           //
     * If is set to false, can update all fields                                                                       //
     */                                                                                                                //
orion.dictionary.deny({                                                                                                // 61
  update: function (userId, doc, fields, modifier) {                                                                   // 62
    var allowedFields = _.union.apply(this, Roles.helper(Meteor.userId(), 'dictionary.allowedCategories'));            // 63
                                                                                                                       //
    if (allowedFields === false && _.difference(fields, allowedFields).length > 0) {                                   // 64
      return true;                                                                                                     // 65
    }                                                                                                                  // 66
  }                                                                                                                    // 67
}); /**                                                                                                                // 61
     * Function to add a definition to the dictionary.                                                                 //
     * This just modifies the schema of the dictionary object                                                          //
     * and adds the form in the admin.                                                                                 //
     */                                                                                                                //
                                                                                                                       //
orion.dictionary.addDefinition = function (name, category, attribute) {                                                // 75
  var newSchema = this.simpleSchema() && _.clone(this.simpleSchema()._schema) || {};                                   // 76
  newSchema[category] = newSchema[category] || {                                                                       // 78
    type: Object,                                                                                                      // 79
    optional: true                                                                                                     // 80
  };                                                                                                                   // 78
  newSchema[category + '.' + name] = _.extend({                                                                        // 83
    optional: true                                                                                                     // 84
  }, attribute);                                                                                                       // 83
  this.attachSchema(new SimpleSchema(newSchema));                                                                      // 87
                                                                                                                       //
  if (!this._isActive) {                                                                                               // 89
    this._isActive = true;                                                                                             // 90
                                                                                                                       //
    this._isActiveDependency.changed();                                                                                // 91
  }                                                                                                                    // 92
}; /**                                                                                                                 // 93
    * Returns the value of the definition.                                                                             //
    * If the definition doesn't exists it                                                                              //
    * returns the defaultValue                                                                                         //
    */                                                                                                                 //
                                                                                                                       //
orion.dictionary.get = function (path, defaultValue) {                                                                 // 100
  // Sets empty string to avoid problems on templates                                                                  // 101
  defaultValue = !defaultValue || defaultValue instanceof Spacebars.kw ? undefined : defaultValue;                     // 102
                                                                                                                       //
  if (!defaultValue && orion.dictionary.simpleSchema()) {                                                              // 104
    var def = orion.dictionary.simpleSchema()._schema[path];                                                           // 105
                                                                                                                       //
    if (def && _.has(def, 'defaultValue')) {                                                                           // 106
      defaultValue = _.isFunction(def.defaultValue) ? def.defaultValue() : def.defaultValue;                           // 107
    }                                                                                                                  // 108
  }                                                                                                                    // 109
                                                                                                                       //
  var dictionaryId = Meteor.isServer && process.env.ORION_APPID ? {                                                    // 111
    _id: process.env.ORION_APPID                                                                                       // 111
  } : {};                                                                                                              // 111
  var dictionary = this.findOne(dictionaryId);                                                                         // 112
  return orion.helpers.searchObjectWithDots(dictionary, path) || defaultValue;                                         // 113
};                                                                                                                     // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"admin.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/orionjs_dictionary/admin.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Init the template name variable                                                                                     //
 */ReactiveTemplates.request('dictionaryUpdate'); /**                                                                  //
                                                   * Register the route                                                //
                                                   */                                                                  //
RouterLayer.route('/admin/dictionary', {                                                                               // 9
  layout: 'layout',                                                                                                    // 10
  template: 'dictionaryUpdate',                                                                                        // 11
  name: 'dictionary.update',                                                                                           // 12
  reactiveTemplates: true                                                                                              // 13
}); /**                                                                                                                // 9
     * Ensure user is logged in                                                                                        //
     */                                                                                                                //
orion.accounts.addProtectedRoute('dictionary.update'); /**                                                             // 19
                                                        * Register the link                                            //
                                                        */                                                             //
Tracker.autorun(function () {                                                                                          // 24
  if (!orion.dictionary.isActive() || Meteor.isServer) return;                                                         // 25
  orion.links.add({                                                                                                    // 27
    index: 10,                                                                                                         // 28
    identifier: 'dictionary-update',                                                                                   // 29
    title: i18n('dictionary.update.title'),                                                                            // 30
    routeName: 'dictionary.update',                                                                                    // 31
    activeRouteRegex: 'dictionary',                                                                                    // 32
    permission: 'dictionary.update'                                                                                    // 33
  });                                                                                                                  // 27
}); /**                                                                                                                // 35
     * Create the template helpers for a dictionary                                                                    //
     */                                                                                                                //
                                                                                                                       //
if (Meteor.isClient) {                                                                                                 // 41
  ReactiveTemplates.onRendered('dictionaryUpdate', function () {                                                       // 43
    var defaultCategory = _.first(_.union.apply(this, Roles.helper(Meteor.userId(), 'dictionary.allowedCategories')));
                                                                                                                       //
    Session.set('dictionaryUpdateCurrentCategory', defaultCategory);                                                   // 45
  });                                                                                                                  // 46
  ReactiveTemplates.events('dictionaryUpdate', {                                                                       // 48
    'click [data-category]': function (event) {                                                                        // 49
      var newCategory = $(event.currentTarget).attr('data-category');                                                  // 50
      Session.set('dictionaryUpdateCurrentCategory', newCategory);                                                     // 51
    }                                                                                                                  // 52
  });                                                                                                                  // 48
  ReactiveTemplates.helpers('dictionaryUpdate', {                                                                      // 55
    getDoc: function () {                                                                                              // 56
      return orion.dictionary.findOne();                                                                               // 57
    },                                                                                                                 // 58
    currentCategory: function () {                                                                                     // 59
      return Session.get('dictionaryUpdateCurrentCategory');                                                           // 60
    },                                                                                                                 // 61
    getCategories: function () {                                                                                       // 62
      return _.union.apply(this, Roles.helper(Meteor.userId(), 'dictionary.allowedCategories'));                       // 63
    }                                                                                                                  // 64
  });                                                                                                                  // 55
}                                                                                                                      // 66
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dictionary_server.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/orionjs_dictionary/dictionary_server.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * If its on server, inserts the dictionary object                                                                     //
 */if (orion.dictionary.find(process.env.ORION_APPID ? {                                                               //
  _id: process.env.ORION_APPID                                                                                         // 4
} : {}).count() === 0) {                                                                                               // 4
  // orion.dictionary.remove(process.env.ORION_APPID?{_id:process.env.ORION_APPID}:{});                                // 5
  orion.dictionary.insert(process.env.ORION_APPID ? {                                                                  // 6
    _id: process.env.ORION_APPID                                                                                       // 6
  } : {}, function () {                                                                                                // 6
    console.log("Orion dictionary initialized");                                                                       // 7
  });                                                                                                                  // 8
} /**                                                                                                                  // 9
   * Publications of the dictionary                                                                                    //
   */                                                                                                                  //
                                                                                                                       //
Meteor.publish('orion_dictionary', function () {                                                                       // 14
  return orion.dictionary.find(process.env.ORION_APPID ? {                                                             // 15
    _id: process.env.ORION_APPID                                                                                       // 15
  } : {});                                                                                                             // 15
});                                                                                                                    // 16
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/orionjs:dictionary/dictionary.js");
require("./node_modules/meteor/orionjs:dictionary/admin.js");
require("./node_modules/meteor/orionjs:dictionary/dictionary_server.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['orionjs:dictionary'] = {}, {
  orion: orion
});

})();

//# sourceMappingURL=orionjs_dictionary.js.map
