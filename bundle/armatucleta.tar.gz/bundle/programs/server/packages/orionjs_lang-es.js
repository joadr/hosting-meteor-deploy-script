(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:lang-es":{"es.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// packages/orionjs_lang-es/es.js                                                      //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
i18n.map('es', {                                                                       // 1
  global: {                                                                            // 2
    save: 'Guardar',                                                                   // 3
    create: 'Crear',                                                                   // 4
    logout: 'Salir',                                                                   // 5
    back: 'Atrás',                                                                     // 6
    cancel: 'Cancelar',                                                                // 7
    "delete": 'Borrar',                                                                // 8
    confirm: 'Confirmar',                                                              // 9
    choose: 'Elegir',                                                                  // 10
    noPermission: 'No tienes permisos',                                                // 11
    passwordNotMatch: 'Las contraseñas no son iguales',                                // 12
    optional: 'Opcional'                                                               // 13
  },                                                                                   // 2
  accounts: {                                                                          // 15
    schema: {                                                                          // 16
      emails: {                                                                        // 17
        title: 'Emails',                                                               // 18
        address: 'Dirección',                                                          // 19
        verified: 'Verificado'                                                         // 20
      },                                                                               // 17
      password: {                                                                      // 22
        title: 'Contraseña',                                                           // 23
        "new": 'Nueva Contraseña',                                                     // 24
        confirm: 'Confirmar Contraseña'                                                // 25
      },                                                                               // 22
      profile: {                                                                       // 27
        name: 'Nombre'                                                                 // 28
      }                                                                                // 27
    },                                                                                 // 16
    index: {                                                                           // 31
      title: 'Cuentas',                                                                // 32
      noName: 'Sin Nombre',                                                            // 33
      actions: {                                                                       // 34
        edit: 'Editar',                                                                // 35
        sendEnrollmentEmail: 'Enviar Email de Inscripción'                             // 36
      },                                                                               // 34
      tableTitles: {                                                                   // 38
        name: 'Nombre',                                                                // 39
        services: 'Inicio de Sesión',                                                  // 40
        email: 'Email',                                                                // 41
        roles: 'Roles',                                                                // 42
        actions: 'Acciones'                                                            // 43
      }                                                                                // 38
    },                                                                                 // 31
    update: {                                                                          // 46
      title: 'Editar Cuenta',                                                          // 47
      messages: {                                                                      // 48
        noPermissions: 'No tienes permisos para editar este usuario'                   // 49
      },                                                                               // 48
      sections: {                                                                      // 51
        profile: {                                                                     // 52
          title: 'Perfil'                                                              // 53
        },                                                                             // 52
        roles: {                                                                       // 55
          title: 'Roles',                                                              // 56
          selectRoles: 'Selecciona los roles'                                          // 57
        },                                                                             // 55
        changePassword: {                                                              // 59
          title: 'Cambiar Contraseña'                                                  // 60
        },                                                                             // 59
        deleteUser: {                                                                  // 62
          title: 'Borrar usuario',                                                     // 63
          advice: 'Borrar usuarios puede causar problemas.',                           // 64
          button: 'Borrar Usuario'                                                     // 65
        }                                                                              // 62
      }                                                                                // 51
    },                                                                                 // 46
    myAccount: {                                                                       // 69
      title: 'Mi Cuenta'                                                               // 70
    },                                                                                 // 69
    create: {                                                                          // 72
      title: 'Crear un usuario',                                                       // 73
      createInvitation: 'Crear invitación',                                            // 74
      createUserNow: 'Crear usuario ahora',                                            // 75
      inviteOther: 'Invitar a otro',                                                   // 76
      selectRoles: 'Selecciona los roles para el nuevo usuario',                       // 77
      email: 'Email',                                                                  // 78
      inviteButton: 'Invitar',                                                         // 79
      messages: {                                                                      // 80
        successfullyCreated: 'La invitación fue creada satisfactoriamente'             // 81
      }                                                                                // 80
    },                                                                                 // 72
    changePassword: {                                                                  // 84
      title: 'Cambiar contraseña'                                                      // 85
    },                                                                                 // 84
    updateProfile: {                                                                   // 87
      title: 'Editar perfil'                                                           // 88
    },                                                                                 // 87
    register: {                                                                        // 90
      title: 'Registrarse',                                                            // 91
      registerButton: 'Registrarse',                                                   // 92
      fields: {                                                                        // 93
        email: 'Email',                                                                // 94
        name: 'Nombre',                                                                // 95
        password: 'Contraseña',                                                        // 96
        confirmPassword: 'Confirmar contraseña'                                        // 97
      },                                                                               // 93
      messages: {                                                                      // 99
        invalidEmail: 'Email invalido',                                                // 100
        invalidInvitationCode: 'El código de invitacion es invalido'                   // 101
      }                                                                                // 99
    }                                                                                  // 90
  },                                                                                   // 15
  collections: {                                                                       // 105
    create: {                                                                          // 106
      title: 'Crear un {$1}'                                                           // 107
    },                                                                                 // 106
    update: {                                                                          // 109
      title: 'Actualizar {$1}'                                                         // 110
    },                                                                                 // 109
    "delete": {                                                                        // 112
      title: 'Borrar {$1}',                                                            // 113
      confirmQuestion: '¿Estás seguro de que quieres borrar este {$1}?'                // 114
    },                                                                                 // 112
    common: {                                                                          // 116
      defaultPluralName: 'items',                                                      // 117
      defaultSingularName: 'item'                                                      // 118
    }                                                                                  // 116
  },                                                                                   // 105
  config: {                                                                            // 121
    update: {                                                                          // 122
      title: 'Configuración'                                                           // 123
    }                                                                                  // 122
  },                                                                                   // 121
  dictionary: {                                                                        // 126
    update: {                                                                          // 127
      title: 'Diccionario'                                                             // 128
    }                                                                                  // 127
  },                                                                                   // 126
  filesystem: {                                                                        // 131
    messages: {                                                                        // 132
      notFound_id: 'Archivo no encontrado [{$i}]',                                     // 133
      errorUploading: 'Error subiendo archivo',                                        // 134
      errorRemoving: 'Error borrando archivo'                                          // 135
    }                                                                                  // 132
  },                                                                                   // 131
  pages: {                                                                             // 138
    schema: {                                                                          // 139
      title: 'Título',                                                                 // 140
      url: 'Url'                                                                       // 141
    },                                                                                 // 139
    index: {                                                                           // 143
      title: 'Páginas'                                                                 // 144
    },                                                                                 // 143
    create: {                                                                          // 146
      title: 'Crear página',                                                           // 147
      chooseTemplate: 'Elegir plantilla'                                               // 148
    },                                                                                 // 146
    update: {                                                                          // 150
      title: 'Editar página'                                                           // 151
    },                                                                                 // 150
    "delete": {                                                                        // 153
      title: 'Borrar página',                                                          // 154
      confirmQuestion: '¿Estás seguro de que quieres borrar esta página?'              // 155
    }                                                                                  // 153
  },                                                                                   // 138
  attributes: {                                                                        // 158
    users: {                                                                           // 159
      pluralName: 'usuarios',                                                          // 160
      singularName: 'usuario'                                                          // 161
    },                                                                                 // 159
    file: {                                                                            // 163
      choose: 'Elegir archivo',                                                        // 164
      noFile: 'Ningún archivo seleccionado'                                            // 165
    },                                                                                 // 163
    image: {                                                                           // 167
      choose: 'Elegir imagen'                                                          // 168
    },                                                                                 // 167
    images: {                                                                          // 170
      choose: 'Elige las imagenes',                                                    // 171
      clickToRemove: 'Toca para eliminar'                                              // 172
    }                                                                                  // 170
  },                                                                                   // 158
  tabular: {                                                                           // 175
    search: 'Buscar:',                                                                 // 176
    info: 'Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros',
    infoEmpty: 'Mostrando registros del 0 al 0 de un total de 0 registros',            // 178
    lengthMenu: 'Mostrar _MENU_ registros',                                            // 179
    emptyTable: 'Ningún dato disponible en esta tabla',                                // 180
    paginate: {                                                                        // 181
      first: 'Primero',                                                                // 182
      previous: 'Anterior',                                                            // 183
      next: 'Siguente',                                                                // 184
      last: 'Último'                                                                   // 185
    }                                                                                  // 181
  }                                                                                    // 175
});                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/orionjs:lang-es/es.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:lang-es'] = {};

})();

//# sourceMappingURL=orionjs_lang-es.js.map
