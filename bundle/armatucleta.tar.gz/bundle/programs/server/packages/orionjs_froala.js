(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var orion = Package['orionjs:filesystem'].orion;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var HTML = Package.htmljs.HTML;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Collection2 = Package['aldeed:collection2-core'].Collection2;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:froala":{"attribute.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/orionjs_froala/attribute.js                              //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
orion.attributes.registerAttribute('froala', {                       // 1
  template: 'orionAttributesFroala',                                 // 2
  previewTemplate: 'orionAttributesFroalaColumn',                    // 3
  getSchema: function (options) {                                    // 4
    return {                                                         // 5
      type: String                                                   // 6
    };                                                               // 5
  },                                                                 // 8
  valueOut: function () {                                            // 10
    return this.find('.editor').editable('getHTML', false, true);    // 11
  }                                                                  // 12
});                                                                  // 1
Options.init('froala.height');                                       // 15
orion.config.add('FROALA_ACTIVATION_KEY', 'froala', {                // 16
  "public": true                                                     // 16
});                                                                  // 16
///////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/orionjs:froala/attribute.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:froala'] = {};

})();

//# sourceMappingURL=orionjs_froala.js.map
