var require = meteorInstall({"lib":{"makeGlobal.js":["../imports/api/items/items","../entidades/orion/categories","../entidades/orion/brands","../entidades/orion/colors","../entidades/orion/materials","../entidades/orion/attributes","../entidades/orion/orders","../imports/api/items/sku",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/makeGlobal.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Items = void 0;                                                                                                    // 1
module.import('../imports/api/items/items', {                                                                          // 1
  "default": function (v) {                                                                                            // 1
    Items = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Categories = void 0;                                                                                               // 1
module.import('../entidades/orion/categories', {                                                                       // 1
  "default": function (v) {                                                                                            // 1
    Categories = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Brands = void 0;                                                                                                   // 1
module.import('../entidades/orion/brands', {                                                                           // 1
  "default": function (v) {                                                                                            // 1
    Brands = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Colors = void 0;                                                                                                   // 1
module.import('../entidades/orion/colors', {                                                                           // 1
  "default": function (v) {                                                                                            // 1
    Colors = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var Materials = void 0;                                                                                                // 1
module.import('../entidades/orion/materials', {                                                                        // 1
  "default": function (v) {                                                                                            // 1
    Materials = v;                                                                                                     // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
var Attributes = void 0;                                                                                               // 1
module.import('../entidades/orion/attributes', {                                                                       // 1
  "default": function (v) {                                                                                            // 1
    Attributes = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
var Orders = void 0;                                                                                                   // 1
module.import('../entidades/orion/orders', {                                                                           // 1
  "default": function (v) {                                                                                            // 1
    Orders = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 6);                                                                                                                 // 1
var Sku = void 0;                                                                                                      // 1
module.import('../imports/api/items/sku', {                                                                            // 1
  "default": function (v) {                                                                                            // 1
    Sku = v;                                                                                                           // 1
  }                                                                                                                    // 1
}, 7);                                                                                                                 // 1
global.Items = Items;                                                                                                  // 10
global.Categories = Categories;                                                                                        // 11
global.Brands = Brands;                                                                                                // 12
global.Colors = Colors;                                                                                                // 13
global.Materials = Materials;                                                                                          // 14
global.Attributes = Attributes;                                                                                        // 15
global.Orders = Orders;                                                                                                // 16
global.Sku = Sku;                                                                                                      // 17
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"reemplazartildes.js":["underscore.string",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/reemplazartildes.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
  "default": function () {                                                                                             // 1
    return reemplazartildes;                                                                                           // 1
  }                                                                                                                    // 1
});                                                                                                                    // 1
var s = void 0;                                                                                                        // 1
module.import('underscore.string', {                                                                                   // 1
  "default": function (v) {                                                                                            // 1
    s = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
SimpleSchema.extendOptions({                                                                                           // 3
  srf: Match.Optional(Object)                                                                                          // 4
});                                                                                                                    // 3
                                                                                                                       //
function reemplazartildes(text) {                                                                                      // 7
  /* var acentos = 'ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüûÑñÇç '                                                   // 8
  var original = 'AAAAAEEEEIIIIOOOOUUUUaaaaaeeeeiiiioooouuuunncc-'                                                     //
  for (var i = 0; i < acentos.length; i++) {                                                                           //
    text = text.replace(acentos.charAt(i), original.charAt(i))                                                         //
  } */return s.slugify(text);                                                                                          //
}                                                                                                                      // 14
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"imports":{"api":{"categories":{"server":{"publications.js":["meteor/meteor","../../../../entidades/orion/categories",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/categories/server/publications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Categories = void 0;                                                                                               // 1
module.import('../../../../entidades/orion/categories', {                                                              // 1
  "default": function (v) {                                                                                            // 1
    Categories = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
Meteor.publish('categoriesList', function () {                                                                         // 4
  return Categories.find({                                                                                             // 5
    $and: [{                                                                                                           // 5
      $or: [{                                                                                                          // 5
        accessory: null                                                                                                // 5
      }, {                                                                                                             // 5
        accessory: false                                                                                               // 5
      }]                                                                                                               // 5
    }, {                                                                                                               // 5
      $or: [{                                                                                                          // 5
        dress: null                                                                                                    // 5
      }, {                                                                                                             // 5
        dress: false                                                                                                   // 5
      }]                                                                                                               // 5
    }, {                                                                                                               // 5
      $or: [{                                                                                                          // 5
        bicycle: null                                                                                                  // 5
      }, {                                                                                                             // 5
        bicycle: false                                                                                                 // 5
      }]                                                                                                               // 5
    }, {                                                                                                               // 5
      $or: [{                                                                                                          // 5
        hidden: false                                                                                                  // 5
      }, {                                                                                                             // 5
        hidden: null                                                                                                   // 5
      }]                                                                                                               // 5
    }]                                                                                                                 // 5
  });                                                                                                                  // 5
});                                                                                                                    // 6
Meteor.publish('accessories', function () {                                                                            // 8
  return Categories.find({                                                                                             // 9
    accessory: true,                                                                                                   // 9
    $or: [{                                                                                                            // 9
      hidden: false                                                                                                    // 9
    }, {                                                                                                               // 9
      hidden: null                                                                                                     // 9
    }]                                                                                                                 // 9
  });                                                                                                                  // 9
});                                                                                                                    // 10
Meteor.publish('dress', function () {                                                                                  // 12
  return Categories.find({                                                                                             // 13
    dress: true,                                                                                                       // 13
    $or: [{                                                                                                            // 13
      hidden: false                                                                                                    // 13
    }, {                                                                                                               // 13
      hidden: null                                                                                                     // 13
    }]                                                                                                                 // 13
  });                                                                                                                  // 13
});                                                                                                                    // 14
Meteor.publish('bicycles', function () {                                                                               // 16
  return Categories.find({                                                                                             // 17
    bicycle: true,                                                                                                     // 17
    $or: [{                                                                                                            // 17
      hidden: false                                                                                                    // 17
    }, {                                                                                                               // 17
      hidden: null                                                                                                     // 17
    }]                                                                                                                 // 17
  });                                                                                                                  // 17
}); /*                                                                                                                 // 18
     * Publicamos solo la categoría seleccionada                                                                       //
     */                                                                                                                //
Meteor.publish('category', function (category) {                                                                       // 23
  return Categories.find({                                                                                             // 24
    slug: category                                                                                                     // 24
  });                                                                                                                  // 24
});                                                                                                                    // 25
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"items":{"server":{"methods.js":["meteor/meteor","meteor/check","../../../../imports/api/items/items",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/items/server/methods.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var check = void 0;                                                                                                    // 1
module.import('meteor/check', {                                                                                        // 1
  "check": function (v) {                                                                                              // 1
    check = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Items = void 0;                                                                                                    // 1
module.import('../../../../imports/api/items/items', {                                                                 // 1
  "default": function (v) {                                                                                            // 1
    Items = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
Meteor.methods({                                                                                                       // 5
  'countVisitOnProduct': function (slug) {                                                                             // 6
    check(slug, String);                                                                                               // 7
    this.unblock();                                                                                                    // 8
    Meteor.defer(function () {                                                                                         // 9
      Items.update({                                                                                                   // 10
        slug: slug                                                                                                     // 10
      }, {                                                                                                             // 10
        $inc: {                                                                                                        // 10
          views: 1                                                                                                     // 10
        }                                                                                                              // 10
      });                                                                                                              // 10
    });                                                                                                                // 11
  }                                                                                                                    // 12
});                                                                                                                    // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publications.js":["meteor/meteor","meteor/nicolaslopezj:flow","../items","../../../../entidades/orion/categories","../sku","../../../../entidades/orion/orders","underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/items/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Payments = void 0;                                                                                                 // 1
module.import('meteor/nicolaslopezj:flow', {                                                                           // 1
  "Payments": function (v) {                                                                                           // 1
    Payments = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Items = void 0;                                                                                                    // 1
module.import('../items', {                                                                                            // 1
  "default": function (v) {                                                                                            // 1
    Items = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Categories = void 0;                                                                                               // 1
module.import('../../../../entidades/orion/categories', {                                                              // 1
  "default": function (v) {                                                                                            // 1
    Categories = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var Sku = void 0;                                                                                                      // 1
module.import('../sku', {                                                                                              // 1
  "default": function (v) {                                                                                            // 1
    Sku = v;                                                                                                           // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
var Orders = void 0;                                                                                                   // 1
module.import('../../../../entidades/orion/orders', {                                                                  // 1
  "default": function (v) {                                                                                            // 1
    Orders = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.import('underscore', {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 6);                                                                                                                 // 1
Meteor.publish('most-viewed', function (limit) {                                                                       // 9
  var items = Items.find({}, {                                                                                         // 10
    sort: {                                                                                                            // 10
      views: -1                                                                                                        // 10
    },                                                                                                                 // 10
    limit: limit || 20                                                                                                 // 10
  });                                                                                                                  // 10
  var skus = Sku.find({                                                                                                // 11
    itemId: {                                                                                                          // 11
      $in: _.pluck(items.fetch(), '_id')                                                                               // 11
    },                                                                                                                 // 11
    shopPrice: {                                                                                                       // 11
      $nin: [NaN, null, false]                                                                                         // 11
    },                                                                                                                 // 11
    stock: {                                                                                                           // 11
      $gte: 5                                                                                                          // 11
    }                                                                                                                  // 11
  });                                                                                                                  // 11
  return [items, skus];                                                                                                // 12
});                                                                                                                    // 13
Meteor.publish('item-sku', function (itemId) {                                                                         // 15
  if (!this.itemId) this.ready();                                                                                      // 16
  return Sku.find({                                                                                                    // 17
    itemId: itemId,                                                                                                    // 17
    shopPrice: {                                                                                                       // 17
      $nin: [NaN, null, false]                                                                                         // 17
    },                                                                                                                 // 17
    stock: {                                                                                                           // 17
      $gte: 5                                                                                                          // 17
    }                                                                                                                  // 17
  });                                                                                                                  // 17
});                                                                                                                    // 18
Meteor.publish('itemsCurrent', function (slug) {                                                                       // 20
  if (!slug) this.ready();                                                                                             // 21
  var item = Items.find({                                                                                              // 22
    slug: slug                                                                                                         // 22
  }, {                                                                                                                 // 22
    fields: Items.publicFields                                                                                         // 22
  });                                                                                                                  // 22
  var sku = Sku.find({                                                                                                 // 23
    itemId: {                                                                                                          // 23
      $in: _.pluck(item.fetch(), '_id')                                                                                // 23
    },                                                                                                                 // 23
    shopPrice: {                                                                                                       // 23
      $nin: [NaN, null, false]                                                                                         // 23
    },                                                                                                                 // 23
    stock: {                                                                                                           // 23
      $gte: 5                                                                                                          // 23
    }                                                                                                                  // 23
  });                                                                                                                  // 23
  var category = Categories.find({                                                                                     // 24
    _id: item.fetch()[0].category[0]                                                                                   // 24
  });                                                                                                                  // 24
  return [item, sku, category];                                                                                        // 25
});                                                                                                                    // 26
Meteor.publish('itemsWithIds', function (ids, skus) {                                                                  // 28
  if (!ids || !skus) this.ready();                                                                                     // 29
  var items = Items.find({                                                                                             // 30
    _id: {                                                                                                             // 30
      $in: ids                                                                                                         // 30
    }                                                                                                                  // 30
  }, {                                                                                                                 // 30
    fields: Items.publicFields                                                                                         // 30
  });                                                                                                                  // 30
  var sku = Sku.find({                                                                                                 // 31
    code: {                                                                                                            // 31
      $in: skus                                                                                                        // 31
    }                                                                                                                  // 31
  }); // console.log('lool', items.fetch(), sku.fetch())                                                               // 31
                                                                                                                       //
  return [items, sku];                                                                                                 // 33
}); // Orden de compra a partir de un payment                                                                          // 34
                                                                                                                       //
Meteor.publish('cart', function (paymentId) {                                                                          // 37
  var payments = Payments.findOne(paymentId);                                                                          // 38
  var orders = Orders.find(payments.meta.cartId);                                                                      // 39
                                                                                                                       //
  var itemsId = _.pluck(orders.fetch()[0].items, 'itemId');                                                            // 40
                                                                                                                       //
  var items = Items.find({                                                                                             // 41
    _id: {                                                                                                             // 41
      $in: itemsId                                                                                                     // 41
    }                                                                                                                  // 41
  });                                                                                                                  // 41
  return [orders, items];                                                                                              // 42
});                                                                                                                    // 43
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"items.js":["simple-react-form-material-ui/lib/text","simple-react-form-material-ui/lib/select","simple-react-form-material-ui/lib/checkbox","./multiple-checkbox","../../../lib/reemplazartildes","../../../entidades/orion/categories","../../../entidades/orion/brands","../../../entidades/orion/colors","../../../entidades/orion/materials","meteor/orionjs:core","meteor/aldeed:simple-schema",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/items/items.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Text = void 0;                                                                                                     // 1
module.import('simple-react-form-material-ui/lib/text', {                                                              // 1
  "default": function (v) {                                                                                            // 1
    Text = v;                                                                                                          // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Select = void 0;                                                                                                   // 1
module.import('simple-react-form-material-ui/lib/select', {                                                            // 1
  "default": function (v) {                                                                                            // 1
    Select = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Checkbox = void 0;                                                                                                 // 1
module.import('simple-react-form-material-ui/lib/checkbox', {                                                          // 1
  "default": function (v) {                                                                                            // 1
    Checkbox = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var MultipleCheckbox = void 0;                                                                                         // 1
module.import('./multiple-checkbox', {                                                                                 // 1
  "default": function (v) {                                                                                            // 1
    MultipleCheckbox = v;                                                                                              // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var reemplazartildes = void 0;                                                                                         // 1
module.import('../../../lib/reemplazartildes', {                                                                       // 1
  "default": function (v) {                                                                                            // 1
    reemplazartildes = v;                                                                                              // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
var Categories = void 0;                                                                                               // 1
module.import('../../../entidades/orion/categories', {                                                                 // 1
  "default": function (v) {                                                                                            // 1
    Categories = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
var Brands = void 0;                                                                                                   // 1
module.import('../../../entidades/orion/brands', {                                                                     // 1
  "default": function (v) {                                                                                            // 1
    Brands = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 6);                                                                                                                 // 1
var Colors = void 0;                                                                                                   // 1
module.import('../../../entidades/orion/colors', {                                                                     // 1
  "default": function (v) {                                                                                            // 1
    Colors = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 7);                                                                                                                 // 1
var Materials = void 0;                                                                                                // 1
module.import('../../../entidades/orion/materials', {                                                                  // 1
  "default": function (v) {                                                                                            // 1
    Materials = v;                                                                                                     // 1
  }                                                                                                                    // 1
}, 8);                                                                                                                 // 1
var orion = void 0;                                                                                                    // 1
module.import('meteor/orionjs:core', {                                                                                 // 1
  "orion": function (v) {                                                                                              // 1
    orion = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 9);                                                                                                                 // 1
var SimpleSchema = void 0;                                                                                             // 1
module.import('meteor/aldeed:simple-schema', {                                                                         // 1
  "SimpleSchema": function (v) {                                                                                       // 1
    SimpleSchema = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 10);                                                                                                                // 1
var Items = new orion.collection('items', {                                                                            // 13
  singularName: 'Item',                                                                                                // 14
  pluralName: 'Items',                                                                                                 // 15
  link: {                                                                                                              // 16
    title: 'Items'                                                                                                     // 17
  },                                                                                                                   // 16
  tabular: {                                                                                                           // 19
    columns: [// Orion.attributeColumn('images', 'images', 'Images'),                                                  // 20
    {                                                                                                                  // 23
      data: 'code',                                                                                                    // 23
      title: 'Código'                                                                                                  // 23
    }, {                                                                                                               // 23
      data: 'name',                                                                                                    // 24
      title: 'Nombre'                                                                                                  // 24
    }, // Orion.attributeColumn('hasOne', 'brand', 'Marca'),                                                           // 24
    orion.attributeColumn('hasMany', 'category', 'Categoría'), // Orion.attributeColumn('hasOne', 'colors.$.color', 'Colores'),
    {                                                                                                                  // 30
      data: 'price',                                                                                                   // 30
      title: 'Precio'                                                                                                  // 30
    }]                                                                                                                 // 30
  }                                                                                                                    // 19
});                                                                                                                    // 13
Items.attachSchema(new SimpleSchema({                                                                                  // 35
  name: {                                                                                                              // 36
    type: String,                                                                                                      // 37
    label: 'Nombre',                                                                                                   // 38
    optional: true,                                                                                                    // 39
    srf: {                                                                                                             // 40
      type: Text                                                                                                       // 41
    }                                                                                                                  // 40
  },                                                                                                                   // 36
  slug: {                                                                                                              // 44
    type: String,                                                                                                      // 45
    index: 1,                                                                                                          // 46
    label: 'Slug',                                                                                                     // 47
    autoform: {                                                                                                        // 48
      omit: true                                                                                                       // 49
    },                                                                                                                 // 48
    autoValue: function () {                                                                                           // 51
      if (this.field('name').isSet) {                                                                                  // 52
        return reemplazartildes(this.field('name').value.toLowerCase());                                               // 53
      }                                                                                                                // 54
    },                                                                                                                 // 55
    srf: {                                                                                                             // 56
      type: Text                                                                                                       // 57
    }                                                                                                                  // 56
  },                                                                                                                   // 44
  code: {                                                                                                              // 60
    type: String,                                                                                                      // 61
    label: 'Código',                                                                                                   // 62
    optional: true,                                                                                                    // 63
    srf: {                                                                                                             // 64
      type: Text                                                                                                       // 65
    }                                                                                                                  // 64
  },                                                                                                                   // 60
  url: {                                                                                                               // 68
    type: String,                                                                                                      // 69
    label: 'URL',                                                                                                      // 70
    optional: true,                                                                                                    // 71
    srf: {                                                                                                             // 72
      type: Text                                                                                                       // 73
    }                                                                                                                  // 72
  },                                                                                                                   // 68
  sku: {                                                                                                               // 77
    type: [Object],                                                                                                    // 78
    label: 'SKU',                                                                                                      // 79
    optional: true,                                                                                                    // 80
    blackbox: true,                                                                                                    // 81
    autoform: {                                                                                                        // 82
      omit: true                                                                                                       // 83
    }                                                                                                                  // 82
  },                                                                                                                   // 77
  skuattrs: {                                                                                                          // 87
    type: [String],                                                                                                    // 88
    label: 'SKU Attributes',                                                                                           // 89
    optional: true,                                                                                                    // 90
    autoform: {                                                                                                        // 91
      type: 'selectize',                                                                                               // 92
      multiple: true,                                                                                                  // 93
      selectizeOptions: {                                                                                              // 94
        hideSelected: true,                                                                                            // 95
        plugins: {                                                                                                     // 96
          'remove_button': {}                                                                                          // 97
        }                                                                                                              // 96
      }                                                                                                                // 94
    }                                                                                                                  // 91
  },                                                                                                                   // 87
  // Poner para varias fotos                                                                                           // 103
  images: orion.attribute('images', {                                                                                  // 104
    label: 'Fotos',                                                                                                    // 105
    optional: true                                                                                                     // 106
  }),                                                                                                                  // 104
  // Description: {                                                                                                    // 109
  //     type: String,                                                                                                 // 110
  //     label: "Descripción",                                                                                         // 111
  //     optional: true                                                                                                // 112
  // },                                                                                                                // 113
  description: orion.attribute('froala', {                                                                             // 114
    label: 'Descripción',                                                                                              // 115
    optional: true                                                                                                     // 116
  }),                                                                                                                  // 114
  category: orion.attribute('hasMany', {                                                                               // 118
    label: 'Categoría',                                                                                                // 119
    optional: true,                                                                                                    // 120
    index: 1                                                                                                           // 121
  }, {                                                                                                                 // 118
    collection: Categories,                                                                                            // 123
    titleField: 'name',                                                                                                // 124
    publicationName: 'categories'                                                                                      // 125
  }),                                                                                                                  // 122
  brand: orion.attribute('hasOne', {                                                                                   // 127
    label: 'Marca',                                                                                                    // 128
    optional: true                                                                                                     // 129
  }, {                                                                                                                 // 127
    collection: Brands,                                                                                                // 131
    titleField: 'name',                                                                                                // 132
    publicationName: 'brands'                                                                                          // 133
  }),                                                                                                                  // 130
  price: {                                                                                                             // 135
    type: Number,                                                                                                      // 136
    label: 'Precio',                                                                                                   // 137
    optional: true                                                                                                     // 138
  },                                                                                                                   // 135
  shopPrice: {                                                                                                         // 140
    type: Number,                                                                                                      // 141
    label: 'Precio Tienda',                                                                                            // 142
    optional: true                                                                                                     // 143
  },                                                                                                                   // 140
  color: orion.attribute('hasOne', {                                                                                   // 145
    label: 'Color',                                                                                                    // 146
    optional: true                                                                                                     // 147
  }, {                                                                                                                 // 145
    collection: Colors,                                                                                                // 149
    titleField: 'glosa',                                                                                               // 150
    publicationName: 'colors'                                                                                          // 151
  }),                                                                                                                  // 148
  material: orion.attribute('hasOne', {                                                                                // 153
    label: 'Material',                                                                                                 // 154
    optional: true                                                                                                     // 155
  }, {                                                                                                                 // 153
    collection: Materials,                                                                                             // 157
    titleField: 'name',                                                                                                // 158
    publicationName: 'materials'                                                                                       // 159
  }),                                                                                                                  // 156
  largo: {                                                                                                             // 161
    type: Number,                                                                                                      // 162
    label: 'Largo',                                                                                                    // 163
    decimal: true,                                                                                                     // 164
    optional: true                                                                                                     // 165
  },                                                                                                                   // 161
  alto: {                                                                                                              // 167
    type: Number,                                                                                                      // 168
    label: 'Alto',                                                                                                     // 169
    decimal: true,                                                                                                     // 170
    optional: true                                                                                                     // 171
  },                                                                                                                   // 167
  ancho: {                                                                                                             // 173
    type: Number,                                                                                                      // 174
    label: 'Ancho',                                                                                                    // 175
    decimal: true,                                                                                                     // 176
    optional: true                                                                                                     // 177
  },                                                                                                                   // 173
  peso: {                                                                                                              // 179
    type: Number,                                                                                                      // 180
    label: 'Peso',                                                                                                     // 181
    optional: true                                                                                                     // 182
  },                                                                                                                   // 179
  conector: {                                                                                                          // 184
    type: String,                                                                                                      // 185
    label: 'Conector',                                                                                                 // 186
    optional: true,                                                                                                    // 187
    allowedValues: ['y', 'o'],                                                                                         // 188
    srf: {                                                                                                             // 189
      type: MultipleCheckbox                                                                                           // 190
    }                                                                                                                  // 189
  },                                                                                                                   // 184
  // THIS IS RELATED TO CONNECTIONS                                                                                    // 194
  // Of the frames                                                                                                     // 195
  // nuevo                                                                                                             // 196
  frontDerailleaurPull: {                                                                                              // 197
    type: [String],                                                                                                    // 198
    label: 'Tiraje desviador delantero',                                                                               // 199
    allowedValues: ['Top', 'Bottom'],                                                                                  // 200
    optional: true,                                                                                                    // 201
    autoform: {                                                                                                        // 202
      noselect: true                                                                                                   // 203
    },                                                                                                                 // 202
    srf: {                                                                                                             // 205
      type: MultipleCheckbox                                                                                           // 206
    }                                                                                                                  // 205
  },                                                                                                                   // 197
  // Nuevo                                                                                                             // 210
  // si el desviador delantero es 'montaje directo', el marco no necesita rellenar el campo del "ancho desviador delantero".
  frontDerailleaurMount: {                                                                                             // 212
    type: [String],                                                                                                    // 213
    label: 'Montaje desviador delantero',                                                                              // 214
    allowedValues: ['montaje directo', 'Abrazadera'],                                                                  // 215
    optional: true,                                                                                                    // 216
    autoform: {                                                                                                        // 217
      noselect: true                                                                                                   // 218
    },                                                                                                                 // 217
    srf: {                                                                                                             // 220
      type: MultipleCheckbox                                                                                           // 221
    }                                                                                                                  // 220
  },                                                                                                                   // 212
  // Nuevo                                                                                                             // 225
  frontDerailleaurWidth: {                                                                                             // 226
    type: [String],                                                                                                    // 227
    label: 'Ancho desviador delantero',                                                                                // 228
    allowedValues: ['28.6', '31.8', '34.9'],                                                                           // 229
    optional: true,                                                                                                    // 230
    autoform: {                                                                                                        // 231
      noselect: true                                                                                                   // 232
    },                                                                                                                 // 231
    srf: {                                                                                                             // 234
      type: MultipleCheckbox                                                                                           // 235
    }                                                                                                                  // 234
  },                                                                                                                   // 226
  // Nuevo                                                                                                             // 239
  rearDerailleaurMount: {                                                                                              // 240
    type: Boolean,                                                                                                     // 241
    label: 'Marco tiene postiza',                                                                                      // 242
    optional: true                                                                                                     // 243
  },                                                                                                                   // 240
  // Nuevo                                                                                                             // 246
  hidraulicCable: {                                                                                                    // 247
    type: Boolean,                                                                                                     // 248
    label: 'Marco tiene cable para freno hidraulico',                                                                  // 249
    optional: true                                                                                                     // 250
  },                                                                                                                   // 247
  bbsize: {                                                                                                            // 252
    type: String,                                                                                                      // 253
    label: 'Tamaño caja motor',                                                                                        // 254
    optional: true,                                                                                                    // 255
    srf: {                                                                                                             // 256
      type: Text                                                                                                       // 257
    }                                                                                                                  // 256
  },                                                                                                                   // 252
  seatTubeSize: {                                                                                                      // 260
    type: String,                                                                                                      // 261
    label: 'Tamaño tija',                                                                                              // 262
    optional: true,                                                                                                    // 263
    srf: {                                                                                                             // 264
      type: Text                                                                                                       // 265
    }                                                                                                                  // 264
  },                                                                                                                   // 260
  SeatClampSize: {                                                                                                     // 268
    type: String,                                                                                                      // 269
    label: 'Tamaño collerín',                                                                                          // 270
    optional: true,                                                                                                    // 271
    srf: {                                                                                                             // 272
      type: Text                                                                                                       // 273
    }                                                                                                                  // 272
  },                                                                                                                   // 268
  headSetSize: {                                                                                                       // 276
    type: String,                                                                                                      // 277
    label: 'Tamaño juego de dirección',                                                                                // 278
    optional: true,                                                                                                    // 279
    srf: {                                                                                                             // 280
      type: Text                                                                                                       // 281
    }                                                                                                                  // 280
  },                                                                                                                   // 276
  headSetType: {                                                                                                       // 284
    type: String,                                                                                                      // 285
    label: 'Tipo juego de dirección',                                                                                  // 286
    optional: true,                                                                                                    // 287
    allowedValues: ['ahead', 'semi-integrated', 'integrated'],                                                         // 288
    srf: {                                                                                                             // 289
      type: Select                                                                                                     // 290
    }                                                                                                                  // 289
  },                                                                                                                   // 284
  headSetConical: {                                                                                                    // 293
    type: Boolean,                                                                                                     // 294
    label: 'Tipo de dirección cónica',                                                                                 // 295
    optional: true,                                                                                                    // 296
    srf: {                                                                                                             // 297
      type: Checkbox                                                                                                   // 298
    }                                                                                                                  // 297
  },                                                                                                                   // 293
  frameShockSize: {                                                                                                    // 301
    type: String,                                                                                                      // 302
    label: 'Tamaño shock',                                                                                             // 303
    optional: true,                                                                                                    // 304
    srf: {                                                                                                             // 305
      type: Text                                                                                                       // 306
    }                                                                                                                  // 305
  },                                                                                                                   // 301
  rearBrakeType: {                                                                                                     // 309
    type: [String],                                                                                                    // 310
    label: 'Tipo freno trasero',                                                                                       // 311
    optional: true,                                                                                                    // 312
    allowedValues: ['Disk', 'vbrake', 'roadBrake', 'cantilever'],                                                      // 313
    autoform: {                                                                                                        // 314
      noselect: true                                                                                                   // 315
    },                                                                                                                 // 314
    srf: {                                                                                                             // 317
      type: MultipleCheckbox                                                                                           // 318
    }                                                                                                                  // 317
  },                                                                                                                   // 309
  // End of frames                                                                                                     // 322
  // of the Forks                                                                                                      // 323
  frontBrakeType: {                                                                                                    // 324
    type: [String],                                                                                                    // 325
    label: 'Tipo freno delantero',                                                                                     // 326
    optional: true,                                                                                                    // 327
    allowedValues: ['Disk', 'vbrake', 'roadBrake', 'cantilever'],                                                      // 328
    autoform: {                                                                                                        // 329
      noselect: true                                                                                                   // 330
    },                                                                                                                 // 329
    srf: {                                                                                                             // 332
      type: MultipleCheckbox                                                                                           // 333
    }                                                                                                                  // 332
  },                                                                                                                   // 324
  axleSize: {                                                                                                          // 336
    type: String,                                                                                                      // 337
    label: 'Tamaño Diámetro eje',                                                                                      // 338
    optional: true,                                                                                                    // 339
    srf: {                                                                                                             // 340
      type: Text                                                                                                       // 341
    }                                                                                                                  // 340
  },                                                                                                                   // 336
  axleWidth: {                                                                                                         // 344
    type: String,                                                                                                      // 345
    label: 'Tamaño eje',                                                                                               // 346
    optional: true,                                                                                                    // 347
    srf: {                                                                                                             // 348
      type: Text                                                                                                       // 349
    }                                                                                                                  // 348
  },                                                                                                                   // 344
  // TyreWidth: {                                                                                                      // 353
  //   type: String,                                                                                                   // 354
  //   label: "Tamaño neumatico",                                                                                      // 355
  //   optional: true                                                                                                  // 356
  // },                                                                                                                // 357
  travel: {                                                                                                            // 358
    type: [String],                                                                                                    // 359
    label: 'Recorrido horquilla',                                                                                      // 360
    allowedValues: ['35', '40', '60', '65', '80', '100', '120', '130', '140', '150', '160', '180', '200'],             // 361
    optional: true,                                                                                                    // 362
    autoform: {                                                                                                        // 363
      noselect: true                                                                                                   // 364
    },                                                                                                                 // 363
    srf: {                                                                                                             // 366
      type: MultipleCheckbox                                                                                           // 367
    }                                                                                                                  // 366
  },                                                                                                                   // 358
  // End of Forks                                                                                                      // 371
  // Stem                                                                                                              // 372
  handleWidth: {                                                                                                       // 373
    type: String,                                                                                                      // 374
    label: 'Tamaño para manubrio',                                                                                     // 375
    optional: true,                                                                                                    // 376
    srf: {                                                                                                             // 377
      type: Text                                                                                                       // 378
    }                                                                                                                  // 377
  },                                                                                                                   // 373
  forkWidth: {                                                                                                         // 381
    type: String,                                                                                                      // 382
    label: 'Tamaño para horquilla',                                                                                    // 383
    optional: true,                                                                                                    // 384
    srf: {                                                                                                             // 385
      type: Text                                                                                                       // 386
    }                                                                                                                  // 385
  },                                                                                                                   // 381
  // Fin Stem                                                                                                          // 390
  // frenos y discos                                                                                                   // 391
  frontRotorSize: {                                                                                                    // 392
    type: [String],                                                                                                    // 393
    label: 'Tamaño rotor delantero',                                                                                   // 394
    allowedValues: ['140', '160', '180', '185', '200', '203'],                                                         // 395
    optional: true,                                                                                                    // 396
    autoform: {                                                                                                        // 397
      noselect: true                                                                                                   // 398
    },                                                                                                                 // 397
    srf: {                                                                                                             // 400
      type: MultipleCheckbox                                                                                           // 401
    }                                                                                                                  // 400
  },                                                                                                                   // 392
  frontRotorType: {                                                                                                    // 404
    type: String,                                                                                                      // 405
    label: 'Tipo rotor delantero',                                                                                     // 406
    optional: true,                                                                                                    // 407
    allowedValues: ['centerlock', 'IS'],                                                                               // 408
    srf: {                                                                                                             // 409
      type: MultipleCheckbox                                                                                           // 410
    }                                                                                                                  // 409
  },                                                                                                                   // 404
  rearRotorType: {                                                                                                     // 413
    type: String,                                                                                                      // 414
    label: 'Tipo rotor trasero',                                                                                       // 415
    optional: true,                                                                                                    // 416
    allowedValues: ['centerlock', 'IS'],                                                                               // 417
    srf: {                                                                                                             // 418
      type: Select                                                                                                     // 419
    }                                                                                                                  // 418
  },                                                                                                                   // 413
  rearRotorSize: {                                                                                                     // 422
    type: [String],                                                                                                    // 423
    label: 'Tamaño rotor trasero',                                                                                     // 424
    allowedValues: ['140', '160', '180', '185', '200', '203'],                                                         // 425
    optional: true,                                                                                                    // 426
    autoform: {                                                                                                        // 427
      noselect: true                                                                                                   // 428
    },                                                                                                                 // 427
    srf: {                                                                                                             // 430
      type: MultipleCheckbox                                                                                           // 431
    }                                                                                                                  // 430
  },                                                                                                                   // 422
  // Fin frenos y discos                                                                                               // 435
  // About wheels                                                                                                      // 436
  // nuevo                                                                                                             // 437
  rimDiameter: {                                                                                                       // 438
    type: String,                                                                                                      // 439
    label: 'Diámetro llantas',                                                                                         // 440
    allowedValues: ['20', '24', '26', '27.5', '29', '700c'],                                                           // 441
    optional: true,                                                                                                    // 442
    srf: {                                                                                                             // 443
      type: Select                                                                                                     // 444
    }                                                                                                                  // 443
  },                                                                                                                   // 438
  // Nuevo                                                                                                             // 448
  rearHubWidth: {                                                                                                      // 449
    type: String,                                                                                                      // 450
    label: 'Ancho maza trasera',                                                                                       // 451
    allowedValues: ['120', '130', '135', '142', '150', '165'],                                                         // 452
    optional: true,                                                                                                    // 453
    srf: {                                                                                                             // 454
      type: MultipleCheckbox                                                                                           // 455
    }                                                                                                                  // 454
  },                                                                                                                   // 449
  // Nuevo                                                                                                             // 459
  rearHubDiameter: {                                                                                                   // 460
    type: String,                                                                                                      // 461
    label: 'Diámetro maza trasera',                                                                                    // 462
    allowedValues: ['10', '12'],                                                                                       // 463
    optional: true,                                                                                                    // 464
    srf: {                                                                                                             // 465
      type: MultipleCheckbox                                                                                           // 466
    }                                                                                                                  // 465
  },                                                                                                                   // 460
  // Nuevo                                                                                                             // 470
  frontTyreWidth: {                                                                                                    // 471
    type: [String],                                                                                                    // 472
    label: 'Ancho rueda delantera',                                                                                    // 473
    optional: true,                                                                                                    // 474
    allowedValues: ['20', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '1.5', '1.6', '1.7', '1.8', '1.9', '2.0', '2.1', '2.2', '2.3', '2.4', '2.5', '2.6', '4.0'],
    autoform: {                                                                                                        // 476
      noselect: true                                                                                                   // 477
    },                                                                                                                 // 476
    srf: {                                                                                                             // 479
      type: MultipleCheckbox                                                                                           // 480
    }                                                                                                                  // 479
  },                                                                                                                   // 471
  // Nuevo                                                                                                             // 484
  rearTyreWidth: {                                                                                                     // 485
    type: [String],                                                                                                    // 486
    label: 'Ancho rueda trasera',                                                                                      // 487
    optional: true,                                                                                                    // 488
    allowedValues: ['20', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '1.5', '1.6', '1.7', '1.8', '1.9', '2.0', '2.1', '2.2', '2.3', '2.4', '2.5', '2.6', '4.0'],
    autoform: {                                                                                                        // 490
      noselect: true                                                                                                   // 491
    },                                                                                                                 // 490
    srf: {                                                                                                             // 493
      type: MultipleCheckbox                                                                                           // 494
    }                                                                                                                  // 493
  },                                                                                                                   // 485
  frontHoles: {                                                                                                        // 497
    type: Number,                                                                                                      // 498
    label: 'Cantidad rayos delantero',                                                                                 // 499
    optional: true                                                                                                     // 500
  },                                                                                                                   // 497
  rearHoles: {                                                                                                         // 502
    type: Number,                                                                                                      // 503
    label: 'Cantidad rayos trasero',                                                                                   // 504
    optional: true                                                                                                     // 505
  },                                                                                                                   // 502
  // End wheels                                                                                                        // 508
  // velocidades                                                                                                       // 509
  frontSpeedsNumber: {                                                                                                 // 510
    type: [String],                                                                                                    // 511
    label: 'Cantidad velocidades delantero',                                                                           // 512
    optional: true,                                                                                                    // 513
    allowedValues: ['1', '2', '3'],                                                                                    // 514
    autoform: {                                                                                                        // 515
      noselect: true                                                                                                   // 516
    },                                                                                                                 // 515
    srf: {                                                                                                             // 518
      type: MultipleCheckbox                                                                                           // 519
    }                                                                                                                  // 518
  },                                                                                                                   // 510
  rearSpeedsNumber: {                                                                                                  // 522
    type: [String],                                                                                                    // 523
    label: 'Cantidad velocidades trasero',                                                                             // 524
    optional: true,                                                                                                    // 525
    allowedValues: ['1', '6', '7', '8', '9', '10', '11'],                                                              // 526
    autoform: {                                                                                                        // 527
      noselect: true                                                                                                   // 528
    },                                                                                                                 // 527
    srf: {                                                                                                             // 530
      type: MultipleCheckbox                                                                                           // 531
    }                                                                                                                  // 530
  },                                                                                                                   // 522
  rearBlockType: {                                                                                                     // 534
    type: String,                                                                                                      // 535
    label: 'Tipo Piñon',                                                                                               // 536
    optional: true,                                                                                                    // 537
    allowedValues: ['Freewheel', 'buildOnto', 'fixed'],                                                                // 538
    srf: {                                                                                                             // 539
      type: MultipleCheckbox                                                                                           // 540
    }                                                                                                                  // 539
  },                                                                                                                   // 534
  // Tubo asiento-asiento                                                                                              // 544
  // nuevo                                                                                                             // 545
  seatMount: {                                                                                                         // 546
    type: Boolean,                                                                                                     // 547
    label: 'Para riel',                                                                                                // 548
    optional: true                                                                                                     // 549
  },                                                                                                                   // 546
  // Parrilla                                                                                                          // 552
  pannierRack: {                                                                                                       // 553
    type: Boolean,                                                                                                     // 554
    label: 'Puede tener parrilla',                                                                                     // 555
    optional: true                                                                                                     // 556
  },                                                                                                                   // 553
  // CrankSet                                                                                                          // 559
  crankSetType: {                                                                                                      // 560
    type: String,                                                                                                      // 561
    label: 'Tipo de Volante',                                                                                          // 562
    optional: true,                                                                                                    // 563
    allowedValues: ['Square', 'Octalink', 'OctalinkV2', 'Integrated'],                                                 // 564
    srf: {                                                                                                             // 565
      type: MultipleCheckbox                                                                                           // 566
    }                                                                                                                  // 565
  },                                                                                                                   // 560
  // Shifters                                                                                                          // 570
  shifterRatio: {                                                                                                      // 571
    type: String,                                                                                                      // 572
    label: 'Tensión cable shifter',                                                                                    // 573
    allowedValues: ['1:1', '1:2'],                                                                                     // 574
    optional: true,                                                                                                    // 575
    srf: {                                                                                                             // 576
      type: MultipleCheckbox                                                                                           // 577
    }                                                                                                                  // 576
  },                                                                                                                   // 571
  // Nuevo                                                                                                             // 581
  handlebarType: {                                                                                                     // 582
    type: String,                                                                                                      // 583
    label: 'Tipo manubrio',                                                                                            // 584
    allowedValues: ['recto', 'ruta', 'fixed'],                                                                         // 585
    optional: true,                                                                                                    // 586
    srf: {                                                                                                             // 587
      type: MultipleCheckbox                                                                                           // 588
    }                                                                                                                  // 587
  },                                                                                                                   // 582
  // Cassete?                                                                                                          // 592
  cassetteType: {                                                                                                      // 593
    type: String,                                                                                                      // 594
    label: 'Tipo Cassette',                                                                                            // 595
    allowedValues: ['shimano', 'XD', 'Campagnolo'],                                                                    // 596
    optional: true,                                                                                                    // 597
    srf: {                                                                                                             // 598
      type: MultipleCheckbox                                                                                           // 599
    }                                                                                                                  // 598
  },                                                                                                                   // 593
  // Pedales                                                                                                           // 603
  crankDiameter: {                                                                                                     // 604
    type: String,                                                                                                      // 605
    allowedValues: ['1/2', '9/16'],                                                                                    // 606
    label: 'Diámetro eje biela',                                                                                       // 607
    optional: true,                                                                                                    // 608
    srf: {                                                                                                             // 609
      type: MultipleCheckbox                                                                                           // 610
    }                                                                                                                  // 609
  },                                                                                                                   // 604
  // Talla                                                                                                             // 614
  size: {                                                                                                              // 615
    type: String,                                                                                                      // 616
    label: 'Talla',                                                                                                    // 617
    allowedValues: ['S', 'M', 'L'],                                                                                    // 618
    optional: true,                                                                                                    // 619
    srf: {                                                                                                             // 620
      type: MultipleCheckbox                                                                                           // 621
    }                                                                                                                  // 620
  },                                                                                                                   // 615
  mala: {                                                                                                              // 625
    type: Boolean,                                                                                                     // 626
    label: 'Registro en mal estado',                                                                                   // 627
    optional: true                                                                                                     // 628
  },                                                                                                                   // 625
  views: {                                                                                                             // 631
    type: Number,                                                                                                      // 632
    label: 'Visitas',                                                                                                  // 633
    optional: true                                                                                                     // 634
  },                                                                                                                   // 631
  createdBy: orion.attribute('createdBy'),                                                                             // 637
  createdAt: orion.attribute('createdAt')                                                                              // 638
}));                                                                                                                   // 35
Items.publicFields = {                                                                                                 // 641
  _id: 1,                                                                                                              // 642
  name: 1,                                                                                                             // 643
  slug: 1,                                                                                                             // 644
  images: 1,                                                                                                           // 645
  description: 1,                                                                                                      // 646
  category: 1,                                                                                                         // 647
  brand: 1,                                                                                                            // 648
  price: 1,                                                                                                            // 649
  colors: 1,                                                                                                           // 650
  material: 1,                                                                                                         // 651
  largo: 1,                                                                                                            // 652
  alto: 1,                                                                                                             // 653
  ancho: 1,                                                                                                            // 654
  peso: 1,                                                                                                             // 655
  conector: 1,                                                                                                         // 656
  crankDiameter: 1,                                                                                                    // 657
  frontDerailleaurPull: 1,                                                                                             // 658
  frontDerailleaurMount: 1,                                                                                            // 659
  frontDerailleaurWidth: 1,                                                                                            // 660
  rearDerailleaurMount: 1,                                                                                             // 661
  hidraulicCable: 1,                                                                                                   // 662
  bbsize: 1,                                                                                                           // 663
  seatTubeSize: 1,                                                                                                     // 664
  SeatClampSize: 1,                                                                                                    // 665
  headSetSize: 1,                                                                                                      // 666
  headSetType: 1,                                                                                                      // 667
  headSetConical: 1,                                                                                                   // 668
  frameShockSize: 1,                                                                                                   // 669
  rearBrakeType: 1,                                                                                                    // 670
  frontBrakeType: 1,                                                                                                   // 671
  axleSize: 1,                                                                                                         // 672
  axleWidth: 1,                                                                                                        // 673
  travel: 1,                                                                                                           // 674
  handleWidth: 1,                                                                                                      // 675
  forkWidth: 1,                                                                                                        // 676
  frontRotorSize: 1,                                                                                                   // 677
  frontRotorType: 1,                                                                                                   // 678
  rearRotorType: 1,                                                                                                    // 679
  rearRotorSize: 1,                                                                                                    // 680
  rimDiameter: 1,                                                                                                      // 681
  rearHubWidth: 1,                                                                                                     // 682
  rearHubDiameter: 1,                                                                                                  // 683
  frontTyreWidth: 1,                                                                                                   // 684
  rearTyreWidth: 1,                                                                                                    // 685
  frontHoles: 1,                                                                                                       // 686
  rearHoles: 1,                                                                                                        // 687
  frontSpeedsNumber: 1,                                                                                                // 688
  rearSpeedsNumber: 1,                                                                                                 // 689
  rearBlockType: 1,                                                                                                    // 690
  seatMount: 1,                                                                                                        // 691
  pannierRack: 1,                                                                                                      // 692
  crankSetType: 1,                                                                                                     // 693
  shifterRatio: 1,                                                                                                     // 694
  handlebarType: 1,                                                                                                    // 695
  sku: 1                                                                                                               // 696
};                                                                                                                     // 641
module.export("default", exports.default = Items);                                                                     // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"multiple-checkbox.jsx":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","react","simple-react-form-material-ui/lib/multiple-checkbox","meteor/meteor","react-select","autobind-decorator","underscore","react-select/dist/react-select.css",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/items/multiple-checkbox.jsx                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                                //
                                                                                                                       //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                       //
                                                                                                                       //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                          //
                                                                                                                       //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                 //
                                                                                                                       //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                            //
                                                                                                                       //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                   //
                                                                                                                       //
var _desc, _value, _class;                                                                                             //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                      //
                                                                                                                       //
function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {                                //
  var desc = {};                                                                                                       //
  Object['ke' + 'ys'](descriptor).forEach(function (key) {                                                             //
    desc[key] = descriptor[key];                                                                                       //
  });                                                                                                                  //
  desc.enumerable = !!desc.enumerable;                                                                                 //
  desc.configurable = !!desc.configurable;                                                                             //
                                                                                                                       //
  if ('value' in desc || desc.initializer) {                                                                           //
    desc.writable = true;                                                                                              //
  }                                                                                                                    //
                                                                                                                       //
  desc = decorators.slice().reverse().reduce(function (desc, decorator) {                                              //
    return decorator(target, property, desc) || desc;                                                                  //
  }, desc);                                                                                                            //
                                                                                                                       //
  if (context && desc.initializer !== void 0) {                                                                        //
    desc.value = desc.initializer ? desc.initializer.call(context) : void 0;                                           //
    desc.initializer = undefined;                                                                                      //
  }                                                                                                                    //
                                                                                                                       //
  if (desc.initializer === void 0) {                                                                                   //
    Object['define' + 'Property'](target, property, desc);                                                             //
    desc = null;                                                                                                       //
  }                                                                                                                    //
                                                                                                                       //
  return desc;                                                                                                         //
}                                                                                                                      //
                                                                                                                       //
module.export({                                                                                                        // 1
  "default": function () {                                                                                             // 1
    return MultipleCheckBox;                                                                                           // 1
  }                                                                                                                    // 1
});                                                                                                                    // 1
var React = void 0;                                                                                                    // 1
module.import('react', {                                                                                               // 1
  "default": function (v) {                                                                                            // 1
    React = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var MultipleCheckboxSRF = void 0;                                                                                      // 1
module.import('simple-react-form-material-ui/lib/multiple-checkbox', {                                                 // 1
  "default": function (v) {                                                                                            // 1
    MultipleCheckboxSRF = v;                                                                                           // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Select = void 0;                                                                                                   // 1
module.import('react-select', {                                                                                        // 1
  "default": function (v) {                                                                                            // 1
    Select = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var autobind = void 0;                                                                                                 // 1
module.import('autobind-decorator', {                                                                                  // 1
  "default": function (v) {                                                                                            // 1
    autobind = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.import('underscore', {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
                                                                                                                       //
if (Meteor.isClient) {                                                                                                 // 8
  module.import('react-select/dist/react-select.css');                                                                 // 1
}                                                                                                                      // 10
                                                                                                                       //
var propTypes = {                                                                                                      // 13
  value: React.PropTypes.array,                                                                                        // 14
  onChange: React.PropTypes.func,                                                                                      // 15
  fieldType: React.PropTypes.string                                                                                    // 16
};                                                                                                                     // 13
var defaultProps = {                                                                                                   // 19
  fieldType: 'filters'                                                                                                 // 20
};                                                                                                                     // 19
var MultipleCheckBox = (_class = function (_React$Component) {                                                         //
  (0, _inherits3.default)(MultipleCheckBox, _React$Component);                                                         //
                                                                                                                       //
  function MultipleCheckBox(props) {                                                                                   // 24
    (0, _classCallCheck3.default)(this, MultipleCheckBox);                                                             // 24
                                                                                                                       //
    var _this = (0, _possibleConstructorReturn3.default)(this, _React$Component.call(this, props));                    // 24
                                                                                                                       //
    _this.state = {                                                                                                    // 26
      value: props.value,                                                                                              // 27
      multi: _this.isMulti()                                                                                           // 28
    };                                                                                                                 // 26
    return _this;                                                                                                      // 24
  }                                                                                                                    // 30
                                                                                                                       //
  MultipleCheckBox.prototype.componentWillReceiveProps = function () {                                                 //
    function componentWillReceiveProps(nextProps) {                                                                    //
      this.setState({                                                                                                  // 33
        value: nextProps.value                                                                                         // 34
      });                                                                                                              // 33
    }                                                                                                                  // 36
                                                                                                                       //
    return componentWillReceiveProps;                                                                                  //
  }();                                                                                                                 //
                                                                                                                       //
  MultipleCheckBox.prototype.isMulti = function () {                                                                   //
    function isMulti() {                                                                                               //
      if (this.props.fieldType !== 'filters') {                                                                        // 39
        return false;                                                                                                  // 40
      }                                                                                                                // 41
                                                                                                                       //
      if (this.isArray()) {                                                                                            // 42
        return true;                                                                                                   // 43
      }                                                                                                                // 44
                                                                                                                       //
      return false;                                                                                                    // 45
    }                                                                                                                  // 46
                                                                                                                       //
    return isMulti;                                                                                                    //
  }();                                                                                                                 //
                                                                                                                       //
  MultipleCheckBox.prototype.isArray = function () {                                                                   //
    function isArray() {                                                                                               //
      if (this.props.fieldSchema.type === Array) {                                                                     // 49
        return true;                                                                                                   // 50
      }                                                                                                                // 51
                                                                                                                       //
      return false;                                                                                                    // 52
    }                                                                                                                  // 53
                                                                                                                       //
    return isArray;                                                                                                    //
  }();                                                                                                                 //
                                                                                                                       //
  MultipleCheckBox.prototype.getField = function () {                                                                  //
    function getField() {                                                                                              //
      if (this.isArray()) {                                                                                            // 56
        return this.props.schema._schema[this.props.fieldName + '.$'];                                                 // 57
      }                                                                                                                // 58
                                                                                                                       //
      return this.props.schema._schema[this.props.fieldName];                                                          // 59
    }                                                                                                                  // 60
                                                                                                                       //
    return getField;                                                                                                   //
  }();                                                                                                                 //
                                                                                                                       //
  MultipleCheckBox.prototype.options = function () {                                                                   //
    function options() {                                                                                               //
      return this.getField().allowedValues.map(function (value) {                                                      // 63
        return {                                                                                                       // 64
          value: value,                                                                                                // 65
          label: value                                                                                                 // 66
        };                                                                                                             // 64
      });                                                                                                              // 68
    }                                                                                                                  // 69
                                                                                                                       //
    return options;                                                                                                    //
  }();                                                                                                                 //
                                                                                                                       //
  MultipleCheckBox.prototype.processValue = function () {                                                              //
    function processValue() {                                                                                          //
      if (!this.isMulti) {                                                                                             // 72
        if (_.isArray(this.state.value)) {                                                                             // 73
          if (_.isObject(this.state.value[0])) {                                                                       // 74
            return this.state.value[0].label;                                                                          // 75
          } else {                                                                                                     // 76
            return this.state.value[0];                                                                                // 77
          }                                                                                                            // 78
        }                                                                                                              // 79
                                                                                                                       //
        return this.state.value;                                                                                       // 80
      } else {                                                                                                         // 81
        if (_.isArray(this.state.value)) {                                                                             // 82
          return this.state.value;                                                                                     // 83
        } else {                                                                                                       // 84
          return [this.state.value];                                                                                   // 85
        }                                                                                                              // 86
      }                                                                                                                // 87
    }                                                                                                                  // 88
                                                                                                                       //
    return processValue;                                                                                               //
  }();                                                                                                                 //
                                                                                                                       //
  MultipleCheckBox.prototype.onChange = function () {                                                                  //
    function onChange(value) {                                                                                         //
      var _this2 = this;                                                                                               // 91
                                                                                                                       //
      if (_.isEmpty(value)) {                                                                                          // 92
        value = null;                                                                                                  // 93
      }                                                                                                                // 94
                                                                                                                       //
      this.setState({                                                                                                  // 95
        value: value                                                                                                   // 95
      }, function () {                                                                                                 // 95
        return _this2.props.onChange(value);                                                                           // 95
      });                                                                                                              // 95
    }                                                                                                                  // 96
                                                                                                                       //
    return onChange;                                                                                                   //
  }();                                                                                                                 //
                                                                                                                       //
  MultipleCheckBox.prototype.render = function () {                                                                    //
    function render() {                                                                                                //
      return React.createElement(Select, {                                                                             // 99
        multi: this.state.multi,                                                                                       // 101
        value: this.processValue(),                                                                                    // 102
        options: this.options(),                                                                                       // 103
        onChange: this.onChange,                                                                                       // 104
        placeholder: this.props.fieldSchema.label,                                                                     // 105
        menuContainerStyle: {                                                                                          // 106
          zIndex: 1000                                                                                                 // 106
        },                                                                                                             // 106
        wrapperStyle: {                                                                                                // 107
          margin: '5px 0'                                                                                              // 107
        }                                                                                                              // 107
      });                                                                                                              // 100
    }                                                                                                                  // 110
                                                                                                                       //
    return render;                                                                                                     //
  }();                                                                                                                 //
                                                                                                                       //
  return MultipleCheckBox;                                                                                             //
}(React.Component), (_applyDecoratedDescriptor(_class.prototype, "onChange", [autobind], Object.getOwnPropertyDescriptor(_class.prototype, "onChange"), _class.prototype)), _class);
MultipleCheckBox.propTypes = propTypes;                                                                                // 113
MultipleCheckBox.defaultProps = defaultProps;                                                                          // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"sku.js":["meteor/meteor","meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/items/sku.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Mongo = void 0;                                                                                                    // 1
module.import('meteor/mongo', {                                                                                        // 1
  "Mongo": function (v) {                                                                                              // 1
    Mongo = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Sku = new Mongo.Collection('sku');                                                                                 // 4
module.export("default", exports.default = Sku);                                                                       // 1
Sku.allow({                                                                                                            // 8
  insert: function (userId, doc) {                                                                                     // 9
    if (!userId) return false;                                                                                         // 10
    return true;                                                                                                       // 11
  },                                                                                                                   // 12
  update: function (userId, doc, fields, modifier) {                                                                   // 14
    if (!userId) return false;                                                                                         // 15
    return true;                                                                                                       // 16
  },                                                                                                                   // 17
  remove: function (userId, doc) {                                                                                     // 19
    if (!userId) return false;                                                                                         // 20
    return true;                                                                                                       // 21
  }                                                                                                                    // 22
});                                                                                                                    // 8
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 25
  Sku._ensureIndex({                                                                                                   // 26
    code: 1                                                                                                            // 26
  }, {                                                                                                                 // 26
    unique: true                                                                                                       // 26
  });                                                                                                                  // 26
                                                                                                                       //
  Sku._ensureIndex({                                                                                                   // 27
    itemId: 1,                                                                                                         // 27
    url: 1                                                                                                             // 27
  });                                                                                                                  // 27
}                                                                                                                      // 28
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"server":{"cron.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/cron.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// import {SyncedCron} from 'meteor/percolate:synced-cron'                                                             // 1
// import {Meteor} from 'meteor/meteor'                                                                                // 2
//                                                                                                                     // 3
// SyncedCron.add({                                                                                                    // 4
//   name: 'Update information from mkr at 12 am everyday',                                                            // 5
//   schedule: function (parser) {                                                                                     // 6
//     return parser.text('at 00:00')                                                                                  // 7
//   },                                                                                                                // 8
//   job: function () {                                                                                                // 9
//     Meteor.call('updatePrices', true)                                                                               // 10
//   }                                                                                                                 // 11
// })                                                                                                                  // 12
//                                                                                                                     // 13
// // SyncedCron.start()                                                                                               // 14
// SyncedCron.stop()                                                                                                   // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"emailTemplates.js":["meteor/meteorhacks:ssr",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/emailTemplates.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var SSR = void 0;                                                                                                      // 1
module.import('meteor/meteorhacks:ssr', {                                                                              // 1
  "SSR": function (v) {                                                                                                // 1
    SSR = v;                                                                                                           // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
/* global Assets */ // Email Layout                                                                                    // 2
SSR.compileTemplate('emailsLayout', Assets.getText('templates/emails/layout/layout.html'));                            // 5
SSR.compileTemplate('emailsLayoutStyles', Assets.getText('templates/emails/layout/styles.html'));                      // 6
SSR.compileTemplate('emailsLayoutButton', Assets.getText('templates/emails/layout/button.html'));                      // 7
SSR.compileTemplate('emailsLayoutUnsubscribe', Assets.getText('templates/emails/layout/unsubscribe.html')); // Contact Form
                                                                                                                       //
SSR.compileTemplate('emailsContactForm', Assets.getText('templates/emails/notifications/contact-form.html'));          // 11
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"emails.js":["meteor/meteor","meteor/email","meteor/kadira:flow-router","meteor/meteorhacks:ssr","juice",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/emails.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Email = void 0;                                                                                                    // 1
module.import('meteor/email', {                                                                                        // 1
  "Email": function (v) {                                                                                              // 1
    Email = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var FlowRouter = void 0;                                                                                               // 1
module.import('meteor/kadira:flow-router', {                                                                           // 1
  "FlowRouter": function (v) {                                                                                         // 1
    FlowRouter = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var SSR = void 0;                                                                                                      // 1
module.import('meteor/meteorhacks:ssr', {                                                                              // 1
  "SSR": function (v) {                                                                                                // 1
    SSR = v;                                                                                                           // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var juice = void 0;                                                                                                    // 1
module.import('juice', {                                                                                               // 1
  "default": function (v) {                                                                                            // 1
    juice = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
process.env.MAIL_URL = 'smtp://AKIAIPCCALM47GMK7HNQ:AgPVMITLMu%2FEZexFDKSk6DKY71pJxOnmnnKMU9ffGdb0@email-smtp.us-east-1.amazonaws.com:465';
process.env.MAIL_FROM = 'Pampa Store <no-reply@pampa.store>';                                                          // 8
Meteor.methods({                                                                                                       // 10
  getInlineMail: function (template, data) {                                                                           // 11
    data = data || {};                                                                                                 // 12
    data.homeUrl = FlowRouter.url('home');                                                                             // 13
    data.logoUrl = process.env.LOGO_URL;                                                                               // 14
    var html = SSR.render(template, data);                                                                             // 16
    return juice(html);                                                                                                // 17
  },                                                                                                                   // 18
  contactEmail: function (data) {                                                                                      // 19
    Meteor.defer(function () {                                                                                         // 20
      try {                                                                                                            // 21
        Email.send({                                                                                                   // 22
          to: 'joaquin@pampa.store',                                                                                   // 23
          cc: 'ignacio@pampa.store',                                                                                   // 24
          from: data.email,                                                                                            // 25
          subject: "Formulario de contacto: " + data.subject,                                                          // 26
          html: Meteor.call('getInlineMail', 'emailsContactForm', data)                                                // 27
        });                                                                                                            // 22
      } catch (e) {                                                                                                    // 29
        console.log(e);                                                                                                // 30
        console.log('de:', process.env.MAIL_FROM = 'no-reply@pampa.store');                                            // 31
      }                                                                                                                // 32
    });                                                                                                                // 33
  }                                                                                                                    // 34
});                                                                                                                    // 10
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["../index","./emails","./register-api","./sitemaps","./prerender","./emailTemplates","./sku-migration.js","./cron","./pampa-publisher",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/index.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.import('../index');                                                                                             // 1
module.import('./emails');                                                                                             // 1
module.import('./register-api');                                                                                       // 1
module.import('./sitemaps');                                                                                           // 1
module.import('./prerender');                                                                                          // 1
module.import('./emailTemplates');                                                                                     // 1
module.import('./sku-migration.js');                                                                                   // 1
module.import('./cron');                                                                                               // 1
module.import('./pampa-publisher');                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"pampa-publisher.js":["meteor/meteor","meteor/mongo","meteor/http","underscore.string","../../api/items/items","../../api/items/sku","../../../entidades/orion/categories","underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/pampa-publisher.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Mongo = void 0;                                                                                                    // 1
module.import('meteor/mongo', {                                                                                        // 1
  "Mongo": function (v) {                                                                                              // 1
    Mongo = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var HTTP = void 0;                                                                                                     // 1
module.import('meteor/http', {                                                                                         // 1
  "HTTP": function (v) {                                                                                               // 1
    HTTP = v;                                                                                                          // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var unescapeHTML = void 0;                                                                                             // 1
module.import('underscore.string', {                                                                                   // 1
  "unescapeHTML": function (v) {                                                                                       // 1
    unescapeHTML = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var Items = void 0;                                                                                                    // 1
module.import('../../api/items/items', {                                                                               // 1
  "default": function (v) {                                                                                            // 1
    Items = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
var Sku = void 0;                                                                                                      // 1
module.import('../../api/items/sku', {                                                                                 // 1
  "default": function (v) {                                                                                            // 1
    Sku = v;                                                                                                           // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
var Categories = void 0;                                                                                               // 1
module.import('../../../entidades/orion/categories', {                                                                 // 1
  "default": function (v) {                                                                                            // 1
    Categories = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 6);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.import('underscore', {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 7);                                                                                                                 // 1
var Tokens = new Mongo.Collection('tokens');                                                                           // 10
global.Tokens = Tokens; /**                                                                                            // 11
                         * Mercadolibre's API Credentials                                                              //
                         */                                                                                            //
var clientId = '2800091695208966';                                                                                     // 16
var clientSecret = 'Hxe1W1uXOcLHk87K6pRm65YGRVtWecGW';                                                                 // 17
Meteor.methods({                                                                                                       // 19
  /**                                                                                                                  // 20
   * To save new tokens in the database. Tokens might be lost or get inactive and new ones need to be set.             //
   * @param  {string} accessToken  accessToken                                                                         //
   * @param  {string} refreshToken RefreshToken has to be asked to mercadolibre with it's api https://api.mercadolibre.com/oauth/token
   * @return void                                                                                                      //
   */putNewRefreshToken: function (accessToken, refreshToken) {                                                        //
    var token = Tokens.find().fetch();                                                                                 // 27
                                                                                                                       //
    if (token.lenght === 0) {                                                                                          // 28
      Tokens.insert({                                                                                                  // 29
        access_token: accessToken,                                                                                     // 29
        refresh_token: refreshToken                                                                                    // 29
      });                                                                                                              // 29
    } else {                                                                                                           // 30
      Tokens.update({}, {                                                                                              // 31
        $set: {                                                                                                        // 31
          access_token: accessToken,                                                                                   // 31
          refresh_token: refreshToken                                                                                  // 31
        }                                                                                                              // 31
      });                                                                                                              // 31
    }                                                                                                                  // 32
  },                                                                                                                   // 33
  /**                                                                                                                  // 34
   * Function to always get the latest token                                                                           //
   * @return void                                                                                                      //
   */getAccessToken: function () {                                                                                     //
    return Tokens.findOne().access_token;                                                                              // 39
  },                                                                                                                   // 40
  /**                                                                                                                  // 41
   * Function to always get the latest refresh token                                                                   //
   * @return void                                                                                                      //
   */getRefreshToken: function () {                                                                                    //
    return Tokens.findOne().refresh_token;                                                                             // 46
  },                                                                                                                   // 47
  /**                                                                                                                  // 48
   * Function to refresh the token. This Function has to run before every operation.                                   //
   * @return void                                                                                                      //
   */refreshToken: function () {                                                                                       //
    var params = {                                                                                                     // 53
      client_id: clientId,                                                                                             // 54
      client_secret: clientSecret,                                                                                     // 55
      refresh_token: Meteor.call('getRefreshToken'),                                                                   // 56
      grant_type: 'refresh_token'                                                                                      // 57
    };                                                                                                                 // 53
    var call = HTTP.call('POST', 'https://api.mercadolibre.com/oauth/token', {                                         // 59
      params: params                                                                                                   // 59
    });                                                                                                                // 59
    var tokens = {                                                                                                     // 60
      refresh_token: call.data.refresh_token,                                                                          // 60
      access_token: call.data.access_token                                                                             // 60
    };                                                                                                                 // 60
    Tokens.update({}, {                                                                                                // 61
      $set: tokens                                                                                                     // 61
    });                                                                                                                // 61
    return tokens;                                                                                                     // 62
  },                                                                                                                   // 63
  /**                                                                                                                  // 64
   * Published new Pampa Items                                                                                         //
   * @return void                                                                                                      //
   */pampaPublisher: function () {                                                                                     //
    console.log(new Date());                                                                                           // 69
    console.log('da1', Meteor.call('getAccessToken'), Meteor.call('getRefreshToken'));                                 // 70
    Meteor.call('refreshToken');                                                                                       // 71
    console.log('da2', Meteor.call('getAccessToken'), Meteor.call('getRefreshToken'));                                 // 72
    var items = Items.find().fetch();                                                                                  // 73
                                                                                                                       //
    _.each(items, function (item, index) {                                                                             // 74
      var skus = Sku.find({                                                                                            // 75
        itemId: item._id,                                                                                              // 75
        stock: {                                                                                                       // 75
          $gte: 5                                                                                                      // 75
        },                                                                                                             // 75
        meli: {                                                                                                        // 75
          $exists: false                                                                                               // 75
        }                                                                                                              // 75
      }).fetch();                                                                                                      // 75
                                                                                                                       //
      if (!_.isArray(item.category) || item.category.lenght === 0) {                                                   // 76
        return;                                                                                                        // 77
      }                                                                                                                // 78
                                                                                                                       //
      var itemCategory = Categories.findOne(item.category[0]);                                                         // 79
                                                                                                                       //
      _.each(skus, function (sku, index2) {                                                                            // 80
        var params = {                                                                                                 // 81
          title: itemCategory.name + " " + item.name,                                                                  // 82
          price: sku.shopPrice,                                                                                        // 83
          category_from: 'MLC1276'                                                                                     // 84
        };                                                                                                             // 81
        HTTP.call('GET', 'https://api.mercadolibre.com/sites/MLC/category_predictor/predict', {                        // 86
          params: params                                                                                               // 86
        }, function (error, result) {                                                                                  // 86
          if (error) {                                                                                                 // 87
            console.log('Error!! buscando categoria!!', error);                                                        // 88
          } else {                                                                                                     // 89
            if (!item.description) {                                                                                   // 90
              item.description = '';                                                                                   // 91
            }                                                                                                          // 92
                                                                                                                       //
            var publication = {                                                                                        // 93
              title: unescapeHTML(item.name),                                                                          // 94
              category_id: result.data.id,                                                                             // 95
              price: sku.shopPrice,                                                                                    // 96
              currency_id: 'CLP',                                                                                      // 97
              available_quantity: sku.stock,                                                                           // 98
              buying_mode: 'buy_it_now',                                                                               // 99
              listing_type_id: 'bronze',                                                                               // 100
              condition: 'new',                                                                                        // 101
              description: Meteor.call('constructDescription', item.description, sku),                                 // 102
              tags: ['immediate_payment'],                                                                             // 103
              pictures: _.map(sku.images, function (image, index3) {                                                   // 106
                return {                                                                                               // 107
                  source: image.url                                                                                    // 107
                };                                                                                                     // 107
              })                                                                                                       // 108
            };                                                                                                         // 93
            HTTP.call('POST', "https://api.mercadolibre.com/items?access_token=" + Meteor.call('getAccessToken'), {    // 111
              data: publication                                                                                        // 111
            }, function (error, result) {                                                                              // 111
              if (error) {                                                                                             // 112
                console.log('Error Publicando!', error);                                                               // 113
              } else {                                                                                                 // 114
                Sku.update(sku._id, {                                                                                  // 115
                  $set: {                                                                                              // 115
                    meli: result.data.id                                                                               // 115
                  }                                                                                                    // 115
                });                                                                                                    // 115
              }                                                                                                        // 116
            });                                                                                                        // 117
          }                                                                                                            // 118
        });                                                                                                            // 119
      });                                                                                                              // 120
    });                                                                                                                // 121
                                                                                                                       //
    console.log(new Date());                                                                                           // 122
  },                                                                                                                   // 123
  /**                                                                                                                  // 124
   * Update al the Publications from mercadolibre                                                                      //
   * @return void                                                                                                      //
   */pampaUpdater: function () {                                                                                       //
    console.log(new Date());                                                                                           // 129
    console.log('da1', Meteor.call('getAccessToken'), Meteor.call('getRefreshToken'));                                 // 130
    Meteor.call('refreshToken');                                                                                       // 131
    console.log('da2', Meteor.call('getAccessToken'), Meteor.call('getRefreshToken'));                                 // 132
    var items = Items.find().fetch();                                                                                  // 133
                                                                                                                       //
    _.each(items, function (item, index) {                                                                             // 134
      var skus = Sku.find({                                                                                            // 135
        itemId: item._id,                                                                                              // 135
        meli: {                                                                                                        // 135
          $nin: [null, false]                                                                                          // 135
        }                                                                                                              // 135
      }).fetch();                                                                                                      // 135
                                                                                                                       //
      _.each(skus, function (sku, index2) {                                                                            // 136
        var pictures = _.map(sku.images, function (image, index3) {                                                    // 137
          return {                                                                                                     // 138
            source: image.url                                                                                          // 138
          };                                                                                                           // 138
        });                                                                                                            // 139
                                                                                                                       //
        pictures.push({                                                                                                // 140
          source: 'https://pampa.store/pampa-logo.png'                                                                 // 140
        });                                                                                                            // 140
        var publication = {                                                                                            // 141
          title: unescapeHTML(item.name),                                                                              // 142
          price: sku.shopPrice,                                                                                        // 143
          currency_id: 'CLP',                                                                                          // 144
          available_quantity: sku.stock,                                                                               // 145
          buying_mode: 'buy_it_now',                                                                                   // 146
          condition: 'new',                                                                                            // 147
          tags: ['immediate_payment'],                                                                                 // 148
          pictures: pictures                                                                                           // 151
        };                                                                                                             // 141
                                                                                                                       //
        if (sku.stock <= 5) {                                                                                          // 154
          publication.status = 'paused';                                                                               // 155
        }                                                                                                              // 156
                                                                                                                       //
        HTTP.call('PUT', "https://api.mercadolibre.com/items/" + sku.meli + "?access_token=" + Meteor.call('getAccessToken'), {
          data: publication                                                                                            // 158
        }, function (error, result) {                                                                                  // 158
          if (error) {                                                                                                 // 159
            console.log('Error Publicando!', error);                                                                   // 160
          } else {                                                                                                     // 161
            console.log('Updated publication', sku.code, '\n'); // Sku.update(sku._id, {$set: {meli: result.data.id}})
          }                                                                                                            // 164
        });                                                                                                            // 165
      });                                                                                                              // 166
    });                                                                                                                // 167
                                                                                                                       //
    console.log(new Date());                                                                                           // 168
  },                                                                                                                   // 169
  /**                                                                                                                  // 170
   * Strangely Description has to be run in a separete API call                                                        //
   * @return void                                                                                                      //
   */pampaUpdateDescriptions: function () {                                                                            //
    console.log(new Date());                                                                                           // 175
    console.log('da1', Meteor.call('getAccessToken'), Meteor.call('getRefreshToken'));                                 // 176
    Meteor.call('refreshToken');                                                                                       // 177
    console.log('da2', Meteor.call('getAccessToken'), Meteor.call('getRefreshToken'));                                 // 178
    var items = Items.find().fetch();                                                                                  // 179
    var number = 1;                                                                                                    // 180
    console.log("There's a total of " + Sku.find({                                                                     // 181
      meli: {                                                                                                          // 181
        $nin: [null, false]                                                                                            // 181
      }                                                                                                                // 181
    }).count() + " skus");                                                                                             // 181
                                                                                                                       //
    _.each(items, function (item, index) {                                                                             // 182
      var skus = Sku.find({                                                                                            // 183
        itemId: item._id,                                                                                              // 183
        meli: {                                                                                                        // 183
          $nin: [null, false]                                                                                          // 183
        }                                                                                                              // 183
      }).fetch();                                                                                                      // 183
                                                                                                                       //
      _.each(skus, function (sku, index2) {                                                                            // 184
        var publication = {                                                                                            // 185
          text: Meteor.call('constructDescription', item.description, sku)                                             // 186
        };                                                                                                             // 185
        HTTP.call('PUT', "https://api.mercadolibre.com/items/" + sku.meli + "/description?access_token=" + Meteor.call('getAccessToken'), {
          data: publication                                                                                            // 189
        }, function (error, result) {                                                                                  // 189
          if (error) {                                                                                                 // 190
            console.log('Error Publicando!', error, sku.code);                                                         // 191
          } else {                                                                                                     // 192
            console.log('Updated description', sku.code, number, '\n');                                                // 193
            number++; // Sku.update(sku._id, {$set: {meli: result.data.id}})                                           // 194
          }                                                                                                            // 196
        });                                                                                                            // 197
      });                                                                                                              // 198
    });                                                                                                                // 199
  },                                                                                                                   // 200
  /**                                                                                                                  // 201
   * Updating shipping has to be done in a new process, This funcion updates all products shipping.                    //
   * @return void                                                                                                      //
   */pampaUpdateShipping: function () {                                                                                //
    Meteor.call('refreshToken');                                                                                       // 206
    var accessToken = Meteor.call('getAccessToken');                                                                   // 207
    var skus = Sku.find({                                                                                              // 208
      meli: {                                                                                                          // 208
        $nin: [null, false]                                                                                            // 208
      }                                                                                                                // 208
    }).fetch();                                                                                                        // 208
    var total = skus.length;                                                                                           // 209
    var number = 1;                                                                                                    // 210
                                                                                                                       //
    _.each(skus, function (sku, index) {                                                                               // 211
      if (!sku.meli) return;                                                                                           // 212
      var params = {                                                                                                   // 213
        'shipping': {                                                                                                  // 214
          'mode': 'me2',                                                                                               // 215
          'local_pick_up': true                                                                                        // 216
        }                                                                                                              // 214
      };                                                                                                               // 213
      HTTP.call('PUT', "https://api.mercadolibre.com/items/" + sku.meli + "?access_token=" + accessToken, {            // 219
        data: params                                                                                                   // 219
      }, function (error, result) {                                                                                    // 219
        if (error) {                                                                                                   // 220
          console.log('Error! Actualizando Shipping', sku.code, error);                                                // 221
        } else {                                                                                                       // 222
          console.log("Updated shipping of " + sku.code + " " + number + " from a total of " + total);                 // 223
        }                                                                                                              // 224
                                                                                                                       //
        number++;                                                                                                      // 225
      });                                                                                                              // 226
    });                                                                                                                // 227
  },                                                                                                                   // 228
  /**                                                                                                                  // 229
   * Creates a stylish description for mercadolibre                                                                    //
   * @param  {string} description The description that is going to be the body of the description                      //
   * @param  {object} sku         The sku object of the item's description. Is used to add a list to the description with the sku attributes.
   * @return void                                                                                                      //
   */constructDescription: function (description, sku) {                                                               //
    description = description || '';                                                                                   // 236
    var theCode = sku.code;                                                                                            // 237
    var simpleSchema = Items.simpleSchema();                                                                           // 238
    var header = '<div style="display: flex; align-items: center; justify-content: center; border-bottom: 1px solid #d9d9d9; border-top: 1px solid #d9d9d9; margin: 0 auto; margin-bottom: 50px; padding: 20px 0; background-color: #424242; color: #fff"><img src="https://pampa.store/pampa-logo.png" height="150" width="150" style="display: inline-block"><span style="margin-left: 50px; font-size: 50px">Pampa Store</span></div>';
    sku = _.omit(sku, 'images', 'extremePrice', 'price', 'shopPrice', 'stock', 'url', 'code', '_id', 'itemId', 'meli');
    var skuList = '<ul>';                                                                                              // 244
                                                                                                                       //
    _.each(sku, function (skuData, skuKey) {                                                                           // 245
      var attribute = simpleSchema.schema(skuKey);                                                                     // 246
                                                                                                                       //
      if (attribute.orion) {                                                                                           // 247
        var options = [skuData];                                                                                       // 248
        var items = attribute.orion.collection.find({                                                                  // 249
          _id: {                                                                                                       // 249
            $in: options                                                                                               // 249
          }                                                                                                            // 249
        }).fetch();                                                                                                    // 249
        items = _.map(items, function (item) {                                                                         // 250
          return item[attribute.orion.titleField];                                                                     // 251
        });                                                                                                            // 252
        skuData = items.join(', ');                                                                                    // 253
      }                                                                                                                // 254
                                                                                                                       //
      if (skuData === false) {                                                                                         // 255
        skuData = 'No';                                                                                                // 256
      } else if (skuData === true) {                                                                                   // 257
        skuData = 'Si';                                                                                                // 258
      }                                                                                                                // 259
                                                                                                                       //
      skuList += "<li><strong>" + attribute.label + ": </strong>" + skuData + "</li>";                                 // 261
    });                                                                                                                // 262
                                                                                                                       //
    skuList += "</ul>";                                                                                                // 263
    var skuFooter = "<div style='padding: 10px 0; width: 100%; text-align: center; background-color: #fff059; border: 1px solid #d9d9d9; border-left: inherit; border-right: inherit; font-size: 20px; font-weight: 600; margin-top: 50px'><div style='width: 50%; display: inline-block;'><img style=\"height: 300px\" src='https://pampa.store/catedral2247.png' /><span style=\"display: block;\">Horarios: Martes de 17:00 a 21:00 y Viernes de 16:00 a 20:00</span></div><div style='width: 50%; display: inline-block;'><img style=\"height: 300px\" src='https://pampa.store/logo-mercadoenvios.png' /><span style=\"display: block;\">Env\xEDos por MercadoEnv\xEDos</span></div></div>";
    var skuCode = "<span style=\"color: white; display: block\">" + theCode + "</span>";                               // 267
    return header + skuList + description + skuFooter + skuCode;                                                       // 269
  }                                                                                                                    // 270
});                                                                                                                    // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"prerender.js":["meteor/meteor","meteor/webapp","prerender-node",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/prerender.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var WebApp = void 0;                                                                                                   // 1
module.import('meteor/webapp', {                                                                                       // 1
  "WebApp": function (v) {                                                                                             // 1
    WebApp = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var prerenderio = void 0;                                                                                              // 1
module.import('prerender-node', {                                                                                      // 1
  "default": function (v) {                                                                                            // 1
    prerenderio = v;                                                                                                   // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
Meteor.startup(function () {                                                                                           // 5
  var settings = Meteor.settings.PrerenderIO;                                                                          // 6
                                                                                                                       //
  if (settings && settings.token && settings.host) {                                                                   // 7
    prerenderio.set('prerenderToken', settings.token);                                                                 // 8
    prerenderio.set('host', settings.host);                                                                            // 9
    prerenderio.set('protocol', 'https');                                                                              // 10
    WebApp.rawConnectHandlers.use(prerenderio);                                                                        // 11
  }                                                                                                                    // 12
});                                                                                                                    // 13
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"register-api.js":["../../api/items/server/publications","../../api/items/server/methods","../../api/categories/server/publications",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/register-api.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.import('../../api/items/server/publications');                                                                  // 1
module.import('../../api/items/server/methods');                                                                       // 1
module.import('../../api/categories/server/publications');                                                             // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"sitemaps.js":["meteor/meteor","meteor/gadicohen:sitemaps",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/sitemaps.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var sitemaps = void 0;                                                                                                 // 1
module.import('meteor/gadicohen:sitemaps', {                                                                           // 1
  "sitemaps": function (v) {                                                                                           // 1
    sitemaps = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
sitemaps.config('rootUrl', 'https://pampa.store/');                                                                    // 4
sitemaps.add('/sitemap.xml', function () {                                                                             // 6
  // required: page                                                                                                    // 7
  // optional: lastmod, changefreq, priority, xhtmlLinks, images, videos                                               // 8
  return [{                                                                                                            // 9
    page: '/armado',                                                                                                   // 10
    lastmod: new Date('02-08-2017')                                                                                    // 10
  }, {                                                                                                                 // 10
    page: '/contacto',                                                                                                 // 11
    lastmod: new Date('02-08-2017')                                                                                    // 11
  }, {                                                                                                                 // 11
    page: '/categorias',                                                                                               // 12
    lastmod: new Date('02-08-2017')                                                                                    // 12
  }, {                                                                                                                 // 12
    page: '/accesorios',                                                                                               // 13
    lastmod: new Date('02-08-2017')                                                                                    // 13
  }, {                                                                                                                 // 13
    page: '/bicicletas',                                                                                               // 14
    lastmod: new Date('02-08-2017')                                                                                    // 14
  }, {                                                                                                                 // 14
    page: '/indumentaria',                                                                                             // 15
    lastmod: new Date('02-08-2017')                                                                                    // 15
  }, {                                                                                                                 // 15
    page: '/accesorios',                                                                                               // 16
    lastmod: new Date('02-08-2017')                                                                                    // 16
  }];                                                                                                                  // 16
});                                                                                                                    // 18
Meteor.methods({                                                                                                       // 20
  'addSiteMap': function (array) {                                                                                     // 21
    sitemaps.add('/sitemap.xml', function () {                                                                         // 22
      return array;                                                                                                    // 23
    });                                                                                                                // 24
  }                                                                                                                    // 25
});                                                                                                                    // 20
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"sku-migration.js":["meteor/meteor","../../api/items/items","../../api/items/sku","underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/sku-migration.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Items = void 0;                                                                                                    // 1
module.import('../../api/items/items', {                                                                               // 1
  "default": function (v) {                                                                                            // 1
    Items = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Sku = void 0;                                                                                                      // 1
module.import('../../api/items/sku', {                                                                                 // 1
  "default": function (v) {                                                                                            // 1
    Sku = v;                                                                                                           // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.import('underscore', {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
// should change to lodash                                                                                             // 4
Meteor.methods({                                                                                                       // 6
  'skuMigrate': function () {                                                                                          // 7
    var errors = 0;                                                                                                    // 8
    var itemsCount = 0;                                                                                                // 9
    var skuCount = 0;                                                                                                  // 10
    console.log('Starting Sku Migrations');                                                                            // 11
    var items = Items.find({}).fetch();                                                                                // 12
    console.log(items.length + " will be migrated...");                                                                // 13
                                                                                                                       //
    _.each(items, function (item, index) {                                                                             // 14
      _.each(item.sku, function (sku, index2) {                                                                        // 15
        try {                                                                                                          // 16
          Sku.insert(Object.assign(sku, {                                                                              // 17
            itemId: item._id                                                                                           // 17
          }));                                                                                                         // 17
        } catch (e) {                                                                                                  // 18
          // console.log(e, 'sku:', sku.code)                                                                          // 19
          if (e.code !== 11000) {                                                                                      // 20
            console.log(e);                                                                                            // 21
          }                                                                                                            // 22
                                                                                                                       //
          console.log('sku already exists', item._id, sku.code);                                                       // 23
          errors++;                                                                                                    // 24
          skuCount--;                                                                                                  // 25
        }                                                                                                              // 26
                                                                                                                       //
        skuCount++;                                                                                                    // 27
      });                                                                                                              // 28
                                                                                                                       //
      Items.update(item._id, {                                                                                         // 29
        $unset: {                                                                                                      // 29
          sku: 1                                                                                                       // 29
        }                                                                                                              // 29
      });                                                                                                              // 29
      itemsCount++;                                                                                                    // 30
    });                                                                                                                // 31
                                                                                                                       //
    console.log("Operation finished with " + itemsCount + " migrated items, " + skuCount + " sku created and " + errors + " errors");
  },                                                                                                                   // 33
  skuMigrateSingle: function (itemId) {                                                                                // 34
    var errors = 0;                                                                                                    // 35
    var skuCount = 0;                                                                                                  // 36
    var item = Items.findOne(itemId);                                                                                  // 37
    if (!item) return false;                                                                                           // 38
                                                                                                                       //
    _.each(item.sku, function (sku, index2) {                                                                          // 39
      try {                                                                                                            // 40
        Sku.insert(Object.assign(sku, {                                                                                // 41
          itemId: item._id                                                                                             // 41
        }));                                                                                                           // 41
      } catch (e) {                                                                                                    // 42
        if (e.code !== 11000) {                                                                                        // 43
          console.log(e);                                                                                              // 44
        }                                                                                                              // 45
                                                                                                                       //
        console.log('sku already exists', item._id, sku.code);                                                         // 46
        errors++;                                                                                                      // 47
        skuCount--;                                                                                                    // 48
      }                                                                                                                // 49
                                                                                                                       //
      skuCount++;                                                                                                      // 50
    });                                                                                                                // 51
                                                                                                                       //
    Items.update(item._id, {                                                                                           // 52
      $unset: {                                                                                                        // 52
        sku: 1                                                                                                         // 52
      }                                                                                                                // 52
    });                                                                                                                // 52
    console.log("Operation finished with " + skuCount + " sku created and " + errors + " errors");                     // 53
  }                                                                                                                    // 54
});                                                                                                                    // 6
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"index.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/index.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
SimpleSchema.extendOptions({                                                                                           // 1
  srf: Match.Optional(Object)                                                                                          // 2
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"entidades":{"dictionary":{"index.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// entidades/dictionary/index.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
orion.dictionary.addDefinition('foto1', 'index', orion.attribute('image', {                                            // 1
  label: 'Foto 1',                                                                                                     // 3
  optional: true                                                                                                       // 4
}));                                                                                                                   // 2
orion.dictionary.addDefinition('texto1', 'index', orion.attribute('image', {                                           // 8
  label: 'Texto 1',                                                                                                    // 10
  optional: true                                                                                                       // 11
}));                                                                                                                   // 9
orion.dictionary.addDefinition('foto2', 'index', orion.attribute('image', {                                            // 15
  label: 'Foto 2',                                                                                                     // 17
  optional: true                                                                                                       // 18
}));                                                                                                                   // 16
orion.dictionary.addDefinition('foto3', 'index', orion.attribute('image', {                                            // 22
  label: 'Foto 3',                                                                                                     // 24
  optional: true                                                                                                       // 25
}));                                                                                                                   // 23
orion.dictionary.addDefinition('foto4', 'index', orion.attribute('image', {                                            // 29
  label: 'Foto 4',                                                                                                     // 31
  optional: true                                                                                                       // 32
}));                                                                                                                   // 30
orion.dictionary.addDefinition('foto5', 'index', orion.attribute('image', {                                            // 36
  label: 'Foto 5',                                                                                                     // 38
  optional: true                                                                                                       // 39
}));                                                                                                                   // 37
orion.dictionary.addDefinition('companyName', 'site', {                                                                // 43
  type: String,                                                                                                        // 45
  label: 'Nombre empresa',                                                                                             // 46
  optional: true                                                                                                       // 47
});                                                                                                                    // 44
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"layout.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// entidades/dictionary/layout.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
orion.dictionary.addDefinition('siteName', 'home', {                                                                   // 1
  type: String,                                                                                                        // 2
  label: 'Nombre del Sitio',                                                                                           // 3
  defaultValue: 'Arma tu bicicleta'                                                                                    // 4
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"orion":{"_init.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// entidades/orion/_init.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
ItemsSuppliers = new orion.collection('itemsSuppliers', {                                                              // 2
  singularName: 'ItemsSupplier',                                                                                       // 3
  pluralName: 'ItemsSuppliers',                                                                                        // 4
  link: {                                                                                                              // 5
    title: 'ItemsSuppliers'                                                                                            // 6
  },                                                                                                                   // 5
  tabular: {                                                                                                           // 8
    columns: [orion.attributeColumn('hasOne', 'item', 'Item'), orion.attributeColumn('hasOne', 'supplier', 'Proveedor'), {
      data: 'code',                                                                                                    // 12
      title: 'Código'                                                                                                  // 12
    }, {                                                                                                               // 12
      data: 'ammount',                                                                                                 // 13
      title: 'Cantidad'                                                                                                // 13
    }, {                                                                                                               // 13
      data: 'price',                                                                                                   // 14
      title: 'Precio'                                                                                                  // 14
    }, {                                                                                                               // 14
      data: 'url',                                                                                                     // 15
      title: 'URL'                                                                                                     // 15
    }]                                                                                                                 // 15
  }                                                                                                                    // 8
});                                                                                                                    // 2
Suppliers = new orion.collection('suppliers', {                                                                        // 20
  singularName: 'Proveedor',                                                                                           // 21
  pluralName: 'Proveedores',                                                                                           // 22
  link: {                                                                                                              // 23
    title: 'Proveedores'                                                                                               // 24
  },                                                                                                                   // 23
  tabular: {                                                                                                           // 26
    columns: [orion.attributeColumn('image', 'image', 'Imagen'), {                                                     // 27
      data: 'name',                                                                                                    // 29
      title: 'Nombre'                                                                                                  // 29
    }]                                                                                                                 // 29
  }                                                                                                                    // 26
});                                                                                                                    // 20
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"attributes.js":["meteor/orionjs:core","meteor/aldeed:simple-schema","./categories",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// entidades/orion/attributes.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var orion = void 0;                                                                                                    // 1
module.import('meteor/orionjs:core', {                                                                                 // 1
  "orion": function (v) {                                                                                              // 1
    orion = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var SimpleSchema = void 0;                                                                                             // 1
module.import('meteor/aldeed:simple-schema', {                                                                         // 1
  "SimpleSchema": function (v) {                                                                                       // 1
    SimpleSchema = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Categories = void 0;                                                                                               // 1
module.import('./categories', {                                                                                        // 1
  "default": function (v) {                                                                                            // 1
    Categories = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Attributes = new orion.collection('attributes', {                                                                  // 5
  singularName: 'Atributo',                                                                                            // 6
  pluralName: 'Atributos',                                                                                             // 7
  link: {                                                                                                              // 8
    title: 'Atributos'                                                                                                 // 9
  },                                                                                                                   // 8
  tabular: {                                                                                                           // 11
    columns: [orion.attributeColumn('hasOne', 'category', 'Categoría')]                                                // 12
  }                                                                                                                    // 11
});                                                                                                                    // 5
Attributes.attachSchema(new SimpleSchema({                                                                             // 18
  category: orion.attribute('hasOne', {                                                                                // 19
    label: 'Categoría',                                                                                                // 20
    optional: true                                                                                                     // 21
  }, {                                                                                                                 // 19
    collection: Categories,                                                                                            // 23
    titleField: 'name',                                                                                                // 24
    publicationName: 'categoriesAttributes'                                                                            // 25
  }),                                                                                                                  // 22
  attributes: {                                                                                                        // 27
    type: [String],                                                                                                    // 28
    label: 'Atributos',                                                                                                // 29
    allowedValues: ['frontDerailleaurPull', 'frontDerailleaurMount', 'frontDerailleaurWidth', 'rearDerailleaurMount', 'hidraulicCable', 'bbsize', 'seatTubeSize', 'SeatClampSize', 'headSetSize', 'headSetType', 'headSetConical', 'frameShockSize', 'rearBrakeType', 'frontBrakeType', 'axleSize', 'axleWidth', 'travel', 'handleWidth', 'forkWidth', 'frontRotorSize', 'frontRotorType', 'rearRotorType', 'rearRotorSize', 'rimDiameter', 'rearHubWidth', 'rearHubDiameter', 'frontTyreWidth', 'rearTyreWidth', 'frontHoles', 'rearHoles', 'frontSpeedsNumber', 'rearSpeedsNumber', 'rearBlockType', 'seatMount', 'pannierRack', 'crankSetType', 'shifterRatio', 'handlebarType', 'cassetteType'],
    autoform: {                                                                                                        // 31
      noselect: true                                                                                                   // 32
    }                                                                                                                  // 31
  },                                                                                                                   // 27
  createdBy: orion.attribute('createdBy'),                                                                             // 36
  createdAt: orion.attribute('createdAt')                                                                              // 37
}));                                                                                                                   // 18
module.export("default", exports.default = Attributes);                                                                // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"brands.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// entidades/orion/brands.js                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Brands = new orion.collection('brands', {                                                                          // 1
  singularName: 'Marca',                                                                                               // 2
  pluralName: 'Marcas',                                                                                                // 3
  link: {                                                                                                              // 4
    title: 'Marcas'                                                                                                    // 5
  },                                                                                                                   // 4
  tabular: {                                                                                                           // 7
    columns: [orion.attributeColumn('image', 'image', 'Image'), {                                                      // 8
      data: 'name',                                                                                                    // 10
      title: 'Nombre'                                                                                                  // 10
    }, {                                                                                                               // 10
      data: 'url',                                                                                                     // 11
      title: 'URL'                                                                                                     // 11
    }]                                                                                                                 // 11
  }                                                                                                                    // 7
});                                                                                                                    // 1
Brands.attachSchema(new SimpleSchema({                                                                                 // 16
  name: {                                                                                                              // 17
    type: String,                                                                                                      // 18
    label: 'Nombre'                                                                                                    // 19
  },                                                                                                                   // 17
  url: {                                                                                                               // 21
    type: String,                                                                                                      // 22
    label: 'URL',                                                                                                      // 23
    optional: true                                                                                                     // 24
  },                                                                                                                   // 21
  image: orion.attribute('image', {                                                                                    // 26
    label: 'Foto',                                                                                                     // 27
    optional: true                                                                                                     // 28
  }),                                                                                                                  // 26
  createdBy: orion.attribute('createdBy'),                                                                             // 31
  createdAt: orion.attribute('createdAt')                                                                              // 32
}));                                                                                                                   // 16
module.export("default", exports.default = Brands);                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"categories.js":["../../lib/reemplazartildes","meteor/aldeed:simple-schema","meteor/orionjs:core",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// entidades/orion/categories.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var reemplazartildes = void 0;                                                                                         // 1
module.import('../../lib/reemplazartildes', {                                                                          // 1
  "default": function (v) {                                                                                            // 1
    reemplazartildes = v;                                                                                              // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var SimpleSchema = void 0;                                                                                             // 1
module.import('meteor/aldeed:simple-schema', {                                                                         // 1
  "SimpleSchema": function (v) {                                                                                       // 1
    SimpleSchema = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var orion = void 0;                                                                                                    // 1
module.import('meteor/orionjs:core', {                                                                                 // 1
  "orion": function (v) {                                                                                              // 1
    orion = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Categories = new orion.collection('categories', {                                                                  // 5
  singularName: 'Categoría',                                                                                           // 6
  pluralName: 'Categorías',                                                                                            // 7
  link: {                                                                                                              // 8
    title: 'Categorías'                                                                                                // 9
  },                                                                                                                   // 8
  tabular: {                                                                                                           // 11
    columns: [orion.attributeColumn('image', 'image', 'Image'), {                                                      // 12
      data: 'name',                                                                                                    // 14
      title: 'Nombre'                                                                                                  // 14
    }, {                                                                                                               // 14
      data: 'code',                                                                                                    // 15
      title: 'Código'                                                                                                  // 15
    }]                                                                                                                 // 15
  }                                                                                                                    // 11
});                                                                                                                    // 5
Categories.attachSchema(new SimpleSchema({                                                                             // 20
  name: {                                                                                                              // 21
    type: String,                                                                                                      // 22
    label: 'Nombre'                                                                                                    // 23
  },                                                                                                                   // 21
  code: {                                                                                                              // 25
    type: String,                                                                                                      // 26
    label: 'Código',                                                                                                   // 27
    optional: true                                                                                                     // 28
  },                                                                                                                   // 25
  image: orion.attribute('image', {                                                                                    // 30
    label: 'Foto',                                                                                                     // 31
    optional: true                                                                                                     // 32
  }),                                                                                                                  // 30
  slug: {                                                                                                              // 34
    type: String,                                                                                                      // 35
    index: 1,                                                                                                          // 36
    label: 'Slug',                                                                                                     // 37
    autoform: {                                                                                                        // 38
      omit: true                                                                                                       // 39
    },                                                                                                                 // 38
    autoValue: function () {                                                                                           // 41
      if (this.field('name').isSet) {                                                                                  // 42
        return reemplazartildes(this.field('name').value.toLowerCase());                                               // 43
      }                                                                                                                // 44
    }                                                                                                                  // 45
  },                                                                                                                   // 34
  armado: {                                                                                                            // 47
    type: Boolean,                                                                                                     // 48
    label: 'Armado',                                                                                                   // 49
    optional: true                                                                                                     // 50
  },                                                                                                                   // 47
  accessory: {                                                                                                         // 52
    type: Boolean,                                                                                                     // 53
    label: 'Accesorio',                                                                                                // 54
    optional: true                                                                                                     // 55
  },                                                                                                                   // 52
  dress: {                                                                                                             // 57
    type: Boolean,                                                                                                     // 58
    label: 'Indumentaria',                                                                                             // 59
    optional: true                                                                                                     // 60
  },                                                                                                                   // 57
  bicycles: {                                                                                                          // 62
    type: Boolean,                                                                                                     // 63
    label: 'Bicicletas',                                                                                               // 64
    optional: true                                                                                                     // 65
  },                                                                                                                   // 62
  hidden: {                                                                                                            // 67
    type: Boolean,                                                                                                     // 68
    label: 'Escondido',                                                                                                // 69
    optional: true                                                                                                     // 70
  },                                                                                                                   // 67
  createdBy: orion.attribute('createdBy'),                                                                             // 72
  createdAt: orion.attribute('createdAt')                                                                              // 73
}));                                                                                                                   // 20
module.export("default", exports.default = Categories);                                                                // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"colors.js":["meteor/orionjs:core","meteor/aldeed:simple-schema",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// entidades/orion/colors.js                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var orion = void 0;                                                                                                    // 1
module.import('meteor/orionjs:core', {                                                                                 // 1
  "orion": function (v) {                                                                                              // 1
    orion = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var SimpleSchema = void 0;                                                                                             // 1
module.import('meteor/aldeed:simple-schema', {                                                                         // 1
  "SimpleSchema": function (v) {                                                                                       // 1
    SimpleSchema = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Colors = new orion.collection('colors', {                                                                          // 4
  singularName: 'Color',                                                                                               // 5
  pluralName: 'Colores',                                                                                               // 6
  link: {                                                                                                              // 7
    title: 'Colores'                                                                                                   // 8
  },                                                                                                                   // 7
  tabular: {                                                                                                           // 10
    columns: [orion.attributeColumn('image', 'image', 'Image'), {                                                      // 11
      data: 'glosa',                                                                                                   // 13
      title: 'Glosa'                                                                                                   // 13
    }, {                                                                                                               // 13
      data: 'code',                                                                                                    // 15
      title: 'Código',                                                                                                 // 16
      render: function (val, type, doc) {                                                                              // 17
        return '<div style="background-color: ' + val + '; height: 12px; width: 12px;"></div>';                        // 18
      }                                                                                                                // 19
    }]                                                                                                                 // 14
  }                                                                                                                    // 10
});                                                                                                                    // 4
Colors.attachSchema(new SimpleSchema({                                                                                 // 25
  glosa: {                                                                                                             // 26
    type: String,                                                                                                      // 27
    label: 'Glosa'                                                                                                     // 28
  },                                                                                                                   // 26
  code: {                                                                                                              // 30
    type: String,                                                                                                      // 31
    label: 'Código',                                                                                                   // 32
    optional: true                                                                                                     // 33
  },                                                                                                                   // 30
  image: orion.attribute('image', {                                                                                    // 35
    label: 'Foto',                                                                                                     // 36
    optional: true                                                                                                     // 37
  }),                                                                                                                  // 35
  createdBy: orion.attribute('createdBy'),                                                                             // 40
  createdAt: orion.attribute('createdAt')                                                                              // 41
}));                                                                                                                   // 25
module.export("default", exports.default = Colors);                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"itemsSuppliers.js":["../../imports/api/items/items",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// entidades/orion/itemsSuppliers.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Items = void 0;                                                                                                    // 1
module.import('../../imports/api/items/items', {                                                                       // 1
    "default": function (v) {                                                                                          // 1
        Items = v;                                                                                                     // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
ItemsSuppliers.attachSchema(new SimpleSchema({                                                                         // 4
    amount: {                                                                                                          // 5
        type: String,                                                                                                  // 6
        label: "Cantidad"                                                                                              // 7
    },                                                                                                                 // 5
    code: {                                                                                                            // 9
        type: String,                                                                                                  // 10
        label: "Código"                                                                                                // 11
    },                                                                                                                 // 9
    url: {                                                                                                             // 13
        type: String,                                                                                                  // 14
        label: "URL"                                                                                                   // 15
    },                                                                                                                 // 13
    price: {                                                                                                           // 17
        type: Number,                                                                                                  // 18
        label: "Precio"                                                                                                // 19
    },                                                                                                                 // 17
    item: orion.attribute('hasOne', {                                                                                  // 21
        label: 'Item'                                                                                                  // 22
    }, {                                                                                                               // 21
        collection: Items,                                                                                             // 24
        titleField: 'name',                                                                                            // 25
        publicationName: 'items'                                                                                       // 26
    }),                                                                                                                // 23
    supplier: orion.attribute('hasOne', {                                                                              // 28
        label: 'Proveedor'                                                                                             // 29
    }, {                                                                                                               // 28
        collection: Suppliers,                                                                                         // 31
        titleField: 'name',                                                                                            // 32
        publicationName: 'suppliers'                                                                                   // 33
    }),                                                                                                                // 30
    createdBy: orion.attribute('createdBy'),                                                                           // 37
    createdAt: orion.attribute('createdAt')                                                                            // 38
}));                                                                                                                   // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"materials.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// entidades/orion/materials.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Materials = new orion.collection('materials', {                                                                    // 1
  singularName: 'Material',                                                                                            // 2
  pluralName: 'Materiales',                                                                                            // 3
  link: {                                                                                                              // 4
    title: 'Materiales'                                                                                                // 5
  },                                                                                                                   // 4
  tabular: {                                                                                                           // 7
    columns: [{                                                                                                        // 8
      data: 'name',                                                                                                    // 9
      title: 'Nombre'                                                                                                  // 9
    }]                                                                                                                 // 9
  }                                                                                                                    // 7
});                                                                                                                    // 1
Materials.attachSchema(new SimpleSchema({                                                                              // 14
  name: {                                                                                                              // 15
    type: String,                                                                                                      // 16
    label: 'Nombre'                                                                                                    // 17
  },                                                                                                                   // 15
  createdBy: orion.attribute('createdBy'),                                                                             // 20
  createdAt: orion.attribute('createdAt')                                                                              // 21
}));                                                                                                                   // 14
module.export("default", exports.default = Materials);                                                                 // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"orders.js":["meteor/orionjs:core","meteor/aldeed:simple-schema",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// entidades/orion/orders.js                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var orion = void 0;                                                                                                    // 1
module.import('meteor/orionjs:core', {                                                                                 // 1
  "orion": function (v) {                                                                                              // 1
    orion = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var SimpleSchema = void 0;                                                                                             // 1
module.import('meteor/aldeed:simple-schema', {                                                                         // 1
  "SimpleSchema": function (v) {                                                                                       // 1
    SimpleSchema = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Orders = new orion.collection('orders', {                                                                          // 4
  singularName: 'Orden',                                                                                               // 5
  pluralName: 'Ordenes',                                                                                               // 6
  link: {                                                                                                              // 7
    title: 'Ordenes'                                                                                                   // 8
  },                                                                                                                   // 7
  tabular: {                                                                                                           // 10
    columns: [{                                                                                                        // 11
      data: 'name',                                                                                                    // 12
      title: 'Nombre'                                                                                                  // 12
    }, {                                                                                                               // 12
      data: 'email',                                                                                                   // 13
      title: 'Email'                                                                                                   // 13
    }, {                                                                                                               // 13
      data: 'phone',                                                                                                   // 14
      title: 'Teléfono'                                                                                                // 14
    }, {                                                                                                               // 14
      data: 'address',                                                                                                 // 15
      title: 'Dirección'                                                                                               // 15
    }, {                                                                                                               // 15
      data: 'total',                                                                                                   // 16
      title: 'Total'                                                                                                   // 16
    }, {                                                                                                               // 16
      data: 'paid',                                                                                                    // 17
      title: 'Pagado'                                                                                                  // 17
    }, {                                                                                                               // 17
      data: 'createdAt',                                                                                               // 18
      title: 'Fecha'                                                                                                   // 18
    }]                                                                                                                 // 18
  }                                                                                                                    // 10
});                                                                                                                    // 4
Orders.attachSchema(new SimpleSchema({                                                                                 // 23
  items: {                                                                                                             // 24
    type: [Object],                                                                                                    // 25
    label: 'Items'                                                                                                     // 26
  },                                                                                                                   // 24
  'items.$.itemId': {                                                                                                  // 28
    type: String,                                                                                                      // 29
    label: 'Item'                                                                                                      // 30
  },                                                                                                                   // 28
  'items.$.cantidad': {                                                                                                // 32
    type: Number,                                                                                                      // 33
    label: 'Cantidad'                                                                                                  // 34
  },                                                                                                                   // 32
  'items.$.sku': {                                                                                                     // 36
    type: String,                                                                                                      // 37
    label: 'Sku'                                                                                                       // 38
  },                                                                                                                   // 36
  'items.$.sellPrice': {                                                                                               // 40
    type: Number,                                                                                                      // 41
    label: 'Precio Venta'                                                                                              // 42
  },                                                                                                                   // 40
  email: {                                                                                                             // 44
    type: String,                                                                                                      // 45
    label: 'Email'                                                                                                     // 46
  },                                                                                                                   // 44
  name: {                                                                                                              // 48
    type: String,                                                                                                      // 49
    label: 'Nombre'                                                                                                    // 50
  },                                                                                                                   // 48
  phone: {                                                                                                             // 52
    type: String,                                                                                                      // 53
    label: 'Teléfono'                                                                                                  // 54
  },                                                                                                                   // 52
  address: {                                                                                                           // 56
    type: String,                                                                                                      // 57
    label: 'Dirección'                                                                                                 // 58
  },                                                                                                                   // 56
  total: {                                                                                                             // 60
    type: Number,                                                                                                      // 61
    label: 'Total',                                                                                                    // 62
    optional: true                                                                                                     // 63
  },                                                                                                                   // 60
  paid: {                                                                                                              // 65
    type: Boolean,                                                                                                     // 66
    label: 'Pagado' // AutoValue: function() {                                                                         // 67
    //   if (this.isInsert) {                                                                                          // 69
    //     return false                                                                                                // 70
    //   } else if (this.isUpdate) {                                                                                   // 71
    //     if (Meteor.isServer) {                                                                                      // 72
    //       return false                                                                                              // 73
    //     } else {                                                                                                    // 74
    //       this.unset()                                                                                              // 75
    //     }                                                                                                           // 76
    //   } else {                                                                                                      // 77
    //     this.unset()  // Prevent user from supplying their own value                                                // 78
    //   }                                                                                                             // 79
    // },                                                                                                              // 80
                                                                                                                       //
  },                                                                                                                   // 65
  status: {                                                                                                            // 83
    type: String,                                                                                                      // 84
    label: 'Estado',                                                                                                   // 85
    allowedValues: ['En proceso', 'En armado', 'En despacho', 'Finalizado'],                                           // 86
    optional: true                                                                                                     // 87
  },                                                                                                                   // 83
  createdBy: orion.attribute('createdBy'),                                                                             // 90
  createdAt: orion.attribute('createdAt')                                                                              // 91
}));                                                                                                                   // 23
Orders.allow({                                                                                                         // 94
  insert: function (userId, doc) {                                                                                     // 95
    // Anyone can add                                                                                                  // 96
    return true;                                                                                                       // 97
  }                                                                                                                    // 98
});                                                                                                                    // 94
module.export("default", exports.default = Orders);                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"suppliers.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// entidades/orion/suppliers.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Suppliers.attachSchema(new SimpleSchema({                                                                              // 1
    name: {                                                                                                            // 2
        type: String,                                                                                                  // 3
        label: "Nombre"                                                                                                // 4
    },                                                                                                                 // 2
    url: {                                                                                                             // 6
        type: String,                                                                                                  // 7
        label: "URL",                                                                                                  // 8
        optional: true                                                                                                 // 9
    },                                                                                                                 // 6
    username: {                                                                                                        // 11
        type: String,                                                                                                  // 12
        label: "Usuario",                                                                                              // 13
        optional: true                                                                                                 // 14
    },                                                                                                                 // 11
    password: {                                                                                                        // 16
        type: String,                                                                                                  // 17
        label: "Contraseña",                                                                                           // 18
        optional: true                                                                                                 // 19
    },                                                                                                                 // 16
    image: orion.attribute('image', {                                                                                  // 21
        label: 'Foto',                                                                                                 // 22
        optional: true                                                                                                 // 23
    }),                                                                                                                // 21
    createdBy: orion.attribute('createdBy'),                                                                           // 27
    createdAt: orion.attribute('createdAt')                                                                            // 28
}));                                                                                                                   // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"mkr":{"login.js":["meteor/meteor","meteor/http","cheerio","request","stream","../../imports/api/items/items","../../imports/api/items/sku","underscore","underscore.string",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/mkr/login.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
  uploadImage: function () {                                                                                           // 1
    return uploadImage;                                                                                                // 1
  }                                                                                                                    // 1
});                                                                                                                    // 1
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var HTTP = void 0;                                                                                                     // 1
module.import('meteor/http', {                                                                                         // 1
  "HTTP": function (v) {                                                                                               // 1
    HTTP = v;                                                                                                          // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var cheerio = void 0;                                                                                                  // 1
module.import('cheerio', {                                                                                             // 1
  "default": function (v) {                                                                                            // 1
    cheerio = v;                                                                                                       // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var request = void 0;                                                                                                  // 1
module.import('request', {                                                                                             // 1
  "default": function (v) {                                                                                            // 1
    request = v;                                                                                                       // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var stream = void 0;                                                                                                   // 1
module.import('stream', {                                                                                              // 1
  "default": function (v) {                                                                                            // 1
    stream = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
var Items = void 0;                                                                                                    // 1
module.import('../../imports/api/items/items', {                                                                       // 1
  "default": function (v) {                                                                                            // 1
    Items = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
var Sku = void 0;                                                                                                      // 1
module.import('../../imports/api/items/sku', {                                                                         // 1
  "default": function (v) {                                                                                            // 1
    Sku = v;                                                                                                           // 1
  }                                                                                                                    // 1
}, 6);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.import('underscore', {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 7);                                                                                                                 // 1
var s = void 0;                                                                                                        // 1
module.import('underscore.string', {                                                                                   // 1
  "default": function (v) {                                                                                            // 1
    s = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 8);                                                                                                                 // 1
/* global S3 */Meteor.methods({                                                                                        // 10
  /**                                                                                                                  // 13
   * Login form:                                                                                                       //
   * Need data[User][username] and data[User][password] _method:POST                                                   //
   */loginMkr: function () {                                                                                           //
    this.unblock();                                                                                                    // 18
                                                                                                                       //
    try {                                                                                                              // 19
      // Now we login with the cookie                                                                                  // 20
      var options = {                                                                                                  // 21
        params: {                                                                                                      // 22
          '_method': 'POST',                                                                                           // 23
          'data[User][username]': '76647772-0',                                                                        // 24
          'data[User][password]': 'hal9000'                                                                            // 25
        },                                                                                                             // 22
        followRedirects: false                                                                                         // 27
      };                                                                                                               // 21
      var login = HTTP.call('POST', 'https://www.mkr.cl/users/login', options);                                        // 29
      var cookie = login.headers['set-cookie'][0];                                                                     // 30
      cookie = cookie.substr(0, 35);                                                                                   // 31
      return cookie;                                                                                                   // 33
    } catch (e) {                                                                                                      // 34
      console.log(e);                                                                                                  // 35
    }                                                                                                                  // 36
  },                                                                                                                   // 37
  // Starts process from itemsAdd                                                                                      // 38
  mkrInit: function (itemId) {                                                                                         // 39
    this.unblock(); // Init capture procedure --> ads meteor.defer for speed in the call                               // 40
                                                                                                                       //
    Meteor.defer(function () {                                                                                         // 42
      // Get data for item and it's skus                                                                               // 43
      Meteor.call('fillDataFromUrl', itemId, function (error, response) {                                              // 44
        if (error) {                                                                                                   // 45
          return console.log(error);                                                                                   // 46
        } // When data is present, get the images                                                                      // 47
                                                                                                                       //
                                                                                                                       //
        Meteor.call('uploadMultipleImages', itemId, function (error, response) {                                       // 50
          if (error) {                                                                                                 // 51
            return Meteor.Error('Error uploading multiple images');                                                    // 52
          }                                                                                                            // 53
        });                                                                                                            // 54
        return true;                                                                                                   // 55
      });                                                                                                              // 56
    });                                                                                                                // 57
  },                                                                                                                   // 58
  /**                                                                                                                  // 59
   * Fill the data for the item and it's sku                                                                           //
   * @param  {string} itemId The item's id                                                                             //
   */fillDataFromUrl: function (itemId) {                                                                              //
    this.unblock(); // Get the document from id                                                                        // 64
                                                                                                                       //
    var dbItem = Items.findOne(itemId);                                                                                // 66
                                                                                                                       //
    if (!dbItem) {                                                                                                     // 67
      throw new Meteor.Error('mkr-fillDataFromUrl-dbItem-not-found', 'Documento no encontrado');                       // 68
    } // Login to server                                                                                               // 69
                                                                                                                       //
                                                                                                                       //
    var cookie = Meteor.call('loginMkr'); // Title will come from first item                                           // 71
                                                                                                                       //
    var firstItem = true;                                                                                              // 74
    var broken = []; // means the sku code was not found on mkr                                                        // 76
    // Get data from each sku and fill it                                                                              // 78
                                                                                                                       //
    var skuList = dbItem.sku && dbItem.sku.length > 0 ? dbItem.sku : Sku.find({                                        // 79
      itemId: dbItem._id                                                                                               // 79
    }).fetch();                                                                                                        // 79
                                                                                                                       //
    _.each(skuList, function (sku) {                                                                                   // 80
      var itemCode = sku.url.replace('https://www.mkr.cl/store/productDetail/', '');                                   // 81
      var item = Meteor.call('getDetails', itemCode, cookie);                                                          // 82
                                                                                                                       //
      if (!item) {                                                                                                     // 83
        broken.push(sku.code); // throw new Meteor.Error('loginMkr-fillDataFromUrl-no-item', 'Item no encontrado')     // 84
      }                                                                                                                // 86
                                                                                                                       //
      if (firstItem === true) {                                                                                        // 87
        firstItem = item;                                                                                              // 88
      } // Update the Sku                                                                                              // 89
                                                                                                                       //
                                                                                                                       //
      var set = {                                                                                                      // 91
        name: item.name,                                                                                               // 92
        url: sku.url,                                                                                                  // 93
        itemId: dbItem._id,                                                                                            // 94
        code: item.code,                                                                                               // 95
        stock: parseInt(item.stock),                                                                                   // 96
        price: Number(item.price),                                                                                     // 97
        shopPrice: Number(item.shopPrice),                                                                             // 98
        extremePrice: Number(item.extremePrice)                                                                        // 99
      };                                                                                                               // 91
      set = _.extend(sku, set);                                                                                        // 101
                                                                                                                       //
      try {                                                                                                            // 102
        Sku.update({                                                                                                   // 103
          code: item.code                                                                                              // 103
        }, {                                                                                                           // 103
          $set: set                                                                                                    // 104
        }, {                                                                                                           // 103
          upsert: true                                                                                                 // 105
        });                                                                                                            // 105
      } catch (error) {                                                                                                // 106
        console.log('Error:', error);                                                                                  // 107
      }                                                                                                                // 108
    });                                                                                                                // 109
                                                                                                                       //
    if (broken.length > 0) {                                                                                           // 111
      console.log('no items found in the following sku codes', broken);                                                // 112
      Sku.update({                                                                                                     // 113
        code: {                                                                                                        // 113
          $in: broken                                                                                                  // 113
        }                                                                                                              // 113
      }, {                                                                                                             // 113
        $set: {                                                                                                        // 113
          stock: 0                                                                                                     // 113
        }                                                                                                              // 113
      }, {                                                                                                             // 113
        multi: true                                                                                                    // 113
      });                                                                                                              // 113
    } // Set the name from the first item                                                                              // 114
                                                                                                                       //
                                                                                                                       //
    Items.update(itemId, {                                                                                             // 117
      $set: {                                                                                                          // 118
        name: firstItem.name,                                                                                          // 119
        slug: s.slugify(firstItem.name),                                                                               // 120
        description: firstItem.description                                                                             // 121
      },                                                                                                               // 118
      $unset: {                                                                                                        // 123
        sku: 1                                                                                                         // 124
      }                                                                                                                // 123
    }, function (error, response) {                                                                                    // 117
      if (error) {                                                                                                     // 127
        throw new Meteor.Error(error);                                                                                 // 128
      }                                                                                                                // 129
                                                                                                                       //
      return true;                                                                                                     // 130
    });                                                                                                                // 131
  },                                                                                                                   // 132
  updateStock: function (itemId, cookie) {                                                                             // 133
    this.unblock();                                                                                                    // 134
                                                                                                                       //
    if (!cookie) {                                                                                                     // 135
      cookie = Meteor.call('loginMkr');                                                                                // 136
    }                                                                                                                  // 137
                                                                                                                       //
    var options = {                                                                                                    // 139
      followRedirects: false,                                                                                          // 140
      headers: {                                                                                                       // 141
        'cookie': cookie                                                                                               // 142
      }                                                                                                                // 141
    };                                                                                                                 // 139
    var skuList = Sku.find({                                                                                           // 145
      itemId: itemId                                                                                                   // 145
    }).fetch();                                                                                                        // 145
                                                                                                                       //
    if (skuList) {                                                                                                     // 146
      _.each(skuList, function (sku) {                                                                                 // 147
        var request = HTTP.call('GET', sku.url, options);                                                              // 148
        var $ = cheerio.load(request.content);                                                                         // 149
        var stock = parseInt($('#product-detail-text-container > ul > li:nth-child(8) > span:nth-child(2)').html());   // 150
        Sku.update(sku._id, {                                                                                          // 151
          $set: {                                                                                                      // 151
            stock: stock                                                                                               // 151
          }                                                                                                            // 151
        });                                                                                                            // 151
      });                                                                                                              // 152
    }                                                                                                                  // 153
                                                                                                                       //
    return 'successfully updated stocks';                                                                              // 154
  },                                                                                                                   // 155
  /**                                                                                                                  // 156
   * Get Details from SKU                                                                                              //
   * @param  {string} itemCode Code from MKR's URL                                                                     //
   * @param  {object} cookie   A cookie to login mkr, if none exist, then a new one is created                         //
   * @return {object}          Returns the item details                                                                //
   */getDetails: function (itemCode, cookie) {                                                                         //
    this.unblock();                                                                                                    // 163
                                                                                                                       //
    if (!cookie) {                                                                                                     // 164
      cookie = Meteor.call('loginMkr');                                                                                // 165
    }                                                                                                                  // 166
                                                                                                                       //
    var options = {                                                                                                    // 168
      followRedirects: true,                                                                                           // 169
      headers: {                                                                                                       // 170
        'cookie': cookie                                                                                               // 171
      }                                                                                                                // 170
    };                                                                                                                 // 168
                                                                                                                       //
    try {                                                                                                              // 174
      var request = HTTP.get('https://www.mkr.cl/store/productDetail/' + itemCode, options);                           // 175
      var $ = cheerio.load(request.content);                                                                           // 176
                                                                                                                       //
      if ($('#flashMessage').html()) {                                                                                 // 177
        return false;                                                                                                  // 178
      }                                                                                                                // 179
                                                                                                                       //
      var data = {                                                                                                     // 180
        name: s.unescapeHTML($('#product-detail-text-container > h2').html().trim()),                                  // 181
        brand: $('#product-detail-text-container > ul > li:nth-child(6)').html().trim().replace('<span class="item-detail-product">Marca: </span>', ''),
        stock: $('#product-detail-text-container > ul > li:nth-child(8) > span:nth-child(2)').html(),                  // 183
        code: $('#product-detail-text-container > ul > li:nth-child(1)').html().trim().replace('<span class="item-detail-product">C&#xF3;digo de Producto: </span>', ''),
        price: parseInt($('.price_product').html().trim().replace('<!-- MKR -->', '').trim().replace('$', '').replace('.', '')),
        description: $('#product-detail-container > p').html().trim()                                                  // 186
      }; // Extreme Zone part                                                                                          // 180
                                                                                                                       //
      var extremeZoneData = Meteor.call('RoundedExtremePrice', data.code, data.price);                                 // 190
                                                                                                                       //
      if (extremeZoneData) {                                                                                           // 191
        data.shopPrice = extremeZoneData.shopPrice;                                                                    // 192
        data.extremePrice = extremeZoneData.extremePrice;                                                              // 193
      }                                                                                                                // 194
                                                                                                                       //
      return data;                                                                                                     // 195
    } catch (e) {                                                                                                      // 196
      console.log('FAIL!', e, itemCode);                                                                               // 197
    }                                                                                                                  // 198
  },                                                                                                                   // 199
  /**                                                                                                                  // 200
   * Populate data for a single SKU                                                                                    //
   * @param  {string} skuId The Sku's Id                                                                               //
   * @return {boolean}      Returns true if was updated and false if wasn't                                            //
   */populateSKU: function (skuId) {                                                                                   //
    var sku;                                                                                                           // 206
                                                                                                                       //
    if (skuId && _.isString(skuId)) {                                                                                  // 207
      sku = Sku.findOne(skuId);                                                                                        // 208
    } else {                                                                                                           // 209
      sku = skuId;                                                                                                     // 210
    }                                                                                                                  // 211
                                                                                                                       //
    var itemCode = sku.url.replace('https://www.mkr.cl/store/productDetail/', '');                                     // 212
    var item = Meteor.call('getDetails', itemCode);                                                                    // 213
                                                                                                                       //
    if (!item) {                                                                                                       // 214
      console.log(item);                                                                                               // 215
      throw new Meteor.Error('loginMkr-fillDataFromUrl-no-item', 'Item no encontrado');                                // 216
    } // Update the Sku                                                                                                // 217
                                                                                                                       //
                                                                                                                       //
    var id = sku._id || null;                                                                                          // 219
    var update = Sku.update(id, {                                                                                      // 220
      $set: {                                                                                                          // 221
        url: sku.url,                                                                                                  // 222
        itemId: sku.itemId,                                                                                            // 223
        code: item.code,                                                                                               // 224
        stock: parseInt(item.stock),                                                                                   // 225
        price: item.price,                                                                                             // 226
        shopPrice: item.shopPrice,                                                                                     // 227
        extremePrice: item.extremePrice                                                                                // 228
      }                                                                                                                // 221
    }, {                                                                                                               // 220
      upsert: true                                                                                                     // 230
    });                                                                                                                // 230
    return id || update;                                                                                               // 231
  },                                                                                                                   // 232
  getImageLink: function (itemCode) {                                                                                  // 233
    this.unblock();                                                                                                    // 234
    return 'https://www.mkr.cl/img/products/' + itemCode + '.jpg';                                                     // 235
  },                                                                                                                   // 236
  uploadMultipleImages: function (itemId) {                                                                            // 237
    this.unblock(); // Get the codes                                                                                   // 238
                                                                                                                       //
    var skuList = Sku.find({                                                                                           // 240
      itemId: itemId                                                                                                   // 240
    }).fetch();                                                                                                        // 240
                                                                                                                       //
    _.each(skuList, function (sku, index) {                                                                            // 242
      var images = [];                                                                                                 // 243
      uploadImage(sku.code, Meteor.bindEnvironment(function (error, response) {                                        // 244
        if (error) {                                                                                                   // 245
          console.log(error);                                                                                          // 246
        } else {                                                                                                       // 247
          images.push(response);                                                                                       // 248
          Sku.update(sku._id, {                                                                                        // 249
            $set: {                                                                                                    // 249
              images: images                                                                                           // 249
            }                                                                                                          // 249
          });                                                                                                          // 249
        }                                                                                                              // 250
      }));                                                                                                             // 251
    });                                                                                                                // 252
                                                                                                                       //
    return 'successfully updated images';                                                                              // 253
  },                                                                                                                   // 254
  RoundedExtremePrice: function (skuCode, mkrPrice) {                                                                  // 255
    this.unblock();                                                                                                    // 256
    var request = HTTP.get('https://www.extremezone.cl/store/product/My-Personal-Bot-' + skuCode);                     // 257
    console.log(skuCode);                                                                                              // 258
    var $ = cheerio.load(request.content);                                                                             // 259
                                                                                                                       //
    try {                                                                                                              // 260
      var extremePriceSelector = $('div.prices > div.price-current').html();                                           // 261
                                                                                                                       //
      if (!extremePriceSelector) {                                                                                     // 262
        console.log('Producto no vendido en extremezone', skuCode);                                                    // 263
        Meteor.call('DisableSku', skuCode);                                                                            // 264
        return false;                                                                                                  // 265
      }                                                                                                                // 266
                                                                                                                       //
      var extremePrice = extremePriceSelector.trim() || false;                                                         // 267
    } catch (e) {                                                                                                      // 268
      console.log('error', e, 'skuCode', skuCode);                                                                     // 269
    }                                                                                                                  // 270
                                                                                                                       //
    extremePrice = extremePrice.replace(/\$/g, '').replace(/\./g, '');                                                 // 271
    extremePrice = parseInt(extremePrice);                                                                             // 272
    var mkrPriceCI = mkrPrice * 1.19;                                                                                  // 274
                                                                                                                       //
    var pampaPrice = _.clone(extremePrice);                                                                            // 276
                                                                                                                       //
    if (pampaPrice > 10000) {                                                                                          // 277
      pampaPrice = Math.trunc(pampaPrice / 1000) * 1000 - 10;                                                          // 278
    }                                                                                                                  // 279
                                                                                                                       //
    if (pampaPrice > 1000) {                                                                                           // 279
      pampaPrice = Math.trunc(pampaPrice / 100) * 100 - 10;                                                            // 280
    } else {                                                                                                           // 281
      pampaPrice = Math.trunc(pampaPrice / 10) * 10;                                                                   // 282
    }                                                                                                                  // 283
                                                                                                                       //
    var diferencia = extremePrice - mkrPriceCI;                                                                        // 285
    var gananciaNetaExtreme = diferencia / 1.19;                                                                       // 286
    var gananciaNetaPampa = (pampaPrice - mkrPriceCI) / 1.19;                                                          // 287
    var porcentaje = 100 - gananciaNetaPampa / gananciaNetaExtreme * 100; // console.log(extremePrice, pampaPrice, porcentaje)
                                                                                                                       //
    if (porcentaje > 5) {                                                                                              // 293
      pampaPrice = extremePrice;                                                                                       // 294
    }                                                                                                                  // 295
                                                                                                                       //
    var retorno = {                                                                                                    // 297
      extremePrice: extremePrice,                                                                                      // 297
      shopPrice: pampaPrice                                                                                            // 297
    };                                                                                                                 // 297
    return retorno;                                                                                                    // 298
  },                                                                                                                   // 299
  DisableSku: function (skuCode) {                                                                                     // 300
    this.unblock();                                                                                                    // 301
    Sku.update({                                                                                                       // 302
      code: skuCode                                                                                                    // 302
    }, {                                                                                                               // 302
      $set: {                                                                                                          // 302
        stock: 0                                                                                                       // 302
      }                                                                                                                // 302
    });                                                                                                                // 302
  }                                                                                                                    // 303
});                                                                                                                    // 12
                                                                                                                       //
function uploadImage(itemCode, callback) {                                                                             // 306
  var PassThrough = stream.PassThrough;                                                                                // 307
  var passthrough = new PassThrough(); // get the image link                                                           // 308
                                                                                                                       //
  var image = Meteor.call('getImageLink', itemCode);                                                                   // 310
  var fileName = itemCode;                                                                                             // 311
  var requestImage = request(image);                                                                                   // 312
  requestImage.on('response', function (response) {                                                                    // 313
    if (response.statusCode !== 200) {                                                                                 // 314
      return callback(null, {                                                                                          // 315
        url: 'https://pampa.store/no_image.png',                                                                       // 316
        meta: {                                                                                                        // 317
          s3Path: '/orionjs/' + fileName + '.jpg'                                                                      // 318
        }                                                                                                              // 317
      });                                                                                                              // 315
    } else {                                                                                                           // 321
      requestImage.pipe(passthrough);                                                                                  // 322
      S3.aws.upload({                                                                                                  // 324
        Bucket: S3.config.bucket,                                                                                      // 325
        Key: 'orionjs/' + fileName + '.jpg',                                                                           // 326
        Body: passthrough,                                                                                             // 327
        ACL: 'public-read',                                                                                            // 328
        ContentType: 'image/jpeg',                                                                                     // 329
        Expires: new Date('01-01-2099')                                                                                // 330
      }).send(function (error, data) {                                                                                 // 324
        if (error) {                                                                                                   // 332
          console.log('ERROR - S3', error);                                                                            // 333
        }                                                                                                              // 334
      });                                                                                                              // 335
      var obj = {                                                                                                      // 337
        url: 'https://s3.amazonaws.com/armatubicicleta/orionjs/' + fileName + '.jpg',                                  // 338
        meta: {                                                                                                        // 339
          s3Path: '/orionjs/' + fileName + '.jpg'                                                                      // 340
        }                                                                                                              // 339
      };                                                                                                               // 337
      return callback(null, obj);                                                                                      // 344
    }                                                                                                                  // 345
  });                                                                                                                  // 346
}                                                                                                                      // 347
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"mkr.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/mkr/mkr.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// import {Meteor} from 'meteor/meteor'                                                                                // 1
// import {HTTP} from 'meteor/http'                                                                                    // 2
// import cheerio from 'cheerio'                                                                                       // 3
// import request from 'request'                                                                                       // 4
// import stream from 'stream'                                                                                         // 5
// import Items from '../../imports/api/items/items'                                                                   // 6
// import Sku from '../../imports/api/items/sku'                                                                       // 7
// import _ from 'underscore'                                                                                          // 8
// import s from 'underscore.string'                                                                                   // 9
// /* global S3 */                                                                                                     // 10
//                                                                                                                     // 11
// export function loginMkr () {                                                                                       // 12
//   const options = {                                                                                                 // 13
//     params: {                                                                                                       // 14
//       '_method': 'POST',                                                                                            // 15
//       'data[User][username]': '76647772-0',                                                                         // 16
//       'data[User][password]': 'hal9000'                                                                             // 17
//     },                                                                                                              // 18
//     followRedirects: false                                                                                          // 19
//   }                                                                                                                 // 20
//                                                                                                                     // 21
//   try {                                                                                                             // 22
//     var login = HTTP.call('POST', 'https://www.mkr.cl/users/login', options)                                        // 23
//     var cookie = login.headers['set-cookie'][0]                                                                     // 24
//     cookie = cookie.substr(0, 35)                                                                                   // 25
//                                                                                                                     // 26
//     return cookie                                                                                                   // 27
//   } catch (e) {                                                                                                     // 28
//     console.log(e)                                                                                                  // 29
//   }                                                                                                                 // 30
// }                                                                                                                   // 31
//                                                                                                                     // 32
// Meteor.methods({                                                                                                    // 33
//   /**                                                                                                               // 34
//    * Login form:                                                                                                    // 35
//    * Need data[User][username] and data[User][password] _method:POST                                                // 36
//    */                                                                                                               // 37
//   loginMkr: function () {                                                                                           // 38
//     this.unblock()                                                                                                  // 39
//     try {                                                                                                           // 40
//       // Now we login with the cookie                                                                               // 41
//       var options = {                                                                                               // 42
//         params: {                                                                                                   // 43
//           '_method': 'POST',                                                                                        // 44
//           'data[User][username]': '76647772-0',                                                                     // 45
//           'data[User][password]': 'hal9000'                                                                         // 46
//         },                                                                                                          // 47
//         followRedirects: false                                                                                      // 48
//       }                                                                                                             // 49
//       var login = HTTP.call('POST', 'https://www.mkr.cl/users/login', options)                                      // 50
//       var cookie = login.headers['set-cookie'][0]                                                                   // 51
//       cookie = cookie.substr(0, 35)                                                                                 // 52
//                                                                                                                     // 53
//       return cookie                                                                                                 // 54
//     } catch (e) {                                                                                                   // 55
//       console.log(e)                                                                                                // 56
//     }                                                                                                               // 57
//   },                                                                                                                // 58
//   // Starts process from itemsAdd                                                                                   // 59
//   mkrInit: function (itemId) {                                                                                      // 60
//     this.unblock()                                                                                                  // 61
//     // Init capture procedure --> ads meteor.defer for speed in the call                                            // 62
//     Meteor.defer(function () {                                                                                      // 63
//       // Get data for item and it's skus                                                                            // 64
//       Meteor.call('fillDataFromUrl', itemId, (error, response) => {                                                 // 65
//         if (error) {                                                                                                // 66
//           return console.log(error)                                                                                 // 67
//         }                                                                                                           // 68
//                                                                                                                     // 69
//         // When data is present, get the images                                                                     // 70
//         Meteor.call('uploadMultipleImages', itemId, function (error, response) {                                    // 71
//           if (error) {                                                                                              // 72
//             return Meteor.Error('Error uploading multiple images')                                                  // 73
//           }                                                                                                         // 74
//         })                                                                                                          // 75
//         return true                                                                                                 // 76
//       })                                                                                                            // 77
//     })                                                                                                              // 78
//   },                                                                                                                // 79
//   /**                                                                                                               // 80
//    * Fill the data for the item and it's sku                                                                        // 81
//    * @param  {string} itemId The item's id                                                                          // 82
//    */                                                                                                               // 83
//   fillDataFromUrl: function (itemId) {                                                                              // 84
//     this.unblock()                                                                                                  // 85
//     // Get the document from id                                                                                     // 86
//     var dbItem = Items.findOne(itemId)                                                                              // 87
//     if (!dbItem) {                                                                                                  // 88
//       throw new Meteor.Error('mkr-fillDataFromUrl-dbItem-not-found', 'Documento no encontrado')                     // 89
//     }                                                                                                               // 90
//     // Login to server                                                                                              // 91
//     var cookie = Meteor.call('loginMkr')                                                                            // 92
//                                                                                                                     // 93
//     // Title will come from first item                                                                              // 94
//     var firstItem = true                                                                                            // 95
//                                                                                                                     // 96
//     var broken = [] // means the sku code was not found on mkr                                                      // 97
//                                                                                                                     // 98
//     // Get data from each sku and fill it                                                                           // 99
//     var skuList = (dbItem.sku && dbItem.sku.length > 0) ? dbItem.sku : Sku.find({itemId: dbItem._id}).fetch()       // 100
//     _.each(skuList, function (sku) {                                                                                // 101
//       var itemCode = sku.url.replace('https://www.mkr.cl/store/productDetail/', '')                                 // 102
//       var item = Meteor.call('getDetails', itemCode, cookie)                                                        // 103
//       if (!item) {                                                                                                  // 104
//         broken.push(sku.code)                                                                                       // 105
//         // throw new Meteor.Error('loginMkr-fillDataFromUrl-no-item', 'Item no encontrado')                         // 106
//       }                                                                                                             // 107
//       if (firstItem === true) {                                                                                     // 108
//         firstItem = item                                                                                            // 109
//       }                                                                                                             // 110
//       // Update the Sku                                                                                             // 111
//       var set = {                                                                                                   // 112
//         name: item.name,                                                                                            // 113
//         url: sku.url,                                                                                               // 114
//         itemId: dbItem._id,                                                                                         // 115
//         code: item.code,                                                                                            // 116
//         stock: parseInt(item.stock),                                                                                // 117
//         price: Number(item.price),                                                                                  // 118
//         shopPrice: Number(item.shopPrice),                                                                          // 119
//         extremePrice: Number(item.extremePrice)                                                                     // 120
//       }                                                                                                             // 121
//       set = _.extend(sku, set)                                                                                      // 122
//       try {                                                                                                         // 123
//         Sku.update({code: item.code}, {                                                                             // 124
//           $set: set                                                                                                 // 125
//         }, {upsert: true})                                                                                          // 126
//       } catch (error) {                                                                                             // 127
//         console.log('Error:', error)                                                                                // 128
//       }                                                                                                             // 129
//     })                                                                                                              // 130
//                                                                                                                     // 131
//     if (broken.length > 0) {                                                                                        // 132
//       console.log('no items found in the following sku codes', broken)                                              // 133
//       Sku.update({code: {$in: broken}}, {$set: {stock: 0}}, {multi: true})                                          // 134
//     }                                                                                                               // 135
//                                                                                                                     // 136
//     // Set the name from the first item                                                                             // 137
//     Items.update(itemId, {                                                                                          // 138
//       $set: {                                                                                                       // 139
//         name: firstItem.name,                                                                                       // 140
//         slug: s.slugify(firstItem.name),                                                                            // 141
//         description: firstItem.description                                                                          // 142
//       },                                                                                                            // 143
//       $unset: {                                                                                                     // 144
//         sku: 1                                                                                                      // 145
//       }                                                                                                             // 146
//     }, (error, response) => {                                                                                       // 147
//       if (error) {                                                                                                  // 148
//         throw new Meteor.Error(error)                                                                               // 149
//       }                                                                                                             // 150
//       return true                                                                                                   // 151
//     })                                                                                                              // 152
//   },                                                                                                                // 153
//   updateStock: function (itemId, cookie) {                                                                          // 154
//     this.unblock()                                                                                                  // 155
//     if (!cookie) {                                                                                                  // 156
//       cookie = Meteor.call('loginMkr')                                                                              // 157
//     }                                                                                                               // 158
//                                                                                                                     // 159
//     var options = {                                                                                                 // 160
//       followRedirects: false,                                                                                       // 161
//       headers: {                                                                                                    // 162
//         'cookie': cookie                                                                                            // 163
//       }                                                                                                             // 164
//     }                                                                                                               // 165
//     var skuList = Sku.find({itemId: itemId}).fetch()                                                                // 166
//     if (skuList) {                                                                                                  // 167
//       _.each(skuList, function (sku) {                                                                              // 168
//         var request = HTTP.call('GET', sku.url, options)                                                            // 169
//         var $ = cheerio.load(request.content)                                                                       // 170
//         var stock = parseInt($('#product-detail-text-container > ul > li:nth-child(8) > span:nth-child(2)').html())
//         Sku.update(sku._id, {$set: {stock: stock}})                                                                 // 172
//       })                                                                                                            // 173
//     }                                                                                                               // 174
//     return 'successfully updated stocks'                                                                            // 175
//   },                                                                                                                // 176
//   /**                                                                                                               // 177
//    * Get Details from SKU                                                                                           // 178
//    * @param  {string} itemCode Code from MKR's URL                                                                  // 179
//    * @param  {object} cookie   A cookie to login mkr, if none exist, then a new one is created                      // 180
//    * @return {object}          Returns the item details                                                             // 181
//    */                                                                                                               // 182
//   getDetails: function (itemCode, cookie) {                                                                         // 183
//     this.unblock()                                                                                                  // 184
//     if (!cookie) {                                                                                                  // 185
//       cookie = Meteor.call('loginMkr')                                                                              // 186
//     }                                                                                                               // 187
//                                                                                                                     // 188
//     var options = {                                                                                                 // 189
//       followRedirects: true,                                                                                        // 190
//       headers: {                                                                                                    // 191
//         'cookie': cookie                                                                                            // 192
//       }                                                                                                             // 193
//     }                                                                                                               // 194
//     try {                                                                                                           // 195
//       var request = HTTP.get('https://www.mkr.cl/store/productDetail/' + itemCode, options)                         // 196
//       var $ = cheerio.load(request.content)                                                                         // 197
//       if ($('#flashMessage').html()) {                                                                              // 198
//         return false                                                                                                // 199
//       }                                                                                                             // 200
//       var data = {                                                                                                  // 201
//         name: s.unescapeHTML($('#product-detail-text-container > h2').html().trim()),                               // 202
//         brand: $('#product-detail-text-container > ul > li:nth-child(6)').html().trim().replace('<span class="item-detail-product">Marca: </span>', ''),
//         stock: $('#product-detail-text-container > ul > li:nth-child(8) > span:nth-child(2)').html(),               // 204
//         code: $('#product-detail-text-container > ul > li:nth-child(1)').html().trim().replace('<span class="item-detail-product">C&#xF3;digo de Producto: </span>', ''),
//         price: parseInt($('.price_product').html().trim().replace('<!-- MKR -->', '').trim().replace('$', '').replace('.', '')),
//         description: $('#product-detail-container > p').html().trim()                                               // 207
//       }                                                                                                             // 208
//                                                                                                                     // 209
//       // Extreme Zone part                                                                                          // 210
//       var extremeZoneData = Meteor.call('RoundedExtremePrice', data.code, data.price)                               // 211
//       if (extremeZoneData) {                                                                                        // 212
//         data.shopPrice = extremeZoneData.shopPrice                                                                  // 213
//         data.extremePrice = extremeZoneData.extremePrice                                                            // 214
//       }                                                                                                             // 215
//       return data                                                                                                   // 216
//     } catch (e) {                                                                                                   // 217
//       console.log('FAIL!', e, itemCode)                                                                             // 218
//     }                                                                                                               // 219
//   },                                                                                                                // 220
//   /**                                                                                                               // 221
//    * Populate data for a single SKU                                                                                 // 222
//    * @param  {string} skuId The Sku's Id                                                                            // 223
//    * @return {boolean}      Returns true if was updated and false if wasn't                                         // 224
//    */                                                                                                               // 225
//   populateSKU: function (skuId) {                                                                                   // 226
//     var sku                                                                                                         // 227
//     if (skuId && _.isString(skuId)) {                                                                               // 228
//       sku = Sku.findOne(skuId)                                                                                      // 229
//     } else {                                                                                                        // 230
//       sku = skuId                                                                                                   // 231
//     }                                                                                                               // 232
//     var itemCode = sku.url.replace('https://www.mkr.cl/store/productDetail/', '')                                   // 233
//     var item = Meteor.call('getDetails', itemCode)                                                                  // 234
//     if (!item) {                                                                                                    // 235
//       console.log(item)                                                                                             // 236
//       throw new Meteor.Error('loginMkr-fillDataFromUrl-no-item', 'Item no encontrado')                              // 237
//     }                                                                                                               // 238
//     // Update the Sku                                                                                               // 239
//     var id = sku._id || null                                                                                        // 240
//     var update = Sku.update(id, {                                                                                   // 241
//       $set: {                                                                                                       // 242
//         url: sku.url,                                                                                               // 243
//         itemId: sku.itemId,                                                                                         // 244
//         code: item.code,                                                                                            // 245
//         stock: parseInt(item.stock),                                                                                // 246
//         price: item.price,                                                                                          // 247
//         shopPrice: item.shopPrice,                                                                                  // 248
//         extremePrice: item.extremePrice                                                                             // 249
//       }                                                                                                             // 250
//     }, {upsert: true})                                                                                              // 251
//     return id || update                                                                                             // 252
//   },                                                                                                                // 253
//   getImageLink: function (itemCode) {                                                                               // 254
//     this.unblock()                                                                                                  // 255
//     return 'https://www.mkr.cl/img/products/' + itemCode + '.jpg'                                                   // 256
//   },                                                                                                                // 257
//   uploadMultipleImages: function (itemId) {                                                                         // 258
//     this.unblock()                                                                                                  // 259
//     // Get the codes                                                                                                // 260
//     var skuList = Sku.find({itemId: itemId}).fetch()                                                                // 261
//                                                                                                                     // 262
//     _.each(skuList, function (sku, index) {                                                                         // 263
//       var images = []                                                                                               // 264
//       uploadImage(sku.code, Meteor.bindEnvironment(function (error, response) {                                     // 265
//         if (error) {                                                                                                // 266
//           console.log(error)                                                                                        // 267
//         } else {                                                                                                    // 268
//           images.push(response)                                                                                     // 269
//           Sku.update(sku._id, {$set: {images: images}})                                                             // 270
//         }                                                                                                           // 271
//       }))                                                                                                           // 272
//     })                                                                                                              // 273
//     return 'successfully updated images'                                                                            // 274
//   },                                                                                                                // 275
//   RoundedExtremePrice: function (skuCode, mkrPrice) {                                                               // 276
//     this.unblock()                                                                                                  // 277
//     var request = HTTP.get('https://www.extremezone.cl/store/product/My-Personal-Bot-' + skuCode)                   // 278
//     console.log(skuCode)                                                                                            // 279
//     var $ = cheerio.load(request.content)                                                                           // 280
//     try {                                                                                                           // 281
//       var extremePriceSelector = $('div.prices > div.price-current').html()                                         // 282
//       if (!extremePriceSelector) {                                                                                  // 283
//         console.log('Producto no vendido en extremezone', skuCode)                                                  // 284
//         Meteor.call('DisableSku', skuCode)                                                                          // 285
//         return false                                                                                                // 286
//       }                                                                                                             // 287
//       var extremePrice = extremePriceSelector.trim() || false                                                       // 288
//     } catch (e) {                                                                                                   // 289
//       console.log('error', e, 'skuCode', skuCode)                                                                   // 290
//     }                                                                                                               // 291
//     extremePrice = extremePrice.replace(/\$/g, '').replace(/\./g, '')                                               // 292
//     extremePrice = parseInt(extremePrice)                                                                           // 293
//                                                                                                                     // 294
//     var mkrPriceCI = mkrPrice * 1.19                                                                                // 295
//                                                                                                                     // 296
//     var pampaPrice = _.clone(extremePrice)                                                                          // 297
//     if (pampaPrice > 10000) {                                                                                       // 298
//       pampaPrice = Math.trunc(pampaPrice / 1000) * 1000 - 10                                                        // 299
//     } if (pampaPrice > 1000) {                                                                                      // 300
//       pampaPrice = Math.trunc(pampaPrice / 100) * 100 - 10                                                          // 301
//     } else {                                                                                                        // 302
//       pampaPrice = Math.trunc(pampaPrice / 10) * 10                                                                 // 303
//     }                                                                                                               // 304
//                                                                                                                     // 305
//     var diferencia = extremePrice - mkrPriceCI                                                                      // 306
//     var gananciaNetaExtreme = diferencia / 1.19                                                                     // 307
//     var gananciaNetaPampa = (pampaPrice - mkrPriceCI) / 1.19                                                        // 308
//                                                                                                                     // 309
//     var porcentaje = 100 - (gananciaNetaPampa / gananciaNetaExtreme * 100)                                          // 310
//                                                                                                                     // 311
//     // console.log(extremePrice, pampaPrice, porcentaje)                                                            // 312
//                                                                                                                     // 313
//     if (porcentaje > 5) {                                                                                           // 314
//       pampaPrice = extremePrice                                                                                     // 315
//     }                                                                                                               // 316
//                                                                                                                     // 317
//     var retorno = { extremePrice: extremePrice, shopPrice: pampaPrice }                                             // 318
//     return retorno                                                                                                  // 319
//   },                                                                                                                // 320
//   DisableSku: function (skuCode) {                                                                                  // 321
//     this.unblock()                                                                                                  // 322
//     Sku.update({code: skuCode}, {$set: {stock: 0}})                                                                 // 323
//   }                                                                                                                 // 324
// })                                                                                                                  // 325
//                                                                                                                     // 326
// export function uploadImage (itemCode, callback) {                                                                  // 327
//   var PassThrough = stream.PassThrough                                                                              // 328
//   var passthrough = new PassThrough()                                                                               // 329
//   // get the image link                                                                                             // 330
//   var image = Meteor.call('getImageLink', itemCode)                                                                 // 331
//   var fileName = itemCode                                                                                           // 332
//   var requestImage = request(image)                                                                                 // 333
//   requestImage.on('response', function (response) {                                                                 // 334
//     if (response.statusCode !== 200) {                                                                              // 335
//       return callback(null, {                                                                                       // 336
//         url: 'https://pampa.store/no_image.png',                                                                    // 337
//         meta: {                                                                                                     // 338
//           s3Path: '/orionjs/' + fileName + '.jpg'                                                                   // 339
//         }                                                                                                           // 340
//       })                                                                                                            // 341
//     } else {                                                                                                        // 342
//       requestImage.pipe(passthrough)                                                                                // 343
//                                                                                                                     // 344
//       S3.aws.upload({                                                                                               // 345
//         Bucket: S3.config.bucket,                                                                                   // 346
//         Key: 'orionjs/' + fileName + '.jpg',                                                                        // 347
//         Body: passthrough,                                                                                          // 348
//         ACL: 'public-read',                                                                                         // 349
//         ContentType: 'image/jpeg',                                                                                  // 350
//         Expires: new Date('01-01-2099')                                                                             // 351
//       }).send(function (error, data) {                                                                              // 352
//         if (error) {                                                                                                // 353
//           console.log('ERROR - S3', error)                                                                          // 354
//         }                                                                                                           // 355
//       })                                                                                                            // 356
//                                                                                                                     // 357
//       var obj = {                                                                                                   // 358
//         url: 'https://s3.amazonaws.com/armatubicicleta/orionjs/' + fileName + '.jpg',                               // 359
//         meta: {                                                                                                     // 360
//           s3Path: '/orionjs/' + fileName + '.jpg'                                                                   // 361
//         }                                                                                                           // 362
//       }                                                                                                             // 363
//                                                                                                                     // 364
//       return callback(null, obj)                                                                                    // 365
//     }                                                                                                               // 366
//   })                                                                                                                // 367
// }                                                                                                                   // 368
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"armadoPublications.js":["meteor/meteor","../imports/api/items/items","../entidades/orion/categories","underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/armadoPublications.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Items = void 0;                                                                                                    // 1
module.import('../imports/api/items/items', {                                                                          // 1
  "default": function (v) {                                                                                            // 1
    Items = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Categories = void 0;                                                                                               // 1
module.import('../entidades/orion/categories', {                                                                       // 1
  "default": function (v) {                                                                                            // 1
    Categories = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.import('underscore', {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
Meteor.publish('armadoItems', function (selectedItems) {                                                               // 6
  console.log('selectedItems', selectedItems);                                                                         // 7
  var armadoCategories = Categories.find({                                                                             // 8
    armado: true                                                                                                       // 8
  }).fetch();                                                                                                          // 8
                                                                                                                       //
  _.each(armadoCategories, function (category) {                                                                       // 9
    if (!selectedItems[category.code]) {                                                                               // 10
      selectedItems[category.code] = null;                                                                             // 11
    }                                                                                                                  // 12
  });                                                                                                                  // 13
                                                                                                                       //
  var query = armar(selectedItems);                                                                                    // 14
  console.log('final query', query);                                                                                   // 15
  return Items.find(query);                                                                                            // 16
});                                                                                                                    // 17
Meteor.publish('categoriesArmado', function () {                                                                       // 19
  return Categories.find({                                                                                             // 20
    armado: true                                                                                                       // 20
  });                                                                                                                  // 20
}); /**                                                                                                                // 21
      * Creates the complete query used to fetch items                                                                 //
      * @params selectedItems --> {'001': 'asdasdasasd', '002': '123123123'}                                           //
      */                                                                                                               //
                                                                                                                       //
function armar(selectedItems) {                                                                                        // 27
  // always add all frames cause it's the main category                                                                // 28
  /* var queryCategory = {code: '001'}                                                                                 // 29
  var category = Categories.findOne(queryCategory)                                                                     //
  var queries = [{category: category._id}] */var queries = [];                                                         //
                                                                                                                       //
  _.each(selectedItems, function (value, key) {                                                                        // 33
    var query = obtenerItems(key, selectedItems); // console.log('obtenerItems', query)                                // 34
                                                                                                                       //
    if (!_.isUndefined(query)) {                                                                                       // 36
      queries.push(query);                                                                                             // 37
    }                                                                                                                  // 38
  }); // console.log('queries', queries)                                                                               // 39
                                                                                                                       //
                                                                                                                       //
  if (_.isEqual(queries, [])) {                                                                                        // 41
    var queryCategory = {                                                                                              // 42
      code: '001'                                                                                                      // 42
    };                                                                                                                 // 42
    var category = Categories.findOne(queryCategory);                                                                  // 43
    queries.push({                                                                                                     // 44
      category: category._id                                                                                           // 44
    });                                                                                                                // 44
  }                                                                                                                    // 45
                                                                                                                       //
  queries = {                                                                                                          // 46
    $or: queries                                                                                                       // 46
  };                                                                                                                   // 46
  return queries;                                                                                                      // 47
} // Knows which connection a item has.                                                                                // 48
                                                                                                                       //
                                                                                                                       //
function obtenerItems(category, selectedItems) {                                                                       // 51
  // console.log('category', category)                                                                                 // 52
  switch (category) {                                                                                                  // 53
    case '001':                                                                                                        // 54
      var categoria = Categories.findOne({                                                                             // 55
        code: '001'                                                                                                    // 55
      });                                                                                                              // 55
      return {                                                                                                         // 56
        category: categoria._id                                                                                        // 56
      };                                                                                                               // 56
    /* var items = Items.find({ category: categoria._id }).fetch()                                                     // 57
    return items */ // return armado(category, [], selectedItems)                                                      //
                                                                                                                       //
    case '002':                                                                                                        // 60
      return armado(category, [{                                                                                       // 61
        connector: '001',                                                                                              // 61
        unions: ['frameShockSize']                                                                                     // 61
      }], selectedItems);                                                                                              // 61
                                                                                                                       //
    case '003':                                                                                                        // 62
      return armado(category, [{                                                                                       // 63
        connector: '001',                                                                                              // 63
        unions: ['headSetSize', 'headSetConical', ['travel'], 'rimDiameter']                                           // 63
      }], selectedItems);                                                                                              // 63
                                                                                                                       //
    case '004':                                                                                                        // 64
      return armado(category, [{                                                                                       // 65
        connector: '001',                                                                                              // 65
        unions: ['headSetSize', 'headSetConical', 'headSetType']                                                       // 65
      }, {                                                                                                             // 65
        connector: '003',                                                                                              // 65
        unions: ['headSetSize', 'headSetConical']                                                                      // 65
      }], selectedItems);                                                                                              // 65
                                                                                                                       //
    case '005':                                                                                                        // 66
      return armado(category, [{                                                                                       // 67
        connector: '003',                                                                                              // 67
        unions: [['frontBrakeType']]                                                                                   // 67
      }], selectedItems);                                                                                              // 67
                                                                                                                       //
    case '006':                                                                                                        // 68
      return armado(category, [{                                                                                       // 69
        connector: '001',                                                                                              // 69
        unions: [['rearBrakeType']]                                                                                    // 69
      }], selectedItems);                                                                                              // 69
                                                                                                                       //
    case '007':                                                                                                        // 70
      return armado(category, [{                                                                                       // 71
        connector: '003',                                                                                              // 71
        unions: ['axleSize', 'axleWidth']                                                                              // 71
      }, {                                                                                                             // 71
        connector: '005',                                                                                              // 71
        unions: [['frontBrakeType']]                                                                                   // 71
      }], selectedItems);                                                                                              // 71
                                                                                                                       //
    case '008':                                                                                                        // 72
      return armado(category, [{                                                                                       // 73
        connector: '003',                                                                                              // 73
        unions: [['frontRotorSize']]                                                                                   // 73
      }], selectedItems);                                                                                              // 73
                                                                                                                       //
    case '009':                                                                                                        // 74
      return armado(category, [{                                                                                       // 75
        connector: '003',                                                                                              // 75
        unions: ['rimDiameter']                                                                                        // 75
      }, {                                                                                                             // 75
        connector: '005',                                                                                              // 75
        unions: ['frontBrakeType']                                                                                     // 75
      }, {                                                                                                             // 75
        connector: '007',                                                                                              // 75
        unions: ['frontHoles']                                                                                         // 75
      }], selectedItems);                                                                                              // 75
                                                                                                                       //
    case '010':                                                                                                        // 76
      return armado(category, [{                                                                                       // 77
        connector: '003',                                                                                              // 77
        unions: ['rimDiameter', 'frontTyreWidth']                                                                      // 77
      }, {                                                                                                             // 77
        connector: '009',                                                                                              // 77
        unions: ['rimDiameter']                                                                                        // 77
      }], selectedItems);                                                                                              // 77
                                                                                                                       //
    case '011':                                                                                                        // 78
      return armado(category, [{                                                                                       // 79
        connector: '010',                                                                                              // 79
        unions: ['rimDiameter', 'frontTyreWidth']                                                                      // 79
      }], selectedItems);                                                                                              // 79
                                                                                                                       //
    case '012':                                                                                                        // 80
      return armado(category, [{                                                                                       // 81
        connector: '009',                                                                                              // 81
        unions: ['rimDiameter']                                                                                        // 81
      }], selectedItems);                                                                                              // 81
                                                                                                                       //
    case '013':                                                                                                        // 82
      return armado(category, [{                                                                                       // 83
        connector: '001',                                                                                              // 83
        unions: ['SeatClampSize']                                                                                      // 83
      }], selectedItems);                                                                                              // 83
                                                                                                                       //
    case '014':                                                                                                        // 84
      return armado(category, [{                                                                                       // 85
        connector: '001',                                                                                              // 85
        unions: ['seatTubeSize']                                                                                       // 85
      }], selectedItems);                                                                                              // 85
                                                                                                                       //
    case '015':                                                                                                        // 86
      return armado(category, [{                                                                                       // 87
        connector: '014',                                                                                              // 87
        unions: ['seatMount']                                                                                          // 87
      }], selectedItems);                                                                                              // 87
                                                                                                                       //
    case '016':                                                                                                        // 88
      return armado(category, [{                                                                                       // 89
        connector: '001',                                                                                              // 89
        unions: ['rearHubWidth', 'rearHubDiameter']                                                                    // 89
      }, {                                                                                                             // 89
        connector: '006',                                                                                              // 89
        unions: ['rearBrakeType']                                                                                      // 89
      }], selectedItems);                                                                                              // 89
                                                                                                                       //
    case '017':                                                                                                        // 90
      return armado(category, [{                                                                                       // 91
        connector: '001',                                                                                              // 91
        unions: [['rearRotorSize']]                                                                                    // 91
      }, {                                                                                                             // 91
        connector: '006',                                                                                              // 91
        unions: [['rearBrakeType']]                                                                                    // 91
      }, {                                                                                                             // 91
        connector: '016',                                                                                              // 91
        unions: [['rearBrakeType']]                                                                                    // 91
      }], selectedItems);                                                                                              // 91
                                                                                                                       //
    case '018':                                                                                                        // 92
      return armado(category, [{                                                                                       // 93
        connector: '001',                                                                                              // 93
        unions: ['rimDiameter']                                                                                        // 93
      }, {                                                                                                             // 93
        connector: '006',                                                                                              // 93
        unions: [['rearBrakeType']]                                                                                    // 93
      }, {                                                                                                             // 93
        connector: '016',                                                                                              // 93
        unions: [['rearBrakeType']]                                                                                    // 93
      }], selectedItems);                                                                                              // 93
                                                                                                                       //
    case '019':                                                                                                        // 94
      return armado(category, [{                                                                                       // 95
        connector: '001',                                                                                              // 95
        unions: [['rearTyreWidth']]                                                                                    // 95
      }, {                                                                                                             // 95
        connector: '018',                                                                                              // 95
        unions: ['rimDiameter']                                                                                        // 95
      }], selectedItems);                                                                                              // 95
                                                                                                                       //
    case '020':                                                                                                        // 96
      return armado(category, [{                                                                                       // 97
        connector: '019',                                                                                              // 97
        unions: ['rimDiameter', ['rearTyreWidth']]                                                                     // 97
      }], selectedItems);                                                                                              // 97
                                                                                                                       //
    case '021':                                                                                                        // 98
      return armado(category, [{                                                                                       // 99
        connector: '016',                                                                                              // 99
        unions: ['rearBlockType', ['rearSpeedsNumber']]                                                                // 99
      }], selectedItems);                                                                                              // 99
                                                                                                                       //
    case '022':                                                                                                        // 100
      return armado(category, [{                                                                                       // 101
        connector: '001',                                                                                              // 101
        unions: ['rearDerailleaurMount']                                                                               // 101
      }, {                                                                                                             // 101
        connector: '021',                                                                                              // 101
        unions: [['rearSpeedsNumber']]                                                                                 // 101
      }], selectedItems);                                                                                              // 101
                                                                                                                       //
    case '023':                                                                                                        // 102
      return armado(category, [{                                                                                       // 103
        connector: '021',                                                                                              // 103
        unions: [['rearSpeedsNumber']]                                                                                 // 103
      }], selectedItems);                                                                                              // 103
                                                                                                                       //
    case '024':                                                                                                        // 104
      return armado(category, [{                                                                                       // 105
        connector: '001',                                                                                              // 105
        unions: ['frontDerailleaurMount', ['frontDerailleaurWidth'], ['frontDerailleaurPull']]                         // 105
      }, {                                                                                                             // 105
        connector: '021',                                                                                              // 105
        unions: [['rearSpeedsNumber']]                                                                                 // 105
      }, {                                                                                                             // 105
        connector: '023',                                                                                              // 105
        unions: [['frontSpeedsNumber']]                                                                                // 105
      }], selectedItems);                                                                                              // 105
                                                                                                                       //
    case '025':                                                                                                        // 106
      return armado(category, [{                                                                                       // 107
        connector: '021',                                                                                              // 107
        unions: [['rearSpeedsNumber']]                                                                                 // 107
      }, {                                                                                                             // 107
        connector: '022',                                                                                              // 107
        unions: [['rearSpeedsNumber']]                                                                                 // 107
      }], selectedItems);                                                                                              // 107
                                                                                                                       //
    case '026':                                                                                                        // 108
      return armado(category, [{                                                                                       // 109
        connector: '001',                                                                                              // 109
        unions: ['bbsize']                                                                                             // 109
      }, {                                                                                                             // 109
        connector: '023',                                                                                              // 109
        unions: ['crankSetType']                                                                                       // 109
      }], selectedItems);                                                                                              // 109
                                                                                                                       //
    case '027':                                                                                                        // 110
      return armado(category, [], selectedItems);                                                                      // 111
                                                                                                                       //
    case '028':                                                                                                        // 112
      return armado(category, [{                                                                                       // 113
        connector: '003',                                                                                              // 113
        unions: ['forkWidth']                                                                                          // 113
      }, {                                                                                                             // 113
        connector: '027',                                                                                              // 113
        unions: ['handleWidth']                                                                                        // 113
      }], selectedItems);                                                                                              // 113
                                                                                                                       //
    case '029':                                                                                                        // 114
      return armado(category, [{                                                                                       // 115
        connector: '024',                                                                                              // 115
        unions: ['shifterRatio', ['frontSpeedsNumber']]                                                                // 115
      }, {                                                                                                             // 115
        connector: '027',                                                                                              // 115
        unions: ['handlebarType']                                                                                      // 115
      }], selectedItems);                                                                                              // 115
                                                                                                                       //
    case '030':                                                                                                        // 116
      return armado(category, [{                                                                                       // 117
        connector: '005',                                                                                              // 117
        unions: [['frontBrakeType']]                                                                                   // 117
      }, {                                                                                                             // 117
        connector: '027',                                                                                              // 117
        unions: ['handlebarType']                                                                                      // 117
      }], selectedItems);                                                                                              // 117
                                                                                                                       //
    case '031':                                                                                                        // 118
      return armado(category, [{                                                                                       // 119
        connector: '022',                                                                                              // 119
        unions: [['rearSpeedsNumber'], 'shifterRatio']                                                                 // 119
      }, {                                                                                                             // 119
        connector: '027',                                                                                              // 119
        unions: ['handlebarType']                                                                                      // 119
      }], selectedItems);                                                                                              // 119
                                                                                                                       //
    case '032':                                                                                                        // 120
      return armado(category, [{                                                                                       // 121
        connector: '006',                                                                                              // 121
        unions: [['rearBrakeType']]                                                                                    // 121
      }, {                                                                                                             // 121
        connector: '027',                                                                                              // 121
        unions: ['handlebarType']                                                                                      // 121
      }], selectedItems);                                                                                              // 121
                                                                                                                       //
    case '033':                                                                                                        // 122
      return armado(category, [{                                                                                       // 123
        connector: '027',                                                                                              // 123
        unions: ['handlebarType']                                                                                      // 123
      }], selectedItems);                                                                                              // 123
                                                                                                                       //
    case '034':                                                                                                        // 124
      return armado(category, [{                                                                                       // 125
        connector: '023',                                                                                              // 125
        unions: ['crankDiameter']                                                                                      // 125
      }], selectedItems);                                                                                              // 125
                                                                                                                       //
    default:                                                                                                           // 126
      break;                                                                                                           // 127
  }                                                                                                                    // 53
} /**                                                                                                                  // 129
    * Creates a query depending on the connections a item has                                                          //
    * @params category                                                                                                 //
    * @params connections                                                                                              //
    [                                                                                                                  //
      { connector: '003', unions: ['axleSize', 'axleWidth'] }, --> a connection                                        //
      { connector: '005', unions: [['frontBrakeType']] } --> another connection                                        //
    ]                                                                                                                  //
    * @params selectedItems                                                                                            //
    * @returns query                                                                                                   //
    {category: '002', axleSize: '1,2', axleWidth: '3,4', frontBrakeType: {$in: ['vbrake', 'disk']}}                    //
    */                                                                                                                 //
                                                                                                                       //
function armado(category, connections, selectedItems) {                                                                // 143
  // we get the category                                                                                               // 144
  var categoria = Categories.findOne({                                                                                 // 145
    code: category                                                                                                     // 145
  }); // Query starts with current category                                                                            // 145
                                                                                                                       //
  var query = {                                                                                                        // 148
    category: categoria._id                                                                                            // 148
  };                                                                                                                   // 148
  var breaking = false; // each connection                                                                             // 149
                                                                                                                       //
  _.each(connections, function (element) {                                                                             // 151
    // Get selected item on that connection                                                                            // 152
    var connectorId = selectedItems[element.connector]; // console.log('connector', connectorId)                       // 153
                                                                                                                       //
    if (!connectorId) {                                                                                                // 155
      breaking = true;                                                                                                 // 156
      return;                                                                                                          // 157
    }                                                                                                                  // 158
                                                                                                                       //
    var connector = Items.findOne(connectorId);                                                                        // 159
                                                                                                                       //
    if (!connector) {                                                                                                  // 160
      return;                                                                                                          // 161
    } // Explore each union                                                                                            // 162
                                                                                                                       //
                                                                                                                       //
    element.unions.forEach(function (union) {                                                                          // 165
      // if string, query[union] = connector[connection]                                                               // 166
      if (!connector[union]) {                                                                                         // 167
        return;                                                                                                        // 168
      }                                                                                                                // 169
                                                                                                                       //
      if (typeof union === 'string') {                                                                                 // 170
        query[union] = connector[union];                                                                               // 171
      } else {                                                                                                         // 172
        query[union] = {                                                                                               // 173
          $in: connector[union]                                                                                        // 173
        };                                                                                                             // 173
      }                                                                                                                // 174
    });                                                                                                                // 175
  });                                                                                                                  // 176
                                                                                                                       //
  if (breaking) {                                                                                                      // 177
    // console.log('breaking')                                                                                         // 178
    return;                                                                                                            // 179
  } // console.log(query)                                                                                              // 180
                                                                                                                       //
                                                                                                                       //
  return query;                                                                                                        // 182
}                                                                                                                      // 183
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"delay.js":["meteor/meteor","underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/delay.js                                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.import('underscore', {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var lag = false;                                                                                                       // 4
var waitingTime = 400;                                                                                                 // 5
Meteor.startup(function () {                                                                                           // 7
  if (!lag) return;                                                                                                    // 8
  var rootUrl = process.env.ROOT_URL;                                                                                  // 10
                                                                                                                       //
  if (rootUrl !== 'http://localhost:3000/') {                                                                          // 11
    return;                                                                                                            // 12
  } else {                                                                                                             // 13
    console.log('Delaying all publications...');                                                                       // 14
  }                                                                                                                    // 15
                                                                                                                       //
  _.keys(Meteor.server.publish_handlers).map(function (key) {                                                          // 17
    var func = Meteor.server.publish_handlers[key];                                                                    // 18
                                                                                                                       //
    Meteor.server.publish_handlers[key] = function () {                                                                // 19
      this.unblock();                                                                                                  // 20
                                                                                                                       //
      Meteor._sleepForMs(waitingTime + _.random(waitingTime / 3));                                                     // 21
                                                                                                                       //
      return func.apply(this, arguments);                                                                              // 22
    };                                                                                                                 // 23
  });                                                                                                                  // 24
                                                                                                                       //
  Meteor.server.universal_publish_handlers = Meteor.server.universal_publish_handlers.map(function (func) {            // 26
    return function () {                                                                                               // 27
      this.unblock();                                                                                                  // 28
                                                                                                                       //
      Meteor._sleepForMs(waitingTime / 4 + _.random(waitingTime / 10));                                                // 29
                                                                                                                       //
      return func.apply(this, arguments);                                                                              // 30
    };                                                                                                                 // 31
  });                                                                                                                  // 32
});                                                                                                                    // 33
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"excel-export.js":["meteor/meteorhacks:picker","../imports/api/items/items","../imports/api/items/sku","excel-export","underscore.string","underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/excel-export.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Picker = void 0;                                                                                                   // 1
module.import('meteor/meteorhacks:picker', {                                                                           // 1
  "Picker": function (v) {                                                                                             // 1
    Picker = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Items = void 0;                                                                                                    // 1
module.import('../imports/api/items/items', {                                                                          // 1
  "default": function (v) {                                                                                            // 1
    Items = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Sku = void 0;                                                                                                      // 1
module.import('../imports/api/items/sku', {                                                                            // 1
  "default": function (v) {                                                                                            // 1
    Sku = v;                                                                                                           // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var nodeExcel = void 0;                                                                                                // 1
module.import('excel-export', {                                                                                        // 1
  "default": function (v) {                                                                                            // 1
    nodeExcel = v;                                                                                                     // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var unescapeHTML = void 0;                                                                                             // 1
module.import('underscore.string', {                                                                                   // 1
  "unescapeHTML": function (v) {                                                                                       // 1
    unescapeHTML = v;                                                                                                  // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.import('underscore', {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
Picker.route('/excel/export/jklASDHFLKJASDFHL2903490ASDASDasdf', function (params, request, response) {                // 8
  var items = Items.find({}).fetch();                                                                                  // 9
  var conf = {};                                                                                                       // 10
  conf.cols = [{                                                                                                       // 11
    caption: '#',                                                                                                      // 13
    type: 'number',                                                                                                    // 14
    width: 10                                                                                                          // 15
  }, {                                                                                                                 // 12
    caption: 'ID',                                                                                                     // 18
    type: 'string',                                                                                                    // 19
    width: 26.7109375                                                                                                  // 20
  }, {                                                                                                                 // 17
    caption: 'Nombre',                                                                                                 // 23
    type: 'string',                                                                                                    // 24
    width: 40.7109375,                                                                                                 // 25
    beforeCellWrite: function (row, cellData) {                                                                        // 26
      if (!cellData) return '';                                                                                        // 27
      return unescapeHTML(cellData) || '';                                                                             // 28
    }                                                                                                                  // 29
  }, {                                                                                                                 // 22
    caption: 'Código',                                                                                                 // 32
    type: 'string',                                                                                                    // 33
    width: 10.7109375                                                                                                  // 34
  }, {                                                                                                                 // 31
    caption: 'Stock',                                                                                                  // 37
    type: 'number',                                                                                                    // 38
    width: 10.7109375                                                                                                  // 39
  }, {                                                                                                                 // 36
    caption: 'Precio MKR',                                                                                             // 42
    type: 'number',                                                                                                    // 43
    width: 10.7109375,                                                                                                 // 44
    beforeCellWrite: function (row, cellData) {                                                                        // 45
      if (!cellData) {                                                                                                 // 46
        return null;                                                                                                   // 47
      }                                                                                                                // 48
                                                                                                                       //
      cellData = cellData.toString().replace(/\./g, '').replace(/,/g, '');                                             // 50
      return cellData;                                                                                                 // 52
    }                                                                                                                  // 53
  }, {                                                                                                                 // 41
    caption: 'Precio Extreme',                                                                                         // 56
    type: 'number',                                                                                                    // 57
    width: 10.7109375                                                                                                  // 58
  }, {                                                                                                                 // 55
    caption: 'Precio Pampa',                                                                                           // 61
    type: 'number',                                                                                                    // 62
    width: 13.7109375                                                                                                  // 63
  }];                                                                                                                  // 60
  conf.rows = [];                                                                                                      // 67
                                                                                                                       //
  _.each(items, function (item, index) {                                                                               // 68
    index++;                                                                                                           // 69
    conf.rows.push([index, item._id, item.name, null, null, null, null, null]);                                        // 70
    var skus = Sku.find({                                                                                              // 71
      itemId: item._id                                                                                                 // 71
    }).fetch();                                                                                                        // 71
                                                                                                                       //
    _.each(skus, function (sku, index2) {                                                                              // 72
      conf.rows.push([null, null, null, sku.code || '', sku.stock, sku.price || '', sku.extremePrice || '', sku.shopPrice || '']);
    });                                                                                                                // 74
                                                                                                                       //
    conf.rows.push([null, null, null, null, null, null, null, null]);                                                  // 75
  });                                                                                                                  // 76
                                                                                                                       //
  conf.name = 'Items';                                                                                                 // 78
  var file = nodeExcel.execute(conf);                                                                                  // 80
  var headers = {                                                                                                      // 82
    'Content-type': 'application/vnd.openxmlformats',                                                                  // 83
    'Content-Disposition': 'attachment; filename=' + conf.name + '.xlsx'                                               // 84
  };                                                                                                                   // 82
  response.writeHead(200, headers);                                                                                    // 87
  response.end(file, 'binary');                                                                                        // 88
}, {                                                                                                                   // 89
  where: 'server'                                                                                                      // 89
});                                                                                                                    // 89
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"flow.js":["meteor/nicolaslopezj:flow","meteor/email","../entidades/orion/orders","../imports/api/items/items","underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/flow.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var setConfig = void 0;                                                                                                // 1
module.import('meteor/nicolaslopezj:flow', {                                                                           // 1
  "setConfig": function (v) {                                                                                          // 1
    setConfig = v;                                                                                                     // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Email = void 0;                                                                                                    // 1
module.import('meteor/email', {                                                                                        // 1
  "Email": function (v) {                                                                                              // 1
    Email = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Orders = void 0;                                                                                                   // 1
module.import('../entidades/orion/orders', {                                                                           // 1
  "default": function (v) {                                                                                            // 1
    Orders = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Items = void 0;                                                                                                    // 1
module.import('../imports/api/items/items', {                                                                          // 1
  "default": function (v) {                                                                                            // 1
    Items = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.import('underscore', {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
                                                                                                                       //
/* global Assets */function confirm(payment) {                                                                         // 7
  console.log('confirming payment', payment); // Payment.meta.paymentId                                                // 10
                                                                                                                       //
  console.log(payment.meta.cartId);                                                                                    // 13
  Orders.update({                                                                                                      // 15
    _id: payment.meta.cartId                                                                                           // 15
  }, {                                                                                                                 // 15
    $set: {                                                                                                            // 15
      paid: true                                                                                                       // 16
    }                                                                                                                  // 15
  }); // Send email                                                                                                    // 15
                                                                                                                       //
  sendSuccessEmail(payment.meta.cartId);                                                                               // 20
  return true;                                                                                                         // 22
}                                                                                                                      // 23
                                                                                                                       //
function sendSuccessEmail(cartId) {                                                                                    // 25
  var order = Orders.findOne(cartId);                                                                                  // 26
  var mailText = '<h2>Recibo orden de compra en Armatubicicleta</h2>' + '<p>Tu orden de compra ha sido recibida con éxito, aquí los detalles de la compra: </p>' + '<strong>Número orden de compra: ' + order._id + '</strong>' + '<table><tr><td>Producto</td><td>Precio</td></tr>';
                                                                                                                       //
  _.each(order.items, function (orderItem) {                                                                           // 32
    var item = Items.find(orderItem).fetch();                                                                          // 33
    mailText += '<tr>' + '<td>' + item.name + '</td>' + '<td>' + item.price + '</td>' + '</tr>';                       // 34
  });                                                                                                                  // 38
                                                                                                                       //
  mailText += '<tr><td>&nbsp;</td><td>' + order.total + '</td></tr></table><p>Recuerde que ante cualquier consulta, no dude en responder este email.</p>';
  Email.send({                                                                                                         // 42
    to: order.email,                                                                                                   // 43
    from: 'contacto@armatubicicleta.cl',                                                                               // 44
    subject: 'Recibo orden de compra - Armatubicicleta.cl',                                                            // 45
    text: mailText                                                                                                     // 46
  });                                                                                                                  // 42
}                                                                                                                      // 48
                                                                                                                       //
setConfig({                                                                                                            // 50
  baseUrl: 'https://pampa.store/',                                                                                     // 51
  successUrl: 'https://pampa.store/success',                                                                           // 52
  failureUrl: 'https://pampa.store/failure',                                                                           // 53
  key: Assets.getText('keyNachoFlow.pem'),                                                                             // 54
  publicKey: Assets.getText('flow.pubkey'),                                                                            // 55
  email: 'idiaz@csi.cl',                                                                                               // 56
  confirm: confirm,                                                                                                    // 57
  paymentTypes: 1                                                                                                      // 58
});                                                                                                                    // 50
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"itemChecker.js":["meteor/meteor","fibers","../imports/api/items/items","../imports/api/items/sku","underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/itemChecker.js                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Fiber = void 0;                                                                                                    // 1
module.import('fibers', {                                                                                              // 1
  "default": function (v) {                                                                                            // 1
    Fiber = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Items = void 0;                                                                                                    // 1
module.import('../imports/api/items/items', {                                                                          // 1
  "default": function (v) {                                                                                            // 1
    Items = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Sku = void 0;                                                                                                      // 1
module.import('../imports/api/items/sku', {                                                                            // 1
  "default": function (v) {                                                                                            // 1
    Sku = v;                                                                                                           // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.import('underscore', {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
Meteor.methods({                                                                                                       // 7
  itemChecker: function () {                                                                                           // 8
    var fix = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;                               // 8
    this.unblock();                                                                                                    // 9
    console.log('Database Status Check');                                                                              // 10
    var noSku = 0;                                                                                                     // 12
    var badImage = 0;                                                                                                  // 13
    var badImageFixed = 0;                                                                                             // 14
    var noShopPrice = 0;                                                                                               // 15
    var noShopPriceFixed = 0;                                                                                          // 16
    var noSkuImage = 0;                                                                                                // 17
    var noSkuImageFixed = 0;                                                                                           // 18
    var wrongPrice = 0;                                                                                                // 19
    var wrongPriceFixed = 0;                                                                                           // 20
    var totalItems = 0;                                                                                                // 21
    var items = Items.find({                                                                                           // 23
      malo: {                                                                                                          // 23
        $in: [false, null]                                                                                             // 23
      }                                                                                                                // 23
    }).fetch();                                                                                                        // 23
                                                                                                                       //
    _.each(items, function (item, index) {                                                                             // 24
      totalItems++;                                                                                                    // 25
                                                                                                                       //
      if (!item.sku) {                                                                                                 // 26
        console.log('No Sku!', item._id);                                                                              // 27
        noSku++;                                                                                                       // 28
                                                                                                                       //
        if (fix) {                                                                                                     // 29
          Items.update(item._id, {                                                                                     // 30
            $set: {                                                                                                    // 30
              malo: true                                                                                               // 30
            }                                                                                                          // 30
          });                                                                                                          // 30
          console.log('Fixed No Sku!', item._id, '\n');                                                                // 31
        }                                                                                                              // 32
                                                                                                                       //
        return;                                                                                                        // 33
      }                                                                                                                // 34
                                                                                                                       //
      if (item.images) {                                                                                               // 36
        console.log('Bad Image!', item._id);                                                                           // 37
        badImage++;                                                                                                    // 38
                                                                                                                       //
        if (fix === true) {                                                                                            // 39
          Items.update(item._id, {                                                                                     // 40
            $unset: {                                                                                                  // 40
              images: 1                                                                                                // 40
            }                                                                                                          // 40
          });                                                                                                          // 40
          console.log('Fixed Bad Image!', item._id, '\n');                                                             // 41
          badImageFixed++;                                                                                             // 42
        }                                                                                                              // 43
      }                                                                                                                // 44
                                                                                                                       //
      _.each(item.sku, function (sku, index) {                                                                         // 46
        if (!sku.shopPrice) {                                                                                          // 47
          noShopPrice++;                                                                                               // 48
          console.log('No shop price!', item._id, sku.code);                                                           // 49
                                                                                                                       //
          if (fix === true) {                                                                                          // 50
            Meteor.call('fillDataFromUrl', item._id, function (error, response) {                                      // 51
              if (!response || error) {                                                                                // 52
                console.log('csmmm', 'Bad item');                                                                      // 53
                Items.update({                                                                                         // 54
                  _id: item._id,                                                                                       // 54
                  sku: {                                                                                               // 54
                    '$elemMatch': {                                                                                    // 54
                      code: sku.code                                                                                   // 54
                    }                                                                                                  // 54
                  }                                                                                                    // 54
                }, {                                                                                                   // 54
                  $set: {                                                                                              // 54
                    'sku.$.stock': 0                                                                                   // 54
                  }                                                                                                    // 54
                }); // return                                                                                          // 54
              }                                                                                                        // 56
                                                                                                                       //
              console.log('Fixed No shop price!', item._id, sku.code, '\n');                                           // 57
              noShopPriceFixed++;                                                                                      // 58
            });                                                                                                        // 59
          }                                                                                                            // 60
        }                                                                                                              // 61
                                                                                                                       //
        if (sku.shopPrice <= 0) {                                                                                      // 63
          wrongPrice++;                                                                                                // 64
          console.log('Wrong Price!', item._id, sku.code);                                                             // 65
                                                                                                                       //
          if (fix === true) {                                                                                          // 66
            Meteor.call('fillDataFromUrl', item._id, function (error, response) {                                      // 67
              if (!response || error) {                                                                                // 68
                console.log('csmmm', 'Bad item');                                                                      // 69
                Items.update({                                                                                         // 70
                  _id: item._id,                                                                                       // 70
                  sku: {                                                                                               // 70
                    '$elemMatch': {                                                                                    // 70
                      code: sku.code                                                                                   // 70
                    }                                                                                                  // 70
                  }                                                                                                    // 70
                }, {                                                                                                   // 70
                  $set: {                                                                                              // 70
                    'sku.$.stock': 0                                                                                   // 70
                  }                                                                                                    // 70
                }); // return                                                                                          // 70
              }                                                                                                        // 72
                                                                                                                       //
              console.log('Fixed Wrong Price!', item._id, sku.code, '\n');                                             // 73
              wrongPriceFixed++;                                                                                       // 74
            });                                                                                                        // 75
          }                                                                                                            // 76
        }                                                                                                              // 77
                                                                                                                       //
        if (!sku.images) {                                                                                             // 79
          noSkuImage++;                                                                                                // 80
          console.log('No sku image!', item._id, sku.code);                                                            // 81
                                                                                                                       //
          if (fix === true) {                                                                                          // 82
            Meteor.call('uploadMultipleImages', item._id);                                                             // 83
            console.log('Fixed No sku image!', item._id, sku.code, '\n');                                              // 84
            noSkuImageFixed++;                                                                                         // 85
          }                                                                                                            // 86
        }                                                                                                              // 87
      });                                                                                                              // 88
    });                                                                                                                // 89
                                                                                                                       //
    var total = noSku + badImage + noShopPrice + wrongPrice + noSkuImage;                                              // 91
    var totalFixed = badImageFixed + noShopPriceFixed + wrongPriceFixed + noSkuImageFixed;                             // 92
    console.log('No Sku: ', noSku);                                                                                    // 93
    console.log('Bad Images:', badImage);                                                                              // 94
    console.log('No Shop Price:', noShopPrice);                                                                        // 95
    console.log('No Sku Image:', noSkuImage);                                                                          // 96
    console.log('Wrong Price: ', wrongPrice);                                                                          // 97
    console.log('Found ' + total + ' errors');                                                                         // 98
    console.log('Fixed ' + totalFixed + ' errors');                                                                    // 99
    console.log("Of a total of " + totalItems + " Items");                                                             // 100
  },                                                                                                                   // 101
  updatePrices: function () {                                                                                          // 102
    this.unblock();                                                                                                    // 103
    console.log('Updating Prices');                                                                                    // 104
    var updatedPrice = 0;                                                                                              // 106
    var broken = 0;                                                                                                    // 107
    var number = 1; // connect to mkr                                                                                  // 108
                                                                                                                       //
    var cookie = Meteor.call('loginMkr');                                                                              // 111
    var skus = Sku.find().fetch(); // Sku.find({itemId: 'Bp4eqqqin8qcxL6b3'}).fetch()                                  // 113
                                                                                                                       //
    var totalSkus = skus.length; // Do this for all skus                                                               // 114
                                                                                                                       //
    _.each(skus, function (sku, index) {                                                                               // 117
      var itemCode = sku.url.replace('https://www.mkr.cl/store/productDetail/', '');                                   // 118
      console.log("Calling " + number);                                                                                // 119
      Meteor.call('getDetails', itemCode, cookie, function (error, result) {                                           // 120
        if (error) {                                                                                                   // 121
          console.log('Error Getting Details!!', error, sku.code);                                                     // 122
        } else {                                                                                                       // 123
          if (number === skus.length) {                                                                                // 124
            console.log("Operation finishing with " + broken + " broken, " + updatedPrice + " updated from a total of " + totalSkus);
          }                                                                                                            // 126
                                                                                                                       //
          if (!result) {                                                                                               // 128
            // Broken, doesn't appear on mkr or extremezone anymore, mightbe because of missing stock?                 // 129
            console.log("BROKEN! " + sku.code + " which is " + number + " from " + totalSkus);                         // 130
            Fiber(function () {                                                                                        // 131
              Sku.update({                                                                                             // 132
                code: sku.code                                                                                         // 132
              }, {                                                                                                     // 132
                $set: {                                                                                                // 132
                  'stock': 0                                                                                           // 132
                }                                                                                                      // 132
              });                                                                                                      // 132
            }).run();                                                                                                  // 133
            broken++;                                                                                                  // 134
            number++;                                                                                                  // 135
            return;                                                                                                    // 136
          }                                                                                                            // 137
                                                                                                                       //
          Fiber(function () {                                                                                          // 138
            Sku.update({                                                                                               // 139
              code: sku.code                                                                                           // 141
            }, {                                                                                                       // 140
              $set: {                                                                                                  // 144
                'name': result.name,                                                                                   // 145
                'code': result.code,                                                                                   // 146
                'stock': parseInt(result.stock),                                                                       // 147
                'price': parseInt(result.price),                                                                       // 148
                'shopPrice': parseInt(result.shopPrice),                                                               // 149
                'extremePrice': parseInt(result.extremePrice)                                                          // 150
              }                                                                                                        // 144
            }, function () {                                                                                           // 143
              updatedPrice++;                                                                                          // 153
              number++;                                                                                                // 154
              console.log("Fixed " + sku.code + " which is " + number + " from " + totalSkus);                         // 155
            });                                                                                                        // 156
          }).run();                                                                                                    // 157
        }                                                                                                              // 158
      });                                                                                                              // 159
    });                                                                                                                // 160
  },                                                                                                                   // 161
  reuploadPictures: function (itemId) {                                                                                // 162
    var items;                                                                                                         // 163
                                                                                                                       //
    if (itemId) {                                                                                                      // 164
      items = Items.find({                                                                                             // 165
        _id: itemId                                                                                                    // 165
      }).fetch();                                                                                                      // 165
    } else {                                                                                                           // 166
      items = Items.find({                                                                                             // 167
        createdAt: {                                                                                                   // 167
          '$gte': new Date('2017-01-15')                                                                               // 167
        }                                                                                                              // 167
      }).fetch();                                                                                                      // 167
    }                                                                                                                  // 168
                                                                                                                       //
    console.log('updating', items.length);                                                                             // 170
                                                                                                                       //
    _.each(items, function (item, index) {                                                                             // 171
      Meteor.call('uploadMultipleImages', item._id, function (error, response) {                                       // 172
        if (error) {                                                                                                   // 173
          console.log(error);                                                                                          // 174
        } else {                                                                                                       // 175
          console.log(response, item._id);                                                                             // 176
        }                                                                                                              // 177
      });                                                                                                              // 178
    });                                                                                                                // 179
                                                                                                                       //
    console.log('finished updating');                                                                                  // 180
  }                                                                                                                    // 181
});                                                                                                                    // 7
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"kadira.js":["meteor/meteorhacks:kadira",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Kadira = void 0;                                                                                                   // 1
module.import('meteor/meteorhacks:kadira', {                                                                           // 1
  "Kadira": function (v) {                                                                                             // 1
    Kadira = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
Kadira.connect('zvJJccQ5PRKhPdbeK', '98f17914-9aac-4363-aad1-87fe4ac5b6dc');                                           // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"movingtos3.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/movingtos3.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
S3.config = {                                                                                                          // 1
  key: 'AKIAIKGSC5Y3X5LPSHEQ',                                                                                         // 2
  secret: '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',                                                                  // 3
  bucket: 'armatubicicleta'                                                                                            // 4
};                                                                                                                     // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"placeOrder.js":["meteor/nicolaslopezj:flow","meteor/meteor","../imports/api/items/sku","../imports/api/items/items","../entidades/orion/orders","meteor/check","underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/placeOrder.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var newOrder = void 0;                                                                                                 // 1
module.import('meteor/nicolaslopezj:flow', {                                                                           // 1
  "newOrder": function (v) {                                                                                           // 1
    newOrder = v;                                                                                                      // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Sku = void 0;                                                                                                      // 1
module.import('../imports/api/items/sku', {                                                                            // 1
  "default": function (v) {                                                                                            // 1
    Sku = v;                                                                                                           // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Items = void 0;                                                                                                    // 1
module.import('../imports/api/items/items', {                                                                          // 1
  "default": function (v) {                                                                                            // 1
    Items = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var Orders = void 0;                                                                                                   // 1
module.import('../entidades/orion/orders', {                                                                           // 1
  "default": function (v) {                                                                                            // 1
    Orders = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
var check = void 0;                                                                                                    // 1
module.import('meteor/check', {                                                                                        // 1
  "check": function (v) {                                                                                              // 1
    check = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.import('underscore', {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 6);                                                                                                                 // 1
Meteor.methods({                                                                                                       // 9
  /**                                                                                                                  // 10
   * Creates Order in our Database                                                                                     //
   * @param  {object} order The order is bassically contact information with the cart in the items fields              //
   */placeOrder: function (order) {                                                                                    //
    check(order, {                                                                                                     // 15
      items: Array,                                                                                                    // 16
      email: String,                                                                                                   // 17
      name: String,                                                                                                    // 18
      phone: String,                                                                                                   // 19
      address: String                                                                                                  // 20
    }); // add the sell price to the order. And calculate the total of the sell                                        // 15
                                                                                                                       //
    var total = 0;                                                                                                     // 24
    order.items = _.map(order.items, function (item) {                                                                 // 25
      var dbItem = Items.findOne({                                                                                     // 26
        _id: item.itemId                                                                                               // 26
      });                                                                                                              // 26
      var sku = Sku.findOne({                                                                                          // 27
        code: item.sku                                                                                                 // 27
      });                                                                                                              // 27
                                                                                                                       //
      if (!dbItem || !sku) {                                                                                           // 28
        throw new Meteor.Error('placeOrder-item-not-found', 'Item en carro de compra no encontrado');                  // 29
      }                                                                                                                // 30
                                                                                                                       //
      if (item.cantidad > sku.stock) {                                                                                 // 32
        throw new Meteor.Error('placeOrder-not-enogh-stock', 'No hay suficiente stock de un item.', dbItem.name + '/-/' + sku.stock);
      } // Get sell Price                                                                                              // 34
                                                                                                                       //
                                                                                                                       //
      item.sellPrice = sku.shopPrice;                                                                                  // 37
      total += item.sellPrice * item.cantidad;                                                                         // 38
      return item;                                                                                                     // 39
    });                                                                                                                // 40
                                                                                                                       //
    if (total < 35000) {                                                                                               // 42
      total += 3500;                                                                                                   // 43
    }                                                                                                                  // 44
                                                                                                                       //
    order.total = total;                                                                                               // 46
    order.paid = false;                                                                                                // 47
    return {                                                                                                           // 49
      cartId: Orders.insert(order, function (error) {                                                                  // 50
        if (error) {                                                                                                   // 51
          console.log('at error 1', error.sanitizedError.reason);                                                      // 52
          throw new Meteor.Error(error.sanitizedError.reason);                                                         // 53
        }                                                                                                              // 54
      })                                                                                                               // 55
    };                                                                                                                 // 49
  },                                                                                                                   // 57
  /**                                                                                                                  // 58
   * Create the order in the payment system, in this case is flow                                                      //
   * @param  {String} description A description of the order                                                           //
   * @param  {String} buyerEmail  The email of the buyer                                                               //
   * @param  {String} cartId      The cart that is being paid                                                          //
   */createOrder: function (_ref) {                                                                                    //
    var description = _ref.description,                                                                                // 64
        buyerEmail = _ref.buyerEmail,                                                                                  // 64
        cartId = _ref.cartId;                                                                                          // 64
    var theOrder = Orders.findOne(cartId);                                                                             // 65
    var amount = theOrder.total;                                                                                       // 66
    var order = newOrder({                                                                                             // 68
      amount: amount,                                                                                                  // 69
      description: description,                                                                                        // 70
      buyerEmail: buyerEmail,                                                                                          // 71
      paymentType: 1,                                                                                                  // 72
      successUrl: 'https://pampa.store/success',                                                                       // 73
      failureUrl: 'https://pampa.store/failure',                                                                       // 74
      meta: {                                                                                                          // 75
        cartId: cartId                                                                                                 // 76
      }                                                                                                                // 75
    });                                                                                                                // 68
    return order.pack;                                                                                                 // 80
  }                                                                                                                    // 81
});                                                                                                                    // 9
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publications.js":["meteor/meteor","meteor/check","../entidades/orion/brands","../imports/api/items/items","../entidades/orion/categories","../entidades/orion/attributes","../entidades/orion/colors","../imports/api/items/sku","underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor = void 0;                                                                                                   // 1
module.import('meteor/meteor', {                                                                                       // 1
  "Meteor": function (v) {                                                                                             // 1
    Meteor = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var check = void 0;                                                                                                    // 1
module.import('meteor/check', {                                                                                        // 1
  "check": function (v) {                                                                                              // 1
    check = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var Brands = void 0;                                                                                                   // 1
module.import('../entidades/orion/brands', {                                                                           // 1
  "default": function (v) {                                                                                            // 1
    Brands = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var Items = void 0;                                                                                                    // 1
module.import('../imports/api/items/items', {                                                                          // 1
  "default": function (v) {                                                                                            // 1
    Items = v;                                                                                                         // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var Categories = void 0;                                                                                               // 1
module.import('../entidades/orion/categories', {                                                                       // 1
  "default": function (v) {                                                                                            // 1
    Categories = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
var Attributes = void 0;                                                                                               // 1
module.import('../entidades/orion/attributes', {                                                                       // 1
  "default": function (v) {                                                                                            // 1
    Attributes = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 5);                                                                                                                 // 1
var Colors = void 0;                                                                                                   // 1
module.import('../entidades/orion/colors', {                                                                           // 1
  "default": function (v) {                                                                                            // 1
    Colors = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 6);                                                                                                                 // 1
var Sku = void 0;                                                                                                      // 1
module.import('../imports/api/items/sku', {                                                                            // 1
  "default": function (v) {                                                                                            // 1
    Sku = v;                                                                                                           // 1
  }                                                                                                                    // 1
}, 7);                                                                                                                 // 1
                                                                                                                       //
var _ = void 0;                                                                                                        // 1
                                                                                                                       //
module.import('underscore', {                                                                                          // 1
  "default": function (v) {                                                                                            // 1
    _ = v;                                                                                                             // 1
  }                                                                                                                    // 1
}, 8);                                                                                                                 // 1
// The components of an item                                                                                           // 11
Meteor.publish('brands2', function () {                                                                                // 12
  return Brands.find();                                                                                                // 13
});                                                                                                                    // 14
Meteor.publish('items3', function () {                                                                                 // 16
  return Items.find();                                                                                                 // 17
}); /*                                                                                                                 // 18
     * Publicamos los items de la categoría seleccionada:                                                              //
     */                                                                                                                //
Meteor.publish('itemsFromCategory', function (category) {                                                              // 23
  check(category, String);                                                                                             // 24
  var selectedCategory = Categories.findOne({                                                                          // 26
    slug: category                                                                                                     // 26
  });                                                                                                                  // 26
  var items = Items.find({                                                                                             // 27
    category: selectedCategory._id                                                                                     // 27
  }, {                                                                                                                 // 27
    fields: Items.publicFields                                                                                         // 27
  });                                                                                                                  // 27
  var skus = Sku.find({                                                                                                // 28
    itemId: {                                                                                                          // 28
      $in: _.pluck(items.fetch(), '_id')                                                                               // 28
    },                                                                                                                 // 28
    shopPrice: {                                                                                                       // 28
      $nin: [false, null]                                                                                              // 28
    },                                                                                                                 // 28
    stock: {                                                                                                           // 28
      $gte: 5                                                                                                          // 28
    }                                                                                                                  // 28
  });                                                                                                                  // 28
  return [items, skus];                                                                                                // 30
}); /*                                                                                                                 // 31
     * Publicamos los atributos por categoría                                                                          //
     */                                                                                                                //
Meteor.publish('attributesFromCategory', function (category) {                                                         // 36
  if (!this.category) this.ready();                                                                                    // 37
  var selectedCategory = Categories.findOne({                                                                          // 38
    slug: category                                                                                                     // 38
  });                                                                                                                  // 38
  return Attributes.find({                                                                                             // 39
    category: selectedCategory._id                                                                                     // 39
  });                                                                                                                  // 39
});                                                                                                                    // 40
Meteor.publish('attributesFromCategories', function (categories) {                                                     // 42
  if (!categories) return;                                                                                             // 43
  var attributes = Attributes.find({                                                                                   // 44
    category: {                                                                                                        // 44
      $in: categories                                                                                                  // 44
    }                                                                                                                  // 44
  });                                                                                                                  // 44
  return attributes;                                                                                                   // 45
}); // Atributos para el item                                                                                          // 46
                                                                                                                       //
Meteor.publish('attributesFromItem', function (itemId) {                                                               // 49
  if (!itemId) return;                                                                                                 // 50
  var item = Items.findOne(itemId);                                                                                    // 51
  var categories = item.category;                                                                                      // 52
  var attributes = Attributes.find({                                                                                   // 54
    category: {                                                                                                        // 54
      $in: categories                                                                                                  // 54
    }                                                                                                                  // 54
  });                                                                                                                  // 54
  return attributes;                                                                                                   // 55
}); // Publish categories                                                                                              // 56
// Publish Colors                                                                                                      // 59
                                                                                                                       //
Meteor.publish('colores', function () {                                                                                // 60
  return Colors.find();                                                                                                // 61
}); /*                                                                                                                 // 62
    // Publish Items                                                                                                   //
    Meteor.publish('items', function(){                                                                                //
        return Items.find()                                                                                            //
    })                                                                                                                 //
                                                                                                                       //
    // Publish Brands                                                                                                  //
    Meteor.publish('brands', function(){                                                                               //
        return Brands.find()                                                                                           //
    })                                                                                                                 //
                                                                                                                       //
    // Publish Materials                                                                                               //
    Meteor.publish('materials', function(){                                                                            //
        return Materials.find()                                                                                        //
    })                                                                                                                 //
                                                                                                                       //
    // Publish Suppliers                                                                                               //
    Meteor.publish('suppliers', function(){                                                                            //
        return Suppliers.find()                                                                                        //
    }); */                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"main.js":["../imports/startup/server/index",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.import('../imports/startup/server/index');                                                                      // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"entitiesHelpers.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// entitiesHelpers.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Define an email helper on AppFeedback documents using dburles:collection-helpers package.                           // 1
// We'll reference this in our table columns with "email()"                                                            // 2
/*itemComponents.helpers({                                                                                             // 3
  image: function () {                                                                                                 //
    var item = orion.entities.items.collection.findOne({_id: this.component});                                         //
    return item && item.image.url;                                                                                     //
  },                                                                                                                   //
  name: function () {                                                                                                  //
    var item = orion.entities.items.collection.findOne({_id: this.component});                                         //
    return item && item.name;                                                                                          //
  },                                                                                                                   //
  brand: function () {                                                                                                 //
    var item = orion.entities.items.collection.findOne({_id: this.component});                                         //
    return item && item.brand;                                                                                         //
  },                                                                                                                   //
  colour: function () {                                                                                                //
    var item = orion.entities.items.collection.findOne({_id: this.component});                                         //
    return item && item.colour;                                                                                        //
  },                                                                                                                   //
  material: function () {                                                                                              //
    var item = orion.entities.items.collection.findOne({_id: this.component});                                         //
    return item && item.material;                                                                                      //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
// Tabla Tabular                                                                                                       //
var TabularTables = {};                                                                                                //
TabularTables.itemComponents = new Tabular.Table({                                                                     //
  name: "itemComponents",                                                                                              //
  collection: itemComponents,                                                                                          //
  pub: "tabular_itemComponents",                                                                                       //
  order: [[0, "desc"]],                                                                                                //
  columns: [                                                                                                           //
  	{data: "image()", title: "Imagen"},                                                                                 //
  	{data: "name()", title: "Nombre"},                                                                                  //
  	{data: "brand()", title: "Marca"},                                                                                  //
  	{data: "colour()", title: "Color"},                                                                                 //
  	{data: "material()", title: "Material"},                                                                            //
    {data: "quantity", title: "Cantidad"},                                                                             //
    {                                                                                                                  //
      tmpl: Meteor.isClient && Template.appFeedbackCellDelete                                                          //
    }                                                                                                                  //
  ]                                                                                                                    //
});*/                                                                                                                  //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mup.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// mup.js                                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {                                                                                                     // 1
  servers: {                                                                                                           // 2
    one: {                                                                                                             // 3
      host: '34.195.192.214',                                                                                          // 4
      username: 'ubuntu',                                                                                              // 5
      pem: '/home/joaco/Documentos/pampa01.pem' // password: 'alohas172839'                                            // 6
      // or leave blank for authenticate from ssh-agent                                                                // 8
                                                                                                                       //
    }                                                                                                                  // 3
  },                                                                                                                   // 2
  meteor: {                                                                                                            // 12
    name: 'pampastore',                                                                                                // 13
    path: '.',                                                                                                         // 14
    servers: {                                                                                                         // 15
      one: {}                                                                                                          // 16
    },                                                                                                                 // 15
    buildOptions: {                                                                                                    // 18
      serverOnly: true,                                                                                                // 19
      debug: true                                                                                                      // 20
    },                                                                                                                 // 18
    env: {                                                                                                             // 22
      ROOT_URL: 'https://pampa.store',                                                                                 // 23
      MONGO_URL: 'mongodb://meteor:1928-AzB@aws-us-east-1-portal.9.dblayer.com:15241,aws-us-east-1-portal.6.dblayer.com:15241/pampastore'
    },                                                                                                                 // 22
    dockerImage: 'joadr/signature',                                                                                    // 27
    deployCheckWaitTime: 70,                                                                                           // 29
    enableUploadProgressBar: true // ssl: {                                                                            // 30
    //   // crt: './private/ssl/new/bundle.crt',                                                                       // 32
    //   // key: './private/ssl/new/pampa-store-decrypted.key',                                                        // 33
    //   // port: 443                                                                                                  // 34
    //   // autogenerate: {                                                                                            // 35
    //   //   email: 'joaquin@pampa.store',                                                                            // 36
    //   //   domains: 'pampa.store,www.pampa.store,pampastore.cl,www.pampastore.cl'                                   // 37
    //   // }                                                                                                          // 38
    // }                                                                                                               // 39
                                                                                                                       //
  }                                                                                                                    // 12
};                                                                                                                     // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json",".jsx"]});
require("./lib/makeGlobal.js");
require("./lib/reemplazartildes.js");
require("./entidades/dictionary/index.js");
require("./entidades/dictionary/layout.js");
require("./entidades/orion/_init.js");
require("./entidades/orion/attributes.js");
require("./entidades/orion/brands.js");
require("./entidades/orion/categories.js");
require("./entidades/orion/colors.js");
require("./entidades/orion/itemsSuppliers.js");
require("./entidades/orion/materials.js");
require("./entidades/orion/orders.js");
require("./entidades/orion/suppliers.js");
require("./server/mkr/login.js");
require("./server/mkr/mkr.js");
require("./server/armadoPublications.js");
require("./server/delay.js");
require("./server/excel-export.js");
require("./server/flow.js");
require("./server/itemChecker.js");
require("./server/kadira.js");
require("./server/movingtos3.js");
require("./server/placeOrder.js");
require("./server/publications.js");
require("./entitiesHelpers.js");
require("./mup.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
